--liquibase formatted sql

--changeSet proc:Initial-ACBS-loadAmortization-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('ACBS.loadAmortization', 'P') IS NULL EXEC('CREATE PROCEDURE [ACBS].[loadAmortization] @reportDate date,@extractContext varchar(3) AS BEGIN SELECT ret = 1 END')
GO



--changeSet proc:Initial-ACBS-loadAmortization-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER PROCEDURE ACBS.loadAmortization  
   @reportDate date,
   @extractContext varchar(3)
  AS
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t           loadAmortization 
  -- ! R e t u r n s         INT
  -- ! P a r a m e t e r s   Name, DataType, Description
  -- +                       =========================================================================================
  -- !                       @reportDate date
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e     
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !   S A M P L E
  -- !      EXEC ACBS.loadAmortization '2011-06-30', 'EOD'
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y         Date       Who  What
  -- +                       ========== ==== =========================================================================
  -- !                       2011-06-30 CHTH Initial version ...
  -- !                       2011-09-20 ChTh  Now using transformed tables in DWH_HISTORY.
  -- ! 						 2012-08-01 HAWI Added sequence number
  -- !								2012-09-11, H.Winther, Added LoadContextID to avoid duplicates
  -- !								2012-09-14 H.Winther Changed the logic for amortization status
  -- + ---------------------------------------------------------------------------------------------------------------
  --
  SET NOCOUNT ON;
  SET XACT_ABORT ON;
  --
  DECLARE @SPID        INT								= @@SPID;
  DECLARE @PROCID      INT								= @@PROCID;
  DECLARE @SPROC       SYSNAME						= DWH_TOOLKIT.dbo.fnProcName(@PROCID,DB_ID());
  DECLARE @SQL         NVARCHAR ( MAX)				= '';
  -- 
  DECLARE @loadContextID INT = (SELECT ID FROM dwh.[loadContext] AS lc WHERE lc.[reportDate] = @reportDate AND lc.[extractContext] = @extractContext);

  EXEC DWH_TOOLKIT.DWH.createLogRecord 0, @SPID, @SPROC, 'Initializing ...';
  --
  BEGIN TRY
  
      BEGIN TRAN

         DELETE AMO
         FROM DWH.amortization AMO
         INNER JOIN DWH.contract C ON AMO._contract_ID = C.ID
         INNER JOIN DWH.loadContext LC ON C._loadContext_ID = LC.ID
         --WHERE C.reportDate = @reportDate AND _importSource_ID = 5 AND LC.extractContext = @extractContext
         WHERE 
				C.reportDate = @reportDate 
				AND c._importSource_ID = 5 
				AND LC.extractContext = @extractContext 
				AND lc.[reportDate] = @reportDate; -- 2012-09-14, H.Winther, added to improve performance
        

         EXEC DWH_TOOLKIT.DWH.createLogRecord 0, @SPID, @SPROC, '%a1 records deleted from amortization for ACBS', @@ROWCOUNT;

/*
         INSERT INTO DWH.amortization(_contract_ID, 
							          _contractType_ID, 
							          _legType_ID, 
							          legNumber, 
							          _currency_ID, 
							          _amortizationStatus_ID, 
							          amortizationDate, 
							          amortizationAmount, 
							          outstandingAmount, 
							          paymentType,
									  sequenceNumber
									  )
         SELECT 
	           C.ID					AS _contract_ID
	         , C._contractType_ID	AS	_contractType_ID
	         , CCP._legType_ID		AS _legType_ID
	         , CCP.legNumber		AS legNumber
	         , CUR.ID				AS _currency_ID
	         , AMS.ID				AS _amortizationStatus_ID
	         , A.pmnt_date	        AS amortizationDate
	         , A.pmnt_amount		AS amortizationAmount
	         , A.pmnt_outstanding	AS outstandingAmount
	         , A.pmnt_type			AS paymentType
			 , sequenceNumber				= ROW_NUMBER() OVER(PARTITION BY A.value_date,[A].[contractno] ORDER BY A.pmnt_date)
         FROM DWH_HISTORY.ACBS.Amortization A
         INNER JOIN DWH.contract C                 ON  C.contractNumber     = A.contractno
         INNER JOIN DWH.contractCommonProperty CCP ON  CCP._contract_ID     = C.ID
                                                       AND CCP._contractType_ID = C._contractType_ID
         INNER JOIN DWH.LKP_currency           CUR ON  A.CCY_id       = CUR.currencyCode
         INNER JOIN DWH.LKP_amortizationStatus AMS ON  AMS.amortizationStatus = 'ACC'
--         WHERE 
--				A.value_date = @reportDate AND C.reportDate = @reportDate
         WHERE 
				A.value_date = @reportDate 
				AND a.[EOD_SOD] = @extractContext				-- 2012-09-11, H.Winther, Added extractContext to avoid duplicates
				AND C.reportDate = @reportDate 
				AND c.[_loadContext_ID] = @loadContextID		-- 2012-09-11, H.Winther, Added LoadContextID to avoid duplicates
				AND c.[_importSource_ID] = 5				
*/
			;WITH cteAmort
			AS
			(
         SELECT 
	         _contract_ID				= C.ID
	         , _contractType_ID		= C._contractType_ID
	         , _legType_ID				= CCP._legType_ID
	         , legNumber					= CCP.legNumber
	         , _currency_ID				= CUR.ID
	         , amortizationStatus		= CASE WHEN [A].[CM_STATUS] = 'PREL' THEN 'PREL' ELSE 'ACC' END
	         , amortizationDate		= A.pmnt_date 
	         , amortizationAmount		= A.pmnt_amount
	         , outstandingAmount		= A.pmnt_outstanding
	         , paymentType				= A.pmnt_type
				, sequenceNumber			= ROW_NUMBER() OVER(PARTITION BY A.value_date,[A].[contractno] ORDER BY A.pmnt_date)
         FROM DWH_HISTORY.ACBS.Amortization A
         INNER JOIN DWH.contract C
				ON  C.contractNumber     = A.contractno
         INNER JOIN DWH.contractCommonProperty CCP 
				ON  CCP._contract_ID     = C.ID
            AND CCP._contractType_ID = C._contractType_ID
         INNER JOIN DWH.LKP_currency CUR 
				ON  A.CCY_id				= CUR.currencyCode
         WHERE 
				A.value_date = @reportDate 
				AND a.[EOD_SOD] = @extractContext				-- 2012-09-11, H.Winther, Added extractContext to avoid duplicates
				AND C.reportDate = @reportDate 
				AND c.[_loadContext_ID] = @loadContextID		-- 2012-09-11, H.Winther, Added LoadContextID to avoid duplicates
				AND c.[_importSource_ID] = 5				
			)
         INSERT INTO DWH.amortization(
					_contract_ID, 
					_contractType_ID, 
					_legType_ID, 
					legNumber, 
					_currency_ID, 
					_amortizationStatus_ID, 
					amortizationDate, 
					amortizationAmount, 
					outstandingAmount, 
					paymentType,
					sequenceNumber
									  )
			SELECT 
					amort._contract_ID, 
					amort._contractType_ID, 
					amort._legType_ID, 
					amort.legNumber, 
					amort._currency_ID, 
					_amortizationStatus_ID		= ams.ID, 
					amort.amortizationDate, 
					amort.amortizationAmount, 
					amort.outstandingAmount, 
					amort.paymentType,
					amort.sequenceNumber
			FROM [cteAmort] amort
         INNER JOIN DWH.LKP_amortizationStatus AMS 
				ON  AMS.amortizationStatus = amort.amortizationStatus;
         

         EXEC DWH_TOOLKIT.DWH.createLogRecord 0, @SPID, @SPROC, '%a1 records amortizations inserted (ACBS)', @@ROWCOUNT;

      IF @@TRANCOUNT>0 
         COMMIT TRAN
      
      EXEC DWH_TOOLKIT.DWH.createLogRecord 0, @SPID, @SPROC, 'Done! ...';      
      RETURN 0
      
  END TRY
  BEGIN CATCH
  
    IF @@TRANCOUNT>0 
      ROLLBACK TRAN;
 
    SET @SQL = 'EXEC DWH_TOOLKIT.DWH.errorHandler ' 
             + CONVERT(VARCHAR(6), ERROR_LINE())     + ','   + CONVERT(VARCHAR(6), ERROR_NUMBER()) + ','
             + CONVERT(VARCHAR(2), ERROR_SEVERITY()) + ',''' + REPLACE(ERROR_PROCEDURE(), '''', '''''') + ''','''
             + REPLACE(ERROR_MESSAGE() , '''', '''''') + '''';
             
    EXEC (@SQL);
    
    EXEC DWH_TOOLKIT.DWH.rethrowError;
    
  END CATCH
GO