--liquibase formatted sql

--changeSet func:Initial-PF-fnGetSekContractStatusLevel2-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('PF.fnGetSekContractStatusLevel2', 'FN') IS NULL EXEC('CREATE FUNCTION [PF].[fnGetSekContractStatusLevel2](@exposureType varchar(15),@statusCode varchar(3),@contractType varchar(15)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-PF-fnGetSekContractStatusLevel2-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [PF].[fnGetSekContractStatusLevel2]
(
  @exposureType     VARCHAR(15)		= NULL
  ,@statusCode		VARCHAR(3)		= NULL
  ,@contractType	VARCHAR(15)		= NULL
)
RETURNS VARCHAR(30)
AS
BEGIN
  DECLARE @sekContractStatusLevel2 VARCHAR(30);

  SET @sekContractStatusLevel2 = 
	CASE	WHEN @contractType = 'Facility'											THEN 'REGISTRATION' -- Changed from PREL to REGISTRATION as stated by DAHJ
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('01')		THEN 'REGISTRATION'
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('06')		THEN 'APPROVED'
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('07')		THEN 'DISBURSEMENT'
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('10')		THEN 'ACTIVE'
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('40')		THEN 'STOPPED'
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('50','51')	THEN 'SETTLEMENT'
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('90','91')	THEN 'TERMINATED'
			-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
			WHEN @exposureType = 'ContractLine'		AND @statusCode IS NULL			THEN 'CONTRACT'
			
			WHEN @exposureType = 'FrameAgreement'									THEN 'ACTIVE'

			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('10.')		THEN 'CASE_NEW'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('20.')		THEN 'CASE_CREDIT_PREPARATION'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('30.')		THEN 'CASE_TO_BE_APPROVED'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('35.')		THEN 'CASE_COMPLEMENT_INIT'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('36.')		THEN 'CASE_COMPLEMENT_COMPLETE'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('40.')		THEN 'CASE_CREDIT_APPROVED'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('50.')		THEN 'CASE_CREDIT_DENIED'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('60.')		THEN 'CASE_APPROVED'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('70.')		THEN 'N/A'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('99.')		THEN 'CANCELLED'
			-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
			WHEN @exposureType = 'ProFront'			AND @statusCode IS NULL			THEN 'CASE'
	END;

 -- SET @sekContractStatusLevel2 = 
	--CASE	WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('01')		THEN 'REGISTRATION'
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('06')		THEN 'APPROVED'
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('07')		THEN 'DISBURSEMENT'
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('10')		THEN 'ACTIVE'
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('40')		THEN 'STOPPED'
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('50','51')	THEN 'SETTLEMENT'
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('90','91')	THEN 'TERMINATED'
	--		-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IS NULL			THEN 'CONTRACT'
			
	--		WHEN @exposureType = 'FrameAgreement'									THEN 'ACTIVE'

	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('10.')		THEN 'CASE_NEW'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('20.')		THEN 'CASE_CREDIT_PREPARATION'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('30.')		THEN 'CASE_TO_BE_APPROVED'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('35.')		THEN 'CASE_COMPLEMENT_INIT'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('36.')		THEN 'CASE_COMPLEMENT_COMPLETE'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('40.')		THEN 'CASE_CREDIT_APPROVED'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('50.')		THEN 'CASE_CREDIT_DENIED'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('60.')		THEN 'CASE_APPROVED'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('70.')		THEN 'N/A'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('99.')		THEN 'CANCELLED'
	--		-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IS NULL			THEN 'CASE'
	--	END;
	
	RETURN @sekContractStatusLevel2;
	
END
GO