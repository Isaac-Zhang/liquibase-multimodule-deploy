--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_is_credit_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_is_credit_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_is_credit_TRN](@mxContractType varchar(10),@IRD_M_CREDITS varchar(1)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_is_credit_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_is_credit_TRN]
(
	@mxContractType varchar(10),
	@IRD_M_CREDITS varchar(1)
)
RETURNS BIT
AS
BEGIN
	RETURN
		CASE WHEN @mxContractType = 'BOND' THEN
            CASE WHEN @IRD_M_CREDITS = 'Y' THEN 1 ELSE 0 END
		ELSE
			NULL
		END
END
GO