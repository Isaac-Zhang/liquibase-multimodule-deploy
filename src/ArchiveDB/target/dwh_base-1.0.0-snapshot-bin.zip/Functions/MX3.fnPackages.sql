--liquibase formatted sql

--changeSet func:Initial-MX3-fnPackages-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.fnPackages', 'IF') IS NULL EXEC('CREATE FUNCTION [MX3].[fnPackages](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-MX3-fnPackages-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX3].[fnPackages]
(
	@reportDate date,
    @extractContext varchar(3)
)
RETURNS TABLE AS RETURN 
(
  SELECT P.ID, P.reportDate, P.packageID, T.packageType, P.packageExternal, S.packageStatus,
     E.shortName AS packageTrader, P.packageComment, M.packageMethod, P.mx2packageID
  FROM DWH.package P 
  INNER JOIN DWH.loadContext LC ON P._loadContext_ID = LC.ID
  LEFT JOIN DWH.LKP_packageType T ON P._packageType_ID = T.ID
  LEFT JOIN MX3.LKP_packageStatus S ON P._packageStatus_ID = S.mxStatusId
  LEFT JOIN DWH.LKP_employee E ON P._packageTraderEmployee_ID = E.ID
  LEFT JOIN DWH.LKP_packageMethod M ON P._packageMethod_ID = M.ID
  WHERE P.reportDate = @reportDate AND LC.extractContext = @extractContext
)
GO