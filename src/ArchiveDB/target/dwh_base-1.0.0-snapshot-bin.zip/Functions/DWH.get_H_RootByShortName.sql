--liquibase formatted sql

--changeSet func:Initial-DWH-get_H_RootByShortName-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_H_RootByShortName', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[get_H_RootByShortName](@shortName varchar(20),@reportDate datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-get_H_RootByShortName-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[get_H_RootByShortName] ( @shortName		VARCHAR (20)
											  , @reportDate		DATETIME )
RETURNS   VARCHAR (20)
AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @parent                     NUMERIC (10, 0)   CounterpartId of acestor at root level to  
  -- !																				   counterpart supplied as @counterpartId
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !                                   @shortName					 VARCHAR (20)      The shortname of the counterpart to get root 
  -- !																				   acestor for.
  -- !                                   @reportDate                 DATETIME          The date on which the procedure will act.
  -- !
  -- ! O b j e c t i v e :				 Returns the shortname for the ancestor the choosen number of levels up from a counterpart.
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-03-10      JoJo    Initial version by JoJo
  -- !
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
BEGIN
--
	DECLARE @parent  VARCHAR (20);
	DECLARE @lvl	 INT;
	--
	SELECT @lvl = counterpartIDPath.GetLevel() - 2 
	  FROM DWH.counterpartHierarchy CH
     INNER JOIN DWH.counterpart CP ON CP.ID = CH._counterpart_ID
     WHERE reportDate = @reportDate
       AND Shortname = @shortName
	-- Check that the supplied counterpart isn't the root
	IF @lvl <= 1
	BEGIN
		--
		SET @parent = @shortName
		--
	END
	ELSE
	BEGIN
	    -- 
		SET @parent = DWH.get_H_AncestorByShortName(@lvl, @shortName, @reportDate)
		--
	END
	--
	RETURN @parent;
--
END
GO