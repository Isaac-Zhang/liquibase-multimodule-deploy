--liquibase formatted sql

--changeSet func:Initial-ACBS-fnGetContracts-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('ACBS.fnGetContracts', 'IF') IS NULL EXEC('CREATE FUNCTION [ACBS].[fnGetContracts](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-ACBS-fnGetContracts-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [ACBS].[fnGetContracts] 
(@reportDate date, @extractContext varchar(3))
-- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : ACBS.fnGetContracts
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate             DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with contracts from ACBS for the given date.
  -- !                       Contracts from ACBS is returned on a standardized format matching the old GWB format.
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s      :
  -- !                select * from ACBS.fnGetContracts('2012-08-22','EOD');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2011-06-27 ChTh  Initial version
  -- !                       2011-07-11 ChTh  Use of OUTER APPLY for fnGetSekContractType
  -- !                       2011-09-20 ChTh  Now using transformed tables in DWH_HISTORY.
  -- !						 2012-08-30 HAWI  Changed the static value 5 to c.SourceID
  -- !                       2012-09-19 HAWI  Changed couponBaseCurve to NULL if empty string
  -- !                       2013-01-21 MaSo  CHG0010010 - Added load of externAllIn and totalMargin
  -- !                       2013-06-12 MaSo  Marketrisk ReqTest 131 - Added load of day count convention
  -- !						 2014-03-03 AnOh  Marketrisk ReqTest 36  - Added couponFrequncys /JOID
  -- !						 2014-04-01 AnOh  Marketrisk reqTest 36  - changed from functionCall to pick the couponFreq from ACBS.contract
  -- !                       2014-04-02 GoLu  CHG0011095 - syndicated flag
  -- !						 2014-04-22	AnOh  CHG0010627 - added wht_tax CHG0010627
  -- !						 2014-06-19	PaSh  CHG0011309 - added swapContractNumber CHG0011309 
  -- !						 2014-10-30 AnWi  CHG0010011, Nytt f�lt i DWH, nytt f�lt i ACBS, AC Centre
  -- +----------------------------------------------------------------------------------------------------------------
RETURNS TABLE AS RETURN
    SELECT * FROM (
        SELECT
              [sourceID]                              , [extractDate]                           , [eod_sod]                               
            , [ext_id]                                , [rec_seq]                               , [rep_date]                              
            , [ac_int_amt]                            , [acc_pre]                               , [base_curv2] = NULLIF([base_curv2],'') -- 2012-09-19, H.Winther, changed according to tr910                            
            , [base_curve]                            , [book_amt]                              , [c_type]                                
            , [ccy]                                   , [client_no]                             , [cm_end_dat]                            
            , [cn_mat_dat]                            , [cn_reg_dat]                            , [cn_str_dat]                            
            , [cn_trd_dat]                            , [cont_leg]                              , C.[contractno]                            
            , [cu_cpn_dat]                            , [cu_fix_dat]                            , [cu_rte_typ]                            
            , [del_ind]                               , [ext_date]                              , [ext_time]                              
            , [fee_type]                              , [freq_int]                              , [int_basis]                             
            , [int_ext]                               , [iss_clt_no]                            , [lg_ccy]                                
            /*, [lg_mat_dat]*/                        , [lg_str_dat]                            , [nx_cpn_dat]                            
            , [nx_cpn_spr]                            , [nx_fix_dat]                            , [nx_fix_dt2]                            
            , [nx_int_dat]                            , [nx_int_dt2]                            , [nx_int_rte]                            
            , [nx_int_tp2]                            , [nx_int_typ]                            , [nx_rte_typ]                            
            , [ol_fix_dat]                            , [orig_nom]                              , [orig_pcpl]                             
            , [os_nom]                                , [os_pcpl]                               , [package_id]                            
            , [pay_rcv]                               , [pay_type]                              , [portfolio]                             
            , [prod_type]                             , [rec_source]                            , [ref_term]                              
            , [rev_red]                               , [yield_rte]                             , [AGT_CLT_NO]                            
            , [CM_STATUS]                             , [DD_ST_DATE]                            , [IND_CORP]                              
            , [IND_CUFI]                              , [IND_EMMA]                              , [IND_IPF]                               
            , [IND_STRF]                              , [IND_TRFI]                              , [GWB_link]                              
            , [asset_or_liability]                    , [sidaRefRate]                           , [sidaRefNo]
            , [extern_all_in]                         , [total_margin]                          , [exporter_clt_no]
            , [dayCountConvention]					  , [interestRateLeadDays]				    , [dueMonthEndIndicator]
            , [businessDayAdjustment]			      , [couponFrequenceValue]
            , CASE WHEN [c].[CM_STATUS] = 'OFF' THEN 'OFFER' ELSE 'LIVE' END AS contractStatus
            , DWH.fnGetSekContractStatusLevel1(C.c_type, C.CM_STATUS, C.contractno, [C].[sourceID]) AS sekContractStatusLevel1 --2012-08-30, H.Winther, changed from static value to column 
            , DWH.fnGetSekContractStatusLevel2(C.c_type, C.CM_STATUS, C.contractno, [C].[sourceID]) AS sekContractStatusLevel2 --2012-08-30, H.Winther, changed from static value to column
            , CT.level1 AS sekContractTypeLevel1
            , CT.level2 AS sekContractTypeLevel2
            , CT.level3 AS sekContractTypeLevel3
            , CT.level4 AS sekContractTypeLevel4
            , CT.level5 AS sekContractTypeLevel5
            , C.isSyndicated
			, C.wht_tax AS whtTax
			, C.swapContractNumber
			, C.acCenter

        FROM [DWH_HISTORY].[ACBS].[Contract] AS C
        --LEFT JOIN [ACBS].[fnGetACBSContractFrequency](@reportDate, @extractContext ) ACF ON ACF.contractNo = C.contractNo  
        OUTER APPLY DWH.fnGetSekContractType(
                    5, 
                    CASE WHEN LEFT(C.c_type, 2) = 'CL' THEN 'CL' ELSE c_type END,
                    c_type,
                    prod_type,
                    package_id,
	                COALESCE(LTRIM(RTRIM(rev_red)),''),
	                '','','','','') CT

        WHERE rep_date = @reportDate
        UNION ALL
        SELECT
              [sourceID]                              , [extractDate]                           , [eod_sod]                               
            , [ext_id]                                , [rec_seq]                               , [rep_date]                              
            , [ac_int_amt]                            , [acc_pre]                               , [base_curv2] = NULLIF([base_curv2],'') -- 2012-09-19, H.Winther, changed according to tr910
            , [base_curve]                            , [book_amt]                              , [c_type]                                
            , [ccy]                                   , [client_no]                             , [cm_end_dat]                            
            , [cn_mat_dat]                            , [cn_reg_dat]                            , [cn_str_dat]                            
            , [cn_trd_dat]                            , [cont_leg]                              , C.[contractno]                            
            , [cu_cpn_dat]                            , [cu_fix_dat]                            , [cu_rte_typ]                            
            , [del_ind]                               , [ext_date]                              , [ext_time]                              
            , [fee_type]                              , [freq_int]                              , [int_basis]                             
            , [int_ext]                               , [iss_clt_no]                            , [lg_ccy]                                
            /*, [lg_mat_dat] */                       , [lg_str_dat]                            , [nx_cpn_dat]                            
            , [nx_cpn_spr]                            , [nx_fix_dat]                            , [nx_fix_dt2]                            
            , [nx_int_dat]                            , [nx_int_dt2]                            , [nx_int_rte]                            
            , [nx_int_tp2]                            , [nx_int_typ]                            , [nx_rte_typ]                            
            , [ol_fix_dat]                            , [orig_nom]                              , [orig_pcpl]                             
            , [os_nom]                                , [os_pcpl]                               , [package_id]                            
            , [pay_rcv]                               , [pay_type]                              , [portfolio]                             
            , [prod_type]                             , [rec_source]                            , [ref_term]                              
            , [rev_red]                               , [yield_rte]                             , [AGT_CLT_NO]                            
            , [CM_STATUS]                             , [DD_ST_DATE]                            , [IND_CORP]                              
            , [IND_CUFI]                              , [IND_EMMA]                              , [IND_IPF]                               
            , [IND_STRF]                              , [IND_TRFI]                              , [GWB_link]                              
            , [asset_or_liability]                    , [sidaRefRate]                           , [sidaRefNo]
            , [extern_all_in]                         , [total_margin]                          , [exporter_clt_no]
            , [dayCountConvention]					  , [interestRateLeadDays]				    , [dueMonthEndIndicator]
            , [businessDayAdjustment]			      , [couponFrequenceValue]
            , CASE WHEN [c].[CM_STATUS] = 'OFF' THEN 'OFFER' ELSE 'LIVE' END AS contractStatus
            , DWH.fnGetSekContractStatusLevel1(C.c_type, C.CM_STATUS, C.contractno, [C].[sourceID]) AS sekContractStatusLevel1 --2012-08-30, H.Winther, changed from static value to column
            , DWH.fnGetSekContractStatusLevel2(C.c_type, C.CM_STATUS, C.contractno, [C].[sourceID]) AS sekContractStatusLevel2 --2012-08-30, H.Winther, changed from static value to column
            , CT.level1 AS sekContractTypeLevel1
            , CT.level2 AS sekContractTypeLevel2
            , CT.level3 AS sekContractTypeLevel3
            , CT.level4 AS sekContractTypeLevel4
            , CT.level5 AS sekContractTypeLevel5
            , C.isSyndicated
			, C.wht_tax AS whtTax
			, C.swapContractNumber
			, C.acCenter
        FROM [DWH_HISTORY].[ACBS].[Contract_SOD] AS C
        --LEFT JOIN [ACBS].[fnGetACBSContractFrequency](@reportDate, @extractContext ) ACF ON ACF.contractNo = C.contractNo  
        OUTER APPLY DWH.fnGetSekContractType(
                    5, 
                    CASE WHEN LEFT(C.c_type, 2) = 'CL' THEN 'CL' ELSE c_type END,
                    c_type,
                    prod_type,
                    package_id,
	                COALESCE(LTRIM(RTRIM(rev_red)),''),
	                '','','','','') CT
        WHERE rep_date = @reportDate
    ) AS SRC
    WHERE eod_sod = @extractContext
GO