--liquibase formatted sql

--changeSet func:Initial-DWH-has_H_SameLegalCounterpartByShortName-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.has_H_SameLegalCounterpartByShortName', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[has_H_SameLegalCounterpartByShortName](@shortName1 varchar(15),@shortName2 varchar(15),@reportDate datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-has_H_SameLegalCounterpartByShortName-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[has_H_SameLegalCounterpartByShortName] (  @shortName1  VARCHAR (15)
															   , @shortName2  VARCHAR (15)
															   , @reportDate DATETIME )
  RETURNS BIT
  AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @same                       BIT			   1 if the two counterparties have the same legal
  -- !																				   counterpart, 0 otherwise
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !                                   @shortName1				 VARCHAR (20)	   The shortname of the first counterpart to compare.
  -- !                                   @shortName2				 VARCHAR (20)	   The shortname of the second counterpart to compare.
  -- !                                   @reportDate                 DATETIME          The date on which the procedure will act.
  -- !
  -- ! O b j e c t i v e :				 Return 1 if the two counterparties have the same legal counterpart, 0 otherwise.
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-03-12      JoJo    Initial version by JoJo
  -- !
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
  BEGIN
  --
	DECLARE @same BIT;
	--
	IF DWH.get_H_LegalCounterpartByShortName(@shortName1, @reportDate) =
	   DWH.get_H_LegalCounterpartByShortName(@shortName2, @reportDate)
		SET @same = 1
	ELSE
		SET @same = 0
	--
	RETURN @same;
  --
  END
GO