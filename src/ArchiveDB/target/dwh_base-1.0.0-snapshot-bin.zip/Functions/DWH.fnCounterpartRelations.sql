--liquibase formatted sql

--changeSet func:Initial-DWH-fnCounterpartRelations-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnCounterpartRelations', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnCounterpartRelations](@reportDate date,@loadContextID int) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnCounterpartRelations-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnCounterpartRelations](@reportDate date, @loadContextID int)
RETURNS TABLE 
AS
RETURN 
 WITH CTE AS (
   SELECT 
      _counterpart_ID = C1.ID
    , thisShortname = C1.shortname
    , thisIdentity = C1.counterpartIdentity
    , RT.relationType
    , otherShortname = C2.shortname
    , otherLongname = C2.longname
    , otherIdentity = C2.counterpartIdentity
    , otherID = C2.ID
   FROM DWH.counterpart C1
   INNER JOIN DWH.counterpartRelation CR ON CR.[_counterpart_ID_has] = C1.ID
   INNER JOIN DWH.counterpart C2 ON CR.[_counterpart_ID_with] = C2.ID
   INNER JOIN DWH.LKP_relationType RT ON CR.[_relationType_ID] = RT.ID
   WHERE C1.reportDate = @reportDate
   AND C1.[_loadContext_ID] = @loadContextID
   AND c2.reportDate = @reportDate
   AND C2.[_loadContext_ID] = @loadContextID
)
SELECT
   _counterpart_ID = C.ID
 , collateralAgreementGuarantorID = CID.[CollateralAgreementGarantor]   
 , collateralAgreementGuarantorShortname = SN.[CollateralAgreementGarantor]
 , collateralAgreementGuarantorLongname = LN.[CollateralAgreementGarantor]
 , collateralAgreementGuarantorIdentity = CI.[CollateralAgreementGarantor]
 

 , centralCounterpartID = CID.CentralCounterpart
 , centralCounterpartShortname = SN.CentralCounterpart
 , centralCounterpartLongname = LN.CentralCounterpart 
 , centralCounterpartIdentity = CI.CentralCounterpart  
FROM DWH.counterpart C
LEFT JOIN (
   SELECT *
   FROM (
      SELECT _counterpart_ID, relationType, otherShortname
      FROM CTE
   ) A
   PIVOT (MAX(A.otherShortname) FOR A.relationType IN ([CollateralAgreementGarantor], [CentralCounterpart])) pvt
) SN ON C.ID = SN._counterpart_ID
LEFT JOIN (
   SELECT *
   FROM (
      SELECT _counterpart_ID, relationType, otherLongname
      FROM CTE
   ) A
   PIVOT (MAX(A.otherLongname) FOR A.relationType IN ([CollateralAgreementGarantor], [CentralCounterpart])) pvt
) LN ON C.ID = LN._counterpart_ID
LEFT JOIN (
   SELECT *
   FROM (
      SELECT _counterpart_ID, relationType, otherIdentity
      FROM CTE
   ) A
   PIVOT (MAX(A.otherIdentity) FOR A.relationType IN ([CollateralAgreementGarantor], [CentralCounterpart])) pvt
) CI ON C.ID = CI._counterpart_ID
LEFT JOIN (
   SELECT *
   FROM (
      SELECT _counterpart_ID, relationType, otherID
      FROM CTE
   ) A
   PIVOT (MAX(A.otherID) FOR A.relationType IN ([CollateralAgreementGarantor], [CentralCounterpart])) pvt
) CID ON C.ID = CID._counterpart_ID
WHERE C.reportDate = @reportDate AND C._loadContext_ID = @loadContextID
GO