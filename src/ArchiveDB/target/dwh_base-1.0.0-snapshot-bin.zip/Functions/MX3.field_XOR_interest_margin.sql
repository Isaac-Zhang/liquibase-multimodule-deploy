--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_interest_margin-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_interest_margin', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_interest_margin](@mxContractType varchar(10),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_BUY varchar(1),@PL_M_TP_RTMMRG0 numeric(9,4),@PL_M_TP_RTMMRG1 numeric(9,4)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_interest_margin-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_XOR_interest_margin]
(
    @mxContractType varchar(10),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTMMRG0 numeric(9,4),
    @PL_M_TP_RTMMRG1 numeric(9,4)
)
RETURNS numeric(9,4)
AS
BEGIN
	RETURN
	    CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @mxContractType IN ('CF', 'FRA')
			THEN CASE --IIF(TP_BUY=='B',TP_RTMMRG0,TP_RTMMRG1)
				WHEN @PL_M_TP_BUY = 'B'
			        THEN @PL_M_TP_RTMMRG0
			    ELSE @PL_M_TP_RTMMRG1
			END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @mxContractType IN ('EQUIT', 'FUT', 'LN_BR', 'CD', 'BOND', 'CDS', 'FDB', 'NDB', 'SCF', 'OPT', 'OSWP')
			THEN @PL_M_TP_RTMMRG0
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'FXD', 'CS', 'IRS', 'REPO')
			THEN
				CASE WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTMMRG0
			    WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTMMRG1
			    ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
            WHEN @mxContractType IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
            THEN
				CASE WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTMMRG0
			    WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTMMRG1
			    ELSE NULL
            END          
		ELSE NULL
		END
END
GO