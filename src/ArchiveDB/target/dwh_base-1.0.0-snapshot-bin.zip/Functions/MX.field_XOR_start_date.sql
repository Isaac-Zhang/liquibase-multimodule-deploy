--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_start_date-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_start_date', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_start_date](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_DTEPMT datetime,@PL_M_TP_DTEPMT2 datetime,@PL_M_TP_DTEFST datetime,@PL_M_TP_DTEFLWF datetime,@PL_M_TP_DTETRN datetime,@PL_M_TP_RTDCC11 datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_start_date-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_start_date]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_DTEPMT datetime,
    @PL_M_TP_DTEPMT2 datetime,
    @PL_M_TP_DTEFST datetime,
    @PL_M_TP_DTEFLWF datetime,
    @PL_M_TP_DTETRN datetime,
    @PL_M_TP_RTDCC11 datetime    
)
RETURNS datetime
AS
BEGIN
	RETURN 
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_DTEPMT
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_DTEFST
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_DTEFLWF
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_DTEPMT
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_DTETRN
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_DTETRN
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_DTEFLWF
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(DTOC(TP_DTEFLWF)<>'00000000'.AND.TP_DTEFLWF<TP_RTDCC11,TP_DTEFLWF,TP_RTDCC11)
			WHEN @PL_M_TP_DTEFLWF IS NOT NULL AND @PL_M_TP_DTEFLWF < @PL_M_TP_RTDCC11
			THEN @PL_M_TP_DTEFLWF
			ELSE @PL_M_TP_RTDCC11
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(DTOC(TP_DTEFLWF)<>'00000000'.AND.TP_DTEFLWF<TP_RTDCC11,TP_DTEFLWF,TP_RTDCC11)
			WHEN @PL_M_TP_DTEFLWF IS NOT NULL AND @PL_M_TP_DTEFLWF < @PL_M_TP_RTDCC11
			THEN @PL_M_TP_DTEFLWF
			ELSE @PL_M_TP_RTDCC11
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN @PL_M_TP_DTEPMT
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TP_DTEFLWF<TP_DTEPMT,TP_DTEFLWF,TP_DTEPMT)
			WHEN @PL_M_TP_DTEFLWF < @PL_M_TP_DTEPMT
			THEN @PL_M_TP_DTEFLWF
			ELSE @PL_M_TP_DTEPMT
			END
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_DTEFLWF
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_DTEFLWF
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_DTEPMT
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_DTEPMT
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_DTEPMT
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_DTEPMT
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN @PL_M_TP_DTEFST
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_DTEPMT2
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_DTEPMT2
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN @PL_M_TP_DTEFST
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_DTEFST
	    ELSE NULL
	    END
END
GO