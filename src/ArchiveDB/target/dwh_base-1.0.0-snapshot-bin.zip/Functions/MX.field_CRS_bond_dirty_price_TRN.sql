--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_bond_dirty_price_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_bond_dirty_price_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_bond_dirty_price_TRN](@mxContractType varchar(10),@PL_M_P_DIRTY numeric(15,8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_bond_dirty_price_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_bond_dirty_price_TRN]
(
	@mxContractType varchar(10), 
	@PL_M_P_DIRTY numeric(15,8)
)
RETURNS numeric(15,8)
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType IN ('REPO', 'BOND') THEN @PL_M_P_DIRTY 
        ELSE NULL 
        END
END
GO