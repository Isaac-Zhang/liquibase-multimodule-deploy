--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_nextCoupDate_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_nextCoupDate_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_nextCoupDate_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTDKN01 datetime,@PL_M_TP_RTDKN11 datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_nextCoupDate_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_nextCoupDate_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
    @PL_M_TP_RTDKN01 datetime,
    @PL_M_TP_RTDKN11 datetime
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP') THEN
                CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTDKN01
                    WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTDKN11
			    ELSE NULL
			    END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
            ---------------------------------------------------- CRS_CF ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'LN_BR', 'REPO', 'CF') THEN @PL_M_TP_RTDKN01
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('CDS', 'FRA', 'FUT', 'FXD', 'XSW','SWLEG')
			THEN NULL
		ELSE NULL
		END
END
GO