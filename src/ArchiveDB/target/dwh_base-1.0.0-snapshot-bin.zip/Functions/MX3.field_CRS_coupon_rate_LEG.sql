--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_coupon_rate_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_coupon_rate_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_coupon_rate_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTNBPHS numeric(2,0),@PL_M_TP_RTVLC01 numeric(19,6),@PL_M_TP_RTVLC11 numeric(19,6),@PL_M_TP_RTMRTE0 numeric(12,6),@PL_M_TP_STRIKE numeric(12,6)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_coupon_rate_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- User Defined Function
ALTER FUNCTION  [MX3].[field_CRS_coupon_rate_LEG]
(
	@mxContractType varchar(10),
	@COM_leg_LEG int,
    @PL_M_TP_RTNBPHS numeric(2,0),
    @PL_M_TP_RTVLC01 numeric(19,6),
    @PL_M_TP_RTVLC11 numeric(19,6),
    @PL_M_TP_RTMRTE0 numeric(12,6),
    @PL_M_TP_STRIKE numeric(12,6)
)
RETURNS numeric(19,6)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP') THEN
				CASE
                    WHEN @COM_leg_LEG = 1 THEN
			            CASE 
                            WHEN @PL_M_TP_RTNBPHS > 1 THEN 0 ELSE @PL_M_TP_RTVLC01 
                        END
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTVLC11
			    ELSE NULL
			    END
            ---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_CF ----------------------------------------------------
            WHEN @mxContractType IN ('BOND') THEN
			CASE WHEN @PL_M_TP_RTNBPHS > 1 THEN 0 ELSE @PL_M_TP_RTVLC01 END
			---------------------------------------------------- CRS_CD ----------------------------------------------------
    		---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('CD', 'FUT', 'LN_BR', 'REPO', 'CF') THEN @PL_M_TP_RTVLC01
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType IN ('CDS', 'OPT', 'FDB', 'NDB') THEN @PL_M_TP_RTMRTE0
			---------------------------------------------------- CRS_CS ----------------------------------------------------
            ---------------------------------------------------- CRS_FRA ----------------------------------------------------
			WHEN @mxContractType IN ('FRA') THEN
			    CASE
			        WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTVLC01
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTVLC11
			    ELSE NULL
			    END
    		---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('CS', 'IRS') THEN
			    CASE
			        WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTVLC01
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTVLC11
			    ELSE NULL
			    END
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType IN ('FXD', 'XSW','SWLEG') THEN NULL
			---------------------------------------------------- CRS_OSWP ----------------------------------------------------
            WHEN @mxContractType = 'OSWP' THEN
				CASE
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTVLC01
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTVLC11
			    ELSE NULL
			    END
		ELSE NULL
		END
END
GO