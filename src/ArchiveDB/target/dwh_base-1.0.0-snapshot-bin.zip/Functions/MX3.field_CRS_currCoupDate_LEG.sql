--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_currCoupDate_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_currCoupDate_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_currCoupDate_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTDKC01 datetime,@PL_M_TP_RTDKC11 datetime,@COM_contractType_TRN varchar(10),@PL_M_TP_RTMAT0 datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_BUY varchar(1),@PL_M_TP_RTMAT1 datetime,@PL_M_TP_DTEPMT2 datetime,@SEC_M_SE_MAT datetime,@PL_M_QTY_INDEX tinyint) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_currCoupDate_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_currCoupDate_LEG]
(
	@mxContractType varchar(10), 
	@COM_leg_LEG int,
    @PL_M_TP_RTDKC01 datetime,
    @PL_M_TP_RTDKC11 datetime,
    -- Fields needed for CRS_maturity_date_LEG
    @COM_contractType_TRN varchar(10),
	@PL_M_TP_RTMAT0 datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTMAT1 datetime,
    @PL_M_TP_DTEPMT2 datetime,
    @SEC_M_SE_MAT datetime,
    @PL_M_QTY_INDEX TINYINT
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP') THEN
				CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTDKC01
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTDKC11
			    ELSE NULL
			    END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'LN_BR', 'REPO', 'CF')
			THEN @PL_M_TP_RTDKC01
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType = 'CDS'
			THEN NULL
			---------------------------------------------------- FRA, FUT, FXD, XSW ----------------------------------------------------
			WHEN @mxContractType IN ('FRA', 'FUT', 'FXD', 'XSW','SWLEG') THEN --PRE.CRS_maturity_date_LEG
                MX3.field_CRS_maturity_date_LEG(
                    @mxContractType,@COM_contractType_TRN,@PL_M_TP_RTMAT0,
                    @PL_M_TP_DTEEXP,@PL_M_TP_BUY,@PL_M_TP_RTMAT1,@PL_M_TP_DTEPMT2,@SEC_M_SE_MAT, @PL_M_QTY_INDEX)
	    ELSE NULL
	    END
END
GO