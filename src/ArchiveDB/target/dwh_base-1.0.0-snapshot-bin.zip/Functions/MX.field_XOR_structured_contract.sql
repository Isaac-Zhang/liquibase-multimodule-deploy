--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_structured_contract-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_structured_contract', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_structured_contract](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_NBLTI numeric(10,0),@LTI_M_TYPE varchar(4),@LTI_TMPL_M_NAME varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_structured_contract-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_structured_contract]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_NBLTI numeric(10, 0),
    @LTI_M_TYPE varchar(4),
    @LTI_TMPL_M_NAME varchar(20)
)
RETURNS varchar(1)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN CASE --IIF(ISBLANK(LTI_TYPEN())=1.OR.'FUND-Plain Vanilla'$LTI_TYPEN().OR.'ASWP'$LTI_TYPEN(),'N','Y')
				WHEN LTRIM(RTRIM(ISNULL(@LTI_TMPL_M_NAME,''))) LIKE '' OR LTRIM(RTRIM(@LTI_TMPL_M_NAME)) LIKE '%FUND-Plain Vanilla%' OR LTRIM(RTRIM(@LTI_TMPL_M_NAME)) LIKE '%ASWP%'
			THEN 'N'
			ELSE 'Y'
			END
			ELSE CASE --IIF(TP_NBLTI=0,'N', IIF(LNK_TYPE='FUND','N', IIF(LNK_TYPE='ASWP','N', 'Y')))
				WHEN @PL_M_TP_NBLTI = 0
			THEN 'N'
			WHEN @LTI_M_TYPE LIKE '%FUND%'
			THEN 'N'
			WHEN @LTI_M_TYPE LIKE '%ASWP%'
			THEN 'N'
			ELSE 'Y'
			END
		END

END
GO