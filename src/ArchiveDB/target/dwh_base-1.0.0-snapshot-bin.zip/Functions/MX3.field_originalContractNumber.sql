--liquibase formatted sql

--changeSet func:Initial-MX3-field_originalContractNumber-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_originalContractNumber', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_originalContractNumber](@PL_M_MRPL_ONB int) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_originalContractNumber-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_originalContractNumber]
(
  @PL_M_MRPL_ONB INT
)
RETURNS VARCHAR(20)
AS
BEGIN
RETURN
   CASE WHEN @PL_m_mrpl_onb <= 0
        THEN NULL
        ELSE CAST(@PL_M_MRPL_ONB AS VARCHAR(20))
   END
END
GO