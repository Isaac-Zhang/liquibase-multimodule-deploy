--liquibase formatted sql

--changeSet func:Initial-NOSTRO-getACBSNostroTransactionStatus-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('NOSTRO.getACBSNostroTransactionStatus', 'IF') IS NULL EXEC('CREATE FUNCTION [NOSTRO].[getACBSNostroTransactionStatus](@reportDate date,@reportTime datetime) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-NOSTRO-getACBSNostroTransactionStatus-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [NOSTRO].[getACBSNostroTransactionStatus]
( 
  @reportDate DATE
 ,@reportTime DATETIME
 )
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : [SUP].[getACBSNostroTransactionStatus]
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns ACBS Nostro transactions' status before @reportTime on @reportDate
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s      :
  -- !                SELECT * FROM [NOSTRO].[getACBSNostroTransactionStatus]('2014-11-11', '2014-11-11 08:00:00.000');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2014-11-11 TOLH  Initial version
  -- +----------------------------------------------------------------------------------------------------------------

AS RETURN
(

WITH acbs AS 
(
   SELECT 
    reportDate
   , tradeGlobalID
   , tradeExternalID
   , nostroName
   , currency
   , amount
   , facilityID
   , loanID
   , loadDate
   , typology
   , rowNumber = ROW_NUMBER() OVER (PARTITION BY tradeGlobalID ORDER BY loadDate DESC)
   FROM NOSTRO.acbsTransaction
   WHERE  (loadDate <= @reportTime OR @reportTime IS NULL)
)
,mx AS
(
   SELECT 
     tradeGlobalID
   , loadStatus
   , reportDate
   , loadDate
   , rowNumber = ROW_NUMBER() OVER (PARTITION BY tradeGlobalID ORDER BY loadDate DESC)
   , batchVerified
   FROM NOSTRO.mxgTransactionAck
   WHERE  (loadDate <= @reportTime OR @reportTime IS NULL)
)


SELECT 
 a.reportDate
,a.tradeGlobalID
,a.tradeExternalID
,a.nostroName
,a.currency
,a.amount
,a.facilityID
,a.loanID
,acbs_loadDate = a.loadDate
,mx_loadDate = m.loadDate
,loadStatus = COALESCE(m.loadStatus, 'WAITING')
,a.typology
,batchVerified = COALESCE(m.batchVerified, 0)
--,acbs_rowNumber = a.rowNumber
--,mx_rowNumber = m.rowNumber
FROM acbs a
LEFT JOIN mx m
  ON  a.tradeGlobalID = m.tradeGlobalID
  AND a.loadDate <= m.loadDate
  AND m.rowNumber = 1
WHERE a.loadDate >= @reportDate
AND a.rowNumber = 1

)
GO