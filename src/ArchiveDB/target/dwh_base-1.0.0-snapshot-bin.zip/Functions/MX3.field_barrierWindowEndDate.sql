--liquibase formatted sql

--changeSet func:Initial-MX3-field_barrierWindowEndDate-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_barrierWindowEndDate', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_barrierWindowEndDate](@mxContractType varchar(10),@PL_M_TP_FXBRWED date) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_barrierWindowEndDate-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_barrierWindowEndDate]
(
	@mxContractType varchar(10), 
	@PL_M_TP_FXBRWED date
)
RETURNS DATE
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType IN ('OPT', 'FDB', 'NDB') THEN @PL_M_TP_FXBRWED
        ELSE NULL
        END
END
GO