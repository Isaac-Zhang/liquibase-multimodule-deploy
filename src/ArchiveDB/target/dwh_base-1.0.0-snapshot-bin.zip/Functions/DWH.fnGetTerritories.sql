--liquibase formatted sql

--changeSet func:Initial-DWH-fnGetTerritories-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnGetTerritories', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnGetTerritories](@reportDate date) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnGetTerritories-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnGetTerritories](@reportDate date)
RETURNS TABLE AS RETURN 
WITH TERR AS (
   SELECT T.ID, T.territoryName, TT.territoryType, CC.currencyCode
   FROM DWH.fnLKP_territory(@reportDate) T
   INNER JOIN DWH.LKP_territoryType TT 
      ON TT.ID = T.[_territoryType_ID]
   LEFT JOIN DWH.LKP_currency CC ON T._currency_ID = CC.ID
), COU AS (
   SELECT *
   FROM TERR
   WHERE territoryType = 'COU'
)
SELECT 
     territoryID = COU.ID
   , countryName = COU.territoryName
   , countryCurrencyCode = COU.currencyCode
   , parentTerritory = TERR.territoryName
   , parentTerritoryType = TERR.territoryType
FROM COU
INNER JOIN DWH.LKP_territoryMapping TM
   ON TM.[_territory_ID] = COU.ID
INNER JOIN TERR 
   ON TERR.ID = TM.[_territoryParent_ID]
WHERE TM.isIncluded = 1
AND @reportDate BETWEEN TM.validFrom AND TM.validTo

/*
SELECT * FROM DWH.fnGetTerritories('2014-09-22')
WHERE parentTerritory = 'EU' AND parentTerritoryType = 'ER'          

*/
GO