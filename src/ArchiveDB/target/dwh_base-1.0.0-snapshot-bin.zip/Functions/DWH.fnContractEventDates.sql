--liquibase formatted sql

--changeSet func:Initial-DWH-fnContractEventDates-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnContractEventDates', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnContractEventDates](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnContractEventDates-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnContractEventDates](@reportDate date, @extractContext varchar(3))
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnContractEventDates
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate					DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with all contractEventDates pivoted to columns
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s			:
  -- !								select * from DWH.fnContractEventDates('2010-05-03');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-10-05 JoJo  Initial version
  -- !                       2011-01-20 JoJo  Added eventType to resultset.
  -- +----------------------------------------------------------------------------------------------------------------

AS RETURN
(
	WITH CON AS (
		SELECT C.ID 
		FROM DWH.contract C
        INNER JOIN DWH.loadContext LC ON C._loadContext_ID = LC.ID
		WHERE C.reportDate=@reportDate AND LC.extractContext = @extractContext
)
	SELECT
		_contract_id		AS _contract_id,
		_contractType_ID	AS _contractType_ID,
		eventType			AS eventType,
		eventStartDate		AS maxEventStartDate, 
		eventTradeDate		AS maxEventTradeDate
	FROM
		(
			SELECT 
				CD._contract_id,
				CD._contractType_ID,
				CD.eventDate,
				DT.dateType,
				ET.eventType
			FROM DWH.contractEventDate CD
				INNER JOIN DWH.LKP_dateType DT on cd._dateType_ID = dt.ID
				INNER JOIN CON ON cd._contract_ID = CON.ID
				INNER JOIN DWH.LKP_eventType ET ON cd._eventType_ID = et.ID

	) AS p
	PIVOT
	(
		MAX([eventDate])
		FOR dateType IN (eventStartDate, eventTradeDate)
	) AS pvt
)
GO