--liquibase formatted sql

--changeSet func:Initial-MX-field_COM_uniqueTradeId_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_COM_uniqueTradeId_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_COM_uniqueTradeId_TRN](@COM_contractFamily varchar(10),@CRD_uniqueTradeId varchar(52),@EQD_uniqueTradeId varchar(52),@IRD_uniqueTradeId varchar(52),@CURR_uniqueTradeId varchar(52)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_COM_uniqueTradeId_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_COM_uniqueTradeId_TRN](
@COM_contractFamily varchar(10), 
@CRD_uniqueTradeId varchar(52),
@EQD_uniqueTradeId varchar(52),
@IRD_uniqueTradeId varchar(52),
@CURR_uniqueTradeId varchar(52)
)
RETURNS varchar(52)
AS
BEGIN
  RETURN
	CASE
		       ---- EQD ----
		WHEN @COM_contractFamily = 'EQD'  THEN
			 @EQD_uniqueTradeId
                ---- IRD ----
        WHEN @COM_contractFamily = 'IRD'  THEN
			 @IRD_uniqueTradeId
                ---- CURR ----
		WHEN @COM_contractFamily = 'CURR' THEN
			 @CURR_uniqueTradeId
		        ---- CRD ---	
		WHEN @COM_contractFamily = 'CRD' THEN
              @CRD_uniqueTradeId
          ELSE NULL
			
  	END
END
GO