--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_coupon_type_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_coupon_type_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_coupon_type_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTFV0 varchar(1),@PL_M_TP_RTFV1 varchar(1)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_coupon_type_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- User Defined Function
ALTER FUNCTION  [MX3].[field_CRS_coupon_type_LEG]
(
	@mxContractType varchar(10),
	@COM_leg_LEG int,
    @PL_M_TP_RTFV0 varchar(1),
    @PL_M_TP_RTFV1 varchar(1)
)
RETURNS varchar(1)
AS
BEGIN
	RETURN 
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP')
			THEN CASE 
                 WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTFV0
			     WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTFV1
			     ELSE NULL
			     END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'CDS', 'LN_BR', 'CF')
			THEN @PL_M_TP_RTFV0
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			WHEN @mxContractType IN ('FRA')
			THEN CASE 
                 WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTFV0
			     WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTFV1
			     ELSE NULL
			     END
            ---------------------------------------------------- CRS_FUT ----------------------------------------------------
            ---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType IN ('FUT', 'FXD', 'XSW','SWLEG')
			THEN 'F'
		ELSE NULL
		END
END
GO