--liquibase formatted sql

--changeSet func:Initial-DWH-fnInstrumentBondLeadManagers-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnInstrumentBondLeadManagers', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnInstrumentBondLeadManagers](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnInstrumentBondLeadManagers-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnInstrumentBondLeadManagers]
(
	@reportDate date,
    @extractContext varchar(3)
)
RETURNS TABLE AS RETURN 
(
    ------------------------------------------------------------------------------------------
    -- Get shortnames and pivot
    ------------------------------------------------------------------------------------------
    SELECT NAMES._instrument_ID, 
        NAMES.LeadManager1, NAMES.LeadManager2, NAMES.LeadManager3, NAMES.LeadManager4,
        ID._leadManager1_ID, ID._leadManager2_ID, ID._leadManager3_ID, ID._leadManager4_ID
    FROM (
       SELECT 
          _instrument_ID,
          [1] AS leadManager1,
          [2] AS leadManager2,
          [3] AS leadManager3,
          [4] AS LeadManager4
       FROM (
          SELECT BLM.position, C.shortname, BLM._instrument_ID
          FROM DWH.instrumentBondLeadManager BLM 
          INNER JOIN DWH.instrument I ON I.ID = BLM._instrument_ID
          INNER JOIN DWH.counterpart C ON BLM._counterpart_ID = C.ID
          WHERE I.reportDate = @reportDate
            AND I._loadContext_ID = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)
            AND C._loadContext_ID = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)
       ) AS p
       PIVOT (
          MIN(shortname)
          FOR position IN ([1],[2],[3],[4])
       ) AS pvt
    ) NAMES

    ------------------------------------------------------------------------------------------
    -- Get ID's and pivot
    ------------------------------------------------------------------------------------------
    LEFT JOIN (
       SELECT 
          _instrument_ID,
          [1] AS _leadManager1_ID,
          [2] AS _leadManager2_ID,
          [3] AS _leadManager3_ID,
          [4] AS _leadManager4_ID
       FROM (
          SELECT BLM.position, BLM._instrument_ID, BLM._counterpart_ID
          FROM DWH.instrumentBondLeadManager BLM 
          INNER JOIN DWH.instrument I ON I.ID = BLM._instrument_ID
          INNER JOIN DWH.counterpart C ON BLM._counterpart_ID = C.ID
          WHERE I.reportDate = @reportDate
            AND I._loadContext_ID = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)
            AND C._loadContext_ID = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)
       ) AS p
       PIVOT (
          MIN(_counterpart_ID)
          FOR position IN ([1],[2],[3],[4])
       ) AS pvt
    ) ID ON NAMES._instrument_ID = ID._instrument_ID
)
GO