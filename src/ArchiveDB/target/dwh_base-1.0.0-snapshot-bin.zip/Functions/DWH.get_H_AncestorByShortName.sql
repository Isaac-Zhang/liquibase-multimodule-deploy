--liquibase formatted sql

--changeSet func:Initial-DWH-get_H_AncestorByShortName-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_H_AncestorByShortName', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[get_H_AncestorByShortName](@level int,@shortName varchar(20),@reportDate datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-get_H_AncestorByShortName-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[get_H_AncestorByShortName] (  @level			INT
												   , @shortName		VARCHAR (20)
												   , @reportDate		DATETIME )
RETURNS   VARCHAR (20)
AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @parent                     VARCHAR (20)      Shortname of acestor at level @level to  
  -- !																				   counterpart supplied as @shortName
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !									 @level						 INT			   The number of levels up in the hierarchy to
  -- !																				   pick the acestor from. Value is zero indexed, e.g.
  -- !																				   0 means parent just above, 1 grandparent etc.
  -- !                                   @shortName					 VARCHAR (20)      The shortname of the counterpart to get acestor for.
  -- !                                   @reportDate                 DATETIME          The date on which the procedure will act.
  -- !
  -- ! O b j e c t i v e :				 Returns the shortname for the ancestor the choosen number of levels up from a counterpart.
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-02-23      JoJo    Initial version by JoJo
  -- !                                   2010-11-22      JoJo    LEFT JOIN instead
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
BEGIN
--
	DECLARE @parent  VARCHAR (20);
	--
	WITH CP AS (
		SELECT C.counterpartIdentity, C.shortname, reportDate, counterpartIDPath, parentCounterpartIDPath
		FROM DWH.counterpart C
		INNER JOIN DWH.counterpartHierarchy CH ON C.ID = CH._counterpart_ID
		WHERE reportDate = @reportDate
	)
	SELECT @parent = COALESCE(parent.shortName, child.shortName)
	FROM CP child
	LEFT JOIN CP parent	ON	child.parentCounterpartIDPath.GetAncestor(@level) = parent.counterpartIDPath
							AND child.reportDate = parent.reportDate
	WHERE child.reportDate = @reportDate AND child.shortName = @shortName;
	--
	RETURN @parent;
--
END
GO