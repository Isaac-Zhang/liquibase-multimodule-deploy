--liquibase formatted sql

--changeSet func:Initial-DWH-fnGetInstrumentQuoteBasis-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnGetInstrumentQuoteBasis', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnGetInstrumentQuoteBasis]() RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnGetInstrumentQuoteBasis-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [DWH].[fnGetInstrumentQuoteBasis]()
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.[fnGetInstrumentQuoteBasis]
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate          DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with quotebasis
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s      :
  -- !                select * from [fnGetInstrumentQuoteBasis];
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2013-10-08 PEHA  Initial version
  -- !                       2013-11-20 PEHA  Updated to allow only valid quoteBasis string
  -- +----------------------------------------------------------------------------------------------------------------

AS RETURN
(  

   SELECT 
         instrument
        ,quoteBasis = RES.quoteBasis
   FROM DWH_MANUAL.DWH.portfolioTransparency PT
   CROSS APPLY (SELECT quoteBasis = SUBSTRING(COALESCE(PT.payoff_1_underlying
                                         ,PT.payoff_2_Underlying
                                         ,PT.payoff_3_underlying
                                         ,PT.payoff_4_underlying
                                         ,PT.payoff_5_underlying
                                         ,PT.finalRedemptionUnderlying),4,7) ) AS RES
   WHERE endDate IS NULL
   AND LEN(quoteBasis) = 7
   AND quoteBasis LIKE '[A-Z][A-Z][A-Z]/[A-Z][A-Z][A-Z]' 

)