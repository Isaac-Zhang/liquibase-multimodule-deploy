--liquibase formatted sql

--changeSet func:Initial-MX3-field_optionPremiumValueCurrency-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_optionPremiumValueCurrency', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_optionPremiumValueCurrency](@mxContractType varchar(10),@pl_m_trn_fmly varchar(10),@pl_m_trn_group varchar(10),@pl_m_pl_inscur varchar(3),@pl_m_tp_uqty varchar(3)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_optionPremiumValueCurrency-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_optionPremiumValueCurrency]
(
   @mxContractType   varchar(10)
 , @pl_m_trn_fmly    varchar(10)
 , @pl_m_trn_group   varchar(10)
 , @pl_m_pl_inscur   varchar(3)
 , @pl_m_tp_uqty     varchar(3)
)
RETURNS varchar(3)
AS
BEGIN
	RETURN 
      CASE WHEN @pl_m_trn_fmly = 'EQD' AND @pl_m_trn_group = 'OPT' THEN @pl_m_pl_inscur
      WHEN @mxContractType IN ('CDS','FDB','NDB') THEN @pl_m_pl_inscur
      WHEN @mxContractType IN ('OPT') THEN @pl_m_tp_uqty
      ELSE NULL
      END    
END
GO