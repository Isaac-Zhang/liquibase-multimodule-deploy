--liquibase formatted sql

--changeSet func:Initial-DWH-fnGetSekContractType-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnGetSekContractType', 'TF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnGetSekContractType](@is int,@ssptl1 varchar(32),@ssptl2 varchar(32),@ssptl3 varchar(32),@ssptl4 varchar(32),@revRed varchar(32),@putCall varchar(32),@capFloor varchar(32),@packType varchar(32),@portfolio varchar(32),@typology varchar(32)) RETURNS @tab TABLE ([level1] varchar(50),[level2] varchar(50),[level3] varchar(50),[level4] varchar(50),[level5] varchar(50)) AS BEGIN RETURN END')
GO



--changeSet func:Initial-DWH-fnGetSekContractType-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [DWH].[fnGetSekContractType]
(
	@is				INT			= 0,
	@ssptl1			VARCHAR(32)	= '',
	@ssptl2			VARCHAR(32)	= '',
	@ssptl3			VARCHAR(32)	= '',
	@ssptl4			VARCHAR(32)	= '',
	@revRed			VARCHAR(32)	= '',
	@putCall		VARCHAR(32)	= '',
	@capFloor		VARCHAR(32)	= '',
	@packType		VARCHAR(32)	= '',
	@portfolio		VARCHAR(32)	= '',
	@typology		VARCHAR(32)	= ''
)
RETURNS @contractType TABLE (
   level1 varchar(50),
   level2 varchar(50),
   level3 varchar(50),
   level4 varchar(50),
   level5 varchar(50)
)
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnGetSekContractType
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @is					 INT			Source system (0, 1, 3)
  -- !                       @ssptl1				 VARCHAR(32)	Source system product type level 1
  -- !                       @ssptl2				 VARCHAR(32)	Source system product type level 2
  -- !                       @ssptl3				 VARCHAR(32)	Source system product type level 3
  -- !                       @ssptl4				 VARCHAR(32)	Source system product type level 4
  -- !                       @revRed				 VARCHAR(32)	Revolving or Reducing product
  -- !                       @putCall				 VARCHAR(32)	Put or Call product
  -- !                       @capFloor				 VARCHAR(32)	Cap or Floor product
  -- !                       @packType				 VARCHAR(32)	Package Type
  -- !                       @portfolio				 VARCHAR(32)	Portfolio
  -- !                       @typology				 VARCHAR(32)	Typology
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table contract levels
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s		:
  -- !						select DWH.fnGetSekContractType(....);
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y        :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-11-15 JOJO  Initial version by Johan Johansson
  -- !                       2010-11-16 JOJO  Added complete sub tree for internal deals
  -- !                       2010-11-29 JOJO  Fix: changed ExportCredit to Loan
  -- !                       2010-12-09 JOJO  Fix: changed PROJ and INFRA mapping for GWB
  -- !						 2010-12-15 DAHJ  Fix: changes on PROJ and INFRA.
  -- !						 2010-12-16 JoJo  Removed InternalDeal top level.
  -- !						 2011-01-10 JoJo  Added Generic to CapFloor type.
  -- !						 2011-01-10 JoJo  Changed CASHCOL to CASH
  -- !						 2011-01-12 JoJo  Added level4 for LN_BR to be tagged as ForexSwapLNBR
  -- !						 2011-01-12 JoJo  Removed previous portfolio test for ForexSwapLNBR
  -- !						 2011-01-19 JoJo  Renamed BAR to SimpleBarrier
  -- !						 2011-01-19 JoJo  Renamed Derivative,Option,Ladder to Derivative,Option,LadderOption
  -- !                       2011-07-11 ChTh  Changed to a table function and use of OUTER APPLY
  -- !                       2011-08-22 ChTh  Added check of ACBS as source as well to all GWB types
  -- !                       2012-01-13 JoJo  Added four rows for PRF Facility types
  -- !						 2012-08-15 HAWI  Added product types for ACBS products (cirr, purrec & billex)
  -- !						 2012-09-18 HAWI Made a correction for BILLEX
  -- !						 2013-11-04 JoJo  (CHG0010719) Added Derivative,CreditDerivative,CreditDefaultSwap,Guarantee,CRD
  -- !						 2014-01-24 JoJo  (CHG0011141) Added Bond_GF: Guarantee,Guarantee,Guarantee,Guarantee,CDS
  -- +----------------------------------------------------------------------------------------------------------------
AS 
BEGIN
	DECLARE @type       VARCHAR(255);

    SELECT @type = 
		CASE
			-- Facility
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'EXLOAN'									THEN 'CreditFacility,Loan,Loan,Revolving,EXLOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'EXLOAN'									THEN 'CreditFacility,Loan,Loan,Reducing,EXLOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'FL\DE\'									THEN 'CreditFacility,Loan,Loan,Revolving,FL\DE\'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'FL\DE\'									THEN 'CreditFacility,Loan,Loan,Reducing,FL\DE\'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'FL\DEN'									THEN 'CreditFacility,Loan,Loan,Revolving,FL\DEN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'FL\DEN'									THEN 'CreditFacility,Loan,Loan,Reducing,FL\DEN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'INFRA'									THEN 'CreditFacility,Loan,Loan,Revolving,INFRA'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'INFRA'									THEN 'CreditFacility,Loan,Loan,Reducing,INFRA'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'LEAS'									THEN 'CreditFacility,Leasing,FinancialLease,Revolving,LEAS'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'LEAS'									THEN 'CreditFacility,Leasing,FinancialLease,Reducing,LEAS'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'LOAN'									THEN 'CreditFacility,Loan,Loan,Revolving,LOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'LOAN'									THEN 'CreditFacility,Loan,Loan,Reducing,LOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'MIK'										THEN 'CreditFacility,Loan,Loan,Revolving,MIK'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'MIK'										THEN 'CreditFacility,Loan,Loan,Reducing,MIK'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'PROJ'									THEN 'CreditFacility,Loan,Loan,Revolving,PROJ'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'PROJ'									THEN 'CreditFacility,Loan,Loan,Reducing,PROJ'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'STAND'									THEN 'CreditFacility,Loan,Loan,Revolving,STAND'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'STAND'									THEN 'CreditFacility,Loan,Loan,Reducing,STAND'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'UKREDN'									THEN 'CreditFacility,Loan,Loan,Revolving,UKREDN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'UKREDN'									THEN 'CreditFacility,Loan,Loan,Reducing,UKREDN'
			-- Disbursed
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'EXLOAN'									THEN 'CreditDisbursed,Loan,Loan,Revolving,EXLOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'EXLOAN'									THEN 'CreditDisbursed,Loan,Loan,Reducing,EXLOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'FL\DE\'									THEN 'CreditDisbursed,Loan,Loan,Revolving,FL\DE\'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'FL\DE\'									THEN 'CreditDisbursed,Loan,Loan,Reducing,FL\DE\'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'FL\DEN'									THEN 'CreditDisbursed,Loan,Loan,Revolving,FL\DEN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'FL\DEN'									THEN 'CreditDisbursed,Loan,Loan,Reducing,FL\DEN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'INFRA'									THEN 'CreditDisbursed,Loan,Loan,Revolving,INFRA'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'INFRA'									THEN 'CreditDisbursed,Loan,Loan,Reducing,INFRA'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'LEAS'									THEN 'CreditDisbursed,Leasing,FinancialLease,Revolving,LEAS'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'LEAS'									THEN 'CreditDisbursed,Leasing,FinancialLease,Reducing,LEAS'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'LOAN'									THEN 'CreditDisbursed,Loan,Loan,Revolving,LOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'LOAN'									THEN 'CreditDisbursed,Loan,Loan,Reducing,LOAN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'MIK'										THEN 'CreditDisbursed,Loan,Loan,Revolving,MIK'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'MIK'										THEN 'CreditDisbursed,Loan,Loan,Reducing,MIK'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'PROJ'									THEN 'CreditDisbursed,Loan,Loan,Revolving,PROJ'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'PROJ'									THEN 'CreditDisbursed,Loan,Loan,Reducing,PROJ'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'STAND'									THEN 'CreditDisbursed,Loan,Loan,Revolving,STAND'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'STAND'									THEN 'CreditDisbursed,Loan,Loan,Reducing,STAND'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'UKREDN'									THEN 'CreditDisbursed,Loan,Loan,Revolving,UKREDN'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'UKREDN'									THEN 'CreditDisbursed,Loan,Loan,Reducing,UKREDN'

			-- cirr
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'CIRR'									THEN 'CreditFacility,Loan,Loan,Revolving,CIRR'
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'CIRR'									THEN 'CreditFacility,Loan,Loan,Reducing,CIRR'
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'CIRR'									THEN 'CreditDisbursed,Loan,Loan,Revolving,CIRR'
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'CIRR'									THEN 'CreditDisbursed,Loan,Loan,Reducing,CIRR'

			--purrec
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RV'		AND @ssptl3 = 'PURREC'									THEN 'CreditFacility,Loan,Loan,Revolving,PURREC'
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM' AND @revRed = 'RD'		AND @ssptl3 = 'PURREC'									THEN 'CreditFacility,Loan,Loan,Reducing,PURREC'
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'PURREC'									THEN 'CreditDisbursed,Loan,Loan,Revolving,PURREC'
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'PURREC'									THEN 'CreditDisbursed,Loan,Loan,Reducing,PURREC'

			--billex
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RV'		AND @ssptl3 = 'BILLEX'									THEN 'CreditDisbursed,Loan,Loan,Revolving,BILLEX'
			--WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'PURREC'									THEN 'CreditDisbursed,Loan,Loan,Reducing,BILLEX'
			WHEN @is = 5		AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLDD' AND @revRed = 'RD'		AND @ssptl3 = 'BILLEX'									THEN 'CreditDisbursed,Loan,Loan,Reducing,BILLEX' -- 2012-09-18, H.Winther, changed to billex


			-- CL som är garantier
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM'						AND @ssptl3 = 'GARANT'									THEN 'Guarantee,PlainGuarantee,PlainGuarantee,PlainGuarantee,GARANT'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'CL'		AND @ssptl2 = 'CLCM'						AND @ssptl3 = 'PERGAR'									THEN 'Guarantee,PerformanceGuarantee,PerformanceGuarantee,PerformanceGuarantee,PERGAR'

			WHEN @is IN (0, 5)	AND @ssptl1 = 'FEES'	AND @ssptl2 = 'FEES'						AND @ssptl3 = 'FEE'										THEN 'Fee,Fee,Fee,Fee,Fee'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'FXMK'	AND @ssptl2 = 'FXMK'						AND @ssptl3 = 'FX'										THEN 'Technical,FXMK,FXMK,FXMK,FXMK'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'MMDP'	AND @ssptl2 = 'MMDP'						AND @ssptl3 = 'DPEX'	AND @ssptl4 LIKE 'CASH%'		THEN 'Collateral,CashCollateral,CashCollateral,CashCollateral,DPEX'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'MMDP'	AND @ssptl2 = 'MMDP'						AND @ssptl3 = 'DPEX'									THEN 'Deposit,Deposit,Deposit,Deposit,DPEX'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'MMLN'	AND @ssptl2 = 'MMLN'						AND @ssptl3 = 'LNEX'	AND @ssptl4 LIKE 'CASH%'		THEN 'Collateral,CashCollateral,CashCollateral,CashCollateral,LNEX'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'MMLN'	AND @ssptl2 = 'MMLN'						AND @ssptl3 = 'LNEX'									THEN 'Deposit,Deposit,Deposit,Deposit,LNEX'
			WHEN @is IN (0, 5)	AND @ssptl1 = 'MMLN'	AND @ssptl2 = 'MMLN'						AND @ssptl3 = 'SPRM'									THEN 'Collateral,CashCollateral,CashCollateral,CashCollateral,SPRM'
			-- MxG
			WHEN @is = 1	AND @ssptl1 = 'CRD'		AND @ssptl2 = 'CDS'	AND COALESCE(@typology, '') NOT IN ('Bond_GL', 'Bond_GF')							THEN 'Derivative,CreditDerivative,CreditDefaultSwap,CreditDefaultSwap,CRD'
			WHEN @is = 1	AND @ssptl1 = 'CRD'		AND @ssptl2 = 'CDS'	AND COALESCE(@typology, '') =  'Bond_GL'											THEN 'Derivative,CreditDerivative,CreditDefaultSwap,Guarantee,CRD'
			WHEN @is = 1	AND @ssptl1 = 'CRD'		AND @ssptl2 = 'CDS'	AND COALESCE(@typology, '') =  'Bond_GF'											THEN 'Guarantee,Guarantee,Guarantee,Guarantee,CDS'

			WHEN @is = 1	AND @ssptl1 = 'CRD'		AND @ssptl2 = 'FDB'																					THEN 'Derivative,CreditDerivative,FirstDefaultBasket,FirstDefaultBasket,CRD'
			WHEN @is = 1	AND @ssptl1 = 'CRD'		AND @ssptl2 = 'NDB'																					THEN 'Derivative,CreditDerivative,NthDefaultBasket,NthDefaultBasket,CRD'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'FXD'							AND @ssptl3 = 'FXD'										THEN 'Derivative,Forex,FxSpotForward,FxSpotForward,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'FXD'							AND @ssptl3 = 'FXDS'									THEN 'Derivative,Forex,FxPlain,FxPlain,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'FXD'							AND @ssptl3 = 'XSW'										THEN 'Derivative,Forex,ForexSwap,ForexSwapXSW,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'FXD'							AND @ssptl3 = 'SWLEG'									THEN 'Derivative,Forex,ForexSwap,ForexSwapXSW,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'BAR'										THEN 'Derivative,Option,SimpleBarrier,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'BAR'										THEN 'Derivative,Option,SimpleBarrier,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'BSK'										THEN 'Derivative,Option,BasketOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'BSK'										THEN 'Derivative,Option,BasketOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'SMP'										THEN 'Derivative,Option,SimpleOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'SMP'										THEN 'Derivative,Option,SimpleOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'ASN'										THEN 'Derivative,Option,AsianOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'ASN'										THEN 'Derivative,Option,AsianOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'BAR2'									THEN 'Derivative,Option,DoubleBarrier,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'BAR2'									THEN 'Derivative,Option,DoubleBarrier,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'BOF'										THEN 'Derivative,Option,BestOfOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'BOF'										THEN 'Derivative,Option,BestOfOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'CMP'										THEN 'Derivative,Option,CompoundOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'CMP'										THEN 'Derivative,Option,CompoundOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'FLEX'									THEN 'Derivative,Option,FlexibleDeal,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'FLEX'									THEN 'Derivative,Option,FlexibleDeal,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'KIKO'									THEN 'Derivative,Option,KikoBarrier,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'KIKO'									THEN 'Derivative,Option,KikoBarrier,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'LKB'										THEN 'Derivative,Option,LookbackOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'LKB'										THEN 'Derivative,Option,LookbackOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'LST'										THEN 'Derivative,Option,ListedOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'LST'										THEN 'Derivative,Option,ListedOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'RBT'										THEN 'Derivative,Option,TouchRebate,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'RBT'										THEN 'Derivative,Option,TouchRebate,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'RBTS'									THEN 'Derivative,Option,StripOfTouchRebate,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'RBTS'									THEN 'Derivative,Option,StripOfTouchRebate,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'SMPS'									THEN 'Derivative,Option,StripOfSimpleOption,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'SMPS'									THEN 'Derivative,Option,StripOfSimpleOption,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'STRA'									THEN 'Derivative,Option,OptionOnStrategy,Put,CURR'
			WHEN @is = 1	AND @ssptl1 = 'CURR'	AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'STRA'									THEN 'Derivative,Option,OptionOnStrategy,Call,CURR'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'ASI'										THEN 'Derivative,Option,AsianOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'ASI'										THEN 'Derivative,Option,AsianOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'BAR'										THEN 'Derivative,Option,BarrierOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'BAR'										THEN 'Derivative,Option,BarrierOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'OTC'										THEN 'Derivative,Option,OTCOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'OTC'										THEN 'Derivative,Option,OTCOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'RAT'										THEN 'Derivative,Option,RatchetOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'RAT'										THEN 'Derivative,Option,RatchetOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'LAD'										THEN 'Derivative,Option,LadderOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'LAD'										THEN 'Derivative,Option,LadderOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'FLEX'									THEN 'Derivative,Option,FlexOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'FLEX'									THEN 'Derivative,Option,FlexOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'LKB'										THEN 'Derivative,Option,LookbackOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'LKB'										THEN 'Derivative,Option,LookbackOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Put'	AND @ssptl3 = 'ORG'										THEN 'Derivative,Option,ListedOption,Put,EQD'
			WHEN @is = 1	AND @ssptl1 = 'EQD'		AND @ssptl2 = 'OPT' AND @putCall = 'Call'	AND @ssptl3 = 'ORG'										THEN 'Derivative,Option,ListedOption,Call,EQD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'ASWP'																				THEN 'Derivative,AssetSwap,AssetSwap,AssetSwap,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'BOND'						AND @ssptl3 = 'FWD'										THEN 'Bond,BondForward,BondForward,BondForward,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'BOND'						AND @ssptl3 = 'CALL'									THEN 'Bond,BondCallable,BondCallable,BondCallable,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'BOND'						AND @ssptl3 = 'REPO'									THEN 'Bond,BondRepo,BondRepo,BondRepo,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'BOND'																				THEN 'Bond,BondPlain,BondPlain,BondPlain,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'CD'																					THEN 'Collateral,CashCollateral,CallDeposit,CallDeposit,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'CF' THEN
				CASE
					WHEN @packType LIKE '%SWAP%MTM%' THEN
						CASE
							WHEN @capFloor = 'Cap'																										THEN 'Collateral,MTMRewriteCollateral,MTMRewriteCF,Cap,IRD'
							WHEN @capFloor = 'Floor'																									THEN 'Collateral,MTMRewriteCollateral,MTMRewriteCF,Floor,IRD'
						END
					ELSE
						CASE
							WHEN @capFloor = 'Cap'																										THEN 'Derivative,CapFloor,Cap,Cap,IRD'
							WHEN @capFloor = 'Floor'																									THEN 'Derivative,CapFloor,Floor,Floor,IRD'
							WHEN @capFloor = 'Generic'																									THEN 'Derivative,CapFloor,Generic,Generic,IRD'
						END
				END
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'CS'																					THEN 'Derivative,CurrencySwap,CurrencySwap,CurrencySwap,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'FRA'																					THEN 'Derivative,ForwardRate,ForwardRate,ForwardRate,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'IRS'																					THEN 
				CASE
					WHEN @packType LIKE '%SWAP%MTM%'																									THEN 'Collateral,MTMRewriteCollateral,MTMRewriteIRS,MTMRewriteIRS,IRD'
																																						ELSE 'Derivative,InterestRateSwap,InterestRateSwap,InterestRateSwap,IRD'
				END
			WHEN @is = 1 AND @ssptl1 = 'IRD'	AND @ssptl2 = 'LN_BR' THEN 
				CASE
					WHEN @packType LIKE '%SWAP%MTM%'																									THEN 'Collateral,MTMRewriteCollateral,MTMRewriteLNBR,MTMRewriteLNBR,IRD'
					WHEN @ssptl4 = 'FXSWP_INTEREST' /* AND @portfolio IN ('FXSWP_INTEREST','IRRISK','LOAN','FXRISK','FUNDEMMA') */						THEN 'Derivative,Forex,ForexSwap,ForexSwapLNBR,IRD'
					WHEN @typology LIKE 'Rewrite%'																										THEN 'Derivative,HedgeRewriteLNBR,HedgeRewriteLNBR,HedgeRewriteLNBR,IRD'
																																						ELSE 'Deposit,Deposit,Deposit,Deposit,IRD'
				END
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OSWP'																				THEN 'Derivative,Swaption,Swaption,Swaption,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'SFUT'																				THEN 'Derivative,ShortFuture,ShortFuture,ShortFuture,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Put'	AND @ssptl3 = 'ASI'										THEN 'Derivative,Option,AsianOption,Put,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Call'	AND @ssptl3 = 'ASI'										THEN 'Derivative,Option,AsianOption,Call,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Put'	AND @ssptl3 = 'BAR'										THEN 'Derivative,Option,BarrierOption,Put,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Call'	AND @ssptl3 = 'BAR'										THEN 'Derivative,Option,BarrierOption,Call,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Put'	AND @ssptl3 = 'FLEX'									THEN 'Derivative,Option,FlexOption,Put,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Call'	AND @ssptl3 = 'FLEX'									THEN 'Derivative,Option,FlexOption,Call,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Put'	AND @ssptl3 = 'LAD'										THEN 'Derivative,Option,LadderOption,Put,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Call'	AND @ssptl3 = 'LAD'										THEN 'Derivative,Option,LadderOption,Call,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Put'	AND @ssptl3 = 'ORG'										THEN 'Derivative,Option,InterestRateFutureOption,Put,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Call'	AND @ssptl3 = 'ORG'										THEN 'Derivative,Option,InterestRateFutureOption,Call,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Put'	AND @ssptl3 = 'OTC'										THEN 'Derivative,Option,BondOptions,Put,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Call'	AND @ssptl3 = 'OTC'										THEN 'Derivative,Option,BondOptions,Call,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Put'	AND @ssptl3 = 'RAT'										THEN 'Derivative,Option,RatchetOptions,Put,IRD'
			WHEN @is = 1	AND @ssptl1 = 'IRD'		AND @ssptl2 = 'OPT'	AND @putCall = 'Call'	AND @ssptl3 = 'RAT'										THEN 'Derivative,Option,RatchetOptions,Call,IRD'
			WHEN @is = 1    AND @ssptl1 = 'SCF'     AND @ssptl2 = 'SCF'	AND @ssptl3  = 'SCF'                                                            THEN 'Derivative,SimpleCashFlow,SimpleCashFlow,SimpleCashFlow,SCF'
			-- ProFinance
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Credit'				AND @ssptl3 = 'HP'	AND @ssptl4 = 'Disbursed'			THEN 'CreditDisbursed,Loan,Loan,Loan,HP'
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Credit'				AND @ssptl3 = 'SC'	AND @ssptl4 = 'Disbursed'			THEN 'CreditDisbursed,Loan,Loan,Loan,SC'
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Leasing'				AND @ssptl3 = 'F'	AND @ssptl4 = 'Disbursed'			THEN 'CreditDisbursed,Leasing,FinancialLease,FinancialLease,F'
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Leasing'				AND @ssptl3 = 'L'	AND @ssptl4 = 'Disbursed'			THEN 'CreditDisbursed,Leasing,OperationalLease,OperationalLease,L'
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Credit'				AND @ssptl3 = 'HP'	AND @ssptl4 = 'Facility'			THEN 'CreditFacility,Loan,Loan,Loan,HP'
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Credit'				AND @ssptl3 = 'SC'	AND @ssptl4 = 'Facility'			THEN 'CreditFacility,Loan,Loan,Loan,SC'
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Leasing'				AND @ssptl3 = 'F'	AND @ssptl4 = 'Facility'			THEN 'CreditFacility,Leasing,FinancialLease,FinancialLease,F'
			WHEN @is = 3	AND @ssptl1 = 'ContractLine'	AND @ssptl2 = 'Leasing'				AND @ssptl3 = 'L'	AND @ssptl4 = 'Facility'			THEN 'CreditFacility,Leasing,OperationalLease,OperationalLease,L'
			WHEN @is = 3	AND @ssptl1 = 'FrameAgreement'	AND @ssptl2 = ''																			THEN 'FrameAgreement,FrameAgreement,FrameAgreement,FrameAgreement,FrameAgreement'
			-- Okänd produktkombination
																																						ELSE 'Unknown,Unknown,Unknown,Unknown,Unknown'
		END

    INSERT INTO @contractType (level1, level2, level3, level4, level5)
      SELECT 
         SUBSTRING(@type, 1, CHARINDEX(',', @type, 1) - 1) AS Level1,
         SUBSTRING(@type, CHARINDEX(',', @type, 1) + 1, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) - 1 - CHARINDEX(',', @type, 1)) AS Level2,
         SUBSTRING(@type, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) + 1, CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) + 1) - 1 - CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1)) AS Level3,
         SUBSTRING(@type, CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) + 1) + 1, CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) + 1) + 1) - 1 - CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) + 1)) AS Level4,
         SUBSTRING(@type, CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) + 1) + 1) + 1, LEN(@type) - CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, CHARINDEX(',', @type, 1) + 1) + 1) + 1)) AS Level5

   RETURN

END
GO