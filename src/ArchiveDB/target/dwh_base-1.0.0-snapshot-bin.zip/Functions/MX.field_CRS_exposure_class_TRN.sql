--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_exposure_class_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_exposure_class_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_exposure_class_TRN](@mxContractType varchar(10)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_exposure_class_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_exposure_class_TRN]
(
	@mxContractType varchar(10)
)
RETURNS varchar(5)
AS
BEGIN
	RETURN
			CASE
			WHEN @mxContractType = 'ASWP' THEN 'SWAP'
            WHEN @mxContractType = 'BOND' THEN 'BOND'
            WHEN @mxContractType = 'CD' THEN 'COLL'
            WHEN @mxContractType = 'CDS' THEN 'CDS'
            WHEN @mxContractType = 'CS' THEN 'SWAP'
            WHEN @mxContractType = 'FRA' THEN 'FRA'
            WHEN @mxContractType = 'FUT' THEN 'FUT'
            WHEN @mxContractType = 'FXD' THEN 'FX'
            WHEN @mxContractType = 'IRS' THEN 'SWAP'
            WHEN @mxContractType = 'LN_BR' THEN 'LNBR'
            WHEN @mxContractType = 'REPO' THEN 'REPO'
            WHEN @mxContractType = 'OPT' THEN 'OPT'
            WHEN @mxContractType = 'FXD' THEN 'FX'
            WHEN @mxContractType = 'FDB' THEN 'FDB'
            WHEN @mxContractType = 'NDB' THEN 'NDB'

		ELSE NULL
		END
END
GO