--liquibase formatted sql

--changeSet func:Initial-MX3-field_cap_floor-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_cap_floor', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_cap_floor](@mxContractType varchar(10),@OPSOW_M_EQ_CAP_F int,@PL_M_TP_CP varchar(1)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_cap_floor-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_cap_floor]
(
	@mxContractType varchar(10)
  , @OPSOW_M_EQ_CAP_F int
  , @PL_M_TP_CP varchar(1)
)
RETURNS VARCHAR(1)
AS
BEGIN
    RETURN
        CASE 
            WHEN @mxContractType IN ('ASWP', 'CF') THEN NULLIF(@PL_M_TP_CP, '')
            WHEN @OPSOW_M_EQ_CAP_F = 1 THEN 'C'
            WHEN @OPSOW_M_EQ_CAP_F = 0 THEN 'F'
            ELSE NULL
        END
END
GO