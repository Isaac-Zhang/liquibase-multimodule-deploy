--liquibase formatted sql

--changeSet func:Initial-MX-field_payOrReceive-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_payOrReceive', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_payOrReceive](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTPR0 varchar(1),@PL_M_TP_RTPR1 varchar(1)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_payOrReceive-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
-- User Defined Function
ALTER FUNCTION  [MX].[field_payOrReceive]
(
    @mxContractType varchar(10), 
    @COM_leg_LEG int,
    @PL_M_TP_RTPR0 varchar(1),
    @PL_M_TP_RTPR1 varchar(1)
)
RETURNS varchar(1)
AS
BEGIN
    RETURN
        CASE
            ---------------------------------------------------- CRS_ASWP ----------------------------------------------------
	        ---------------------------------------------------- CRS_CS ----------------------------------------------------
	        ---------------------------------------------------- CRS_IRS ----------------------------------------------------
	        WHEN @mxContractType IN ('ASWP', 'CS', 'IRS','OSWP') THEN
		        CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTPR0
	                ELSE @PL_M_TP_RTPR1
	            END
	        ---------------------------------------------------- CRS_BOND ----------------------------------------------------
	        ---------------------------------------------------- CRS_FUT ----------------------------------------------------
	        ---------------------------------------------------- CRS_REPO ----------------------------------------------------
	        WHEN @mxContractType IN ('BOND', 'REPO') THEN @PL_M_TP_RTPR0
	        ---------------------------------------------------- CRS_CD ----------------------------------------------------
	        WHEN @mxContractType = 'CD' THEN @PL_M_TP_RTPR0
	        ---------------------------------------------------- CRS_CDS ----------------------------------------------------
	        WHEN @mxContractType = 'CDS' THEN @PL_M_TP_RTPR0
	        ---------------------------------------------------- CRS_FRA ----------------------------------------------------
	        WHEN @mxContractType = 'FRA' THEN
		        CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTPR0
	                ELSE @PL_M_TP_RTPR1
	            END
	        ---------------------------------------------------- CRS_FXD ----------------------------------------------------
	        ---------------------------------------------------- CRS_XSW ----------------------------------------------------
	        WHEN @mxContractType IN ('FXD', 'XSW', 'FUT') THEN NULL
		        --CASE
          --          WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTPR0
	         --       ELSE @PL_M_TP_RTPR1
	         --   END
	        ---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
	        WHEN @mxContractType = 'LN_BR' THEN @PL_M_TP_RTPR0
        ELSE NULL
    END
END
GO