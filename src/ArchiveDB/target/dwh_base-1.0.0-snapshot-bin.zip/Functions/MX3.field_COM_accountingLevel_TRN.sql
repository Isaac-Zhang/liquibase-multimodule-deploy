--liquibase formatted sql

--changeSet func:Initial-MX3-field_COM_accountingLevel_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_COM_accountingLevel_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_COM_accountingLevel_TRN](@COM_contractFamily varchar(10),@EQD_M_L_ACCLEVEL varchar(16),@IRD_M_L_ACCLEVEL varchar(16),@CURR_M_L_ACCLEVEL varchar(16),@CRD_M_ACCLEVEL varchar(16)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_COM_accountingLevel_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_COM_accountingLevel_TRN](
@COM_contractFamily varchar(10), 
@EQD_M_L_ACCLEVEL VARCHAR(16),
@IRD_M_L_ACCLEVEL VARCHAR(16),
@CURR_M_L_ACCLEVEL VARCHAR(16),
@CRD_M_ACCLEVEL VARCHAR(16)

)
RETURNS VARCHAR(16)
AS
BEGIN
  RETURN
           CASE
                             ---- EQD ----
                      WHEN @COM_contractFamily = 'EQD'  THEN
                                 @EQD_M_L_ACCLEVEL
                ---- IRD ----
        WHEN @COM_contractFamily = 'IRD'  THEN
                                 @IRD_M_L_ACCLEVEL
                ---- CURR ----
                      WHEN @COM_contractFamily = 'CURR' THEN
                                 @CURR_M_L_ACCLEVEL
                                     ---- CRD ----
                      WHEN @COM_contractFamily = 'CRD' THEN
                                 @CRD_M_ACCLEVEL     
                ELSE NULL
                                 
           END
END
GO