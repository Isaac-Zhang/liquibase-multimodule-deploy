--liquibase formatted sql

--changeSet func:Initial-DWH-get_H_SiblingsByShortName-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_H_SiblingsByShortName', 'TF') IS NULL EXEC('CREATE FUNCTION [DWH].[get_H_SiblingsByShortName](@shortName varchar(15),@reportDate datetime) RETURNS @tab TABLE ([ID] int,[Shortname] varchar(20),[counterpartIdentity] numeric(10,0),[counterpartPath] varchar(MAX)) AS BEGIN RETURN END')
GO



--changeSet func:Initial-DWH-get_H_SiblingsByShortName-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[get_H_SiblingsByShortName] (  @shortName  VARCHAR (15)
												    , @reportDate DATETIME )
  RETURNS @siblings
  TABLE (
			ID					INT				NULL, 
			Shortname			VARCHAR(20)		NULL, 
			counterpartIdentity NUMERIC(10, 0)	NULL,
			counterpartPath		VARCHAR(MAX)	NULL
		)
  AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @siblings					 TABLE			   Table of siblings to counterpart with 
  -- !																				   shortname equal to supplied @shortName
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !                                   @shortName					 VARCHAR (20)      The shortname of the counterpart to get risk 
  -- !																				   counterpart for.
  -- !                                   @reportDate                 DATETIME          The date on which the procedure will act.
  -- !
  -- ! O b j e c t i v e :				 Returns a table of the sibling counterparts.
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-02-25      JoJo    Initial version by JoJo
  -- !
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
  BEGIN
  --
     WITH TAB AS (
      SELECT CP.ID, CP.shortname, CP.counterpartIdentity, CH.counterpartIDPath, CH.parentCounterpartIDPath
      FROM DWH.counterpartHierarchy CH
      INNER JOIN DWH.counterpart CP ON CH._counterpart_ID = CP.ID
      WHERE CP.reportDate = @reportDate
   )
	INSERT INTO @siblings(ID, Shortname, counterpartIdentity, counterpartPath)
	SELECT sibling.ID, sibling.Shortname, sibling.counterpartIdentity, sibling.counterpartIDPath.ToString() AS counterpartPath
	  FROM TAB sibling
		INNER JOIN TAB parent ON sibling.parentCounterpartIDPath = parent.counterpartIDPath 
	 WHERE parent.Shortname = DWH.get_H_AncestorByShortname(0, @shortName, @reportDate)
	--
	RETURN;
  --
  END
GO