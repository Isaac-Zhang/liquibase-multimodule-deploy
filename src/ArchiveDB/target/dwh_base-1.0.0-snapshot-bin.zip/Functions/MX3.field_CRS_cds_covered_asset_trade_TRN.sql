--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_cds_covered_asset_trade_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_cds_covered_asset_trade_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_cds_covered_asset_trade_TRN](@mxContractType varchar(10),@CRD_M_TRN_NB varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_cds_covered_asset_trade_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_cds_covered_asset_trade_TRN]
(
	@mxContractType varchar(10), 
	@CRD_M_TRN_NB varchar(20)
)
RETURNS varchar(45)
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType = 'CDS' THEN @CRD_M_TRN_NB ELSE NULL END
END
GO