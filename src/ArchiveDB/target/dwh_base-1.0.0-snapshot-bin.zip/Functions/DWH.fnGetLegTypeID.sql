--liquibase formatted sql

--changeSet func:Initial-DWH-fnGetLegTypeID-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnGetLegTypeID', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnGetLegTypeID](@assetOrLiability varchar(1),@buyOrSell varchar(1),@payOrRecieve varchar(1),@spotForward varchar(1)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnGetLegTypeID-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.fnGetLegTypeID 
(	
	@assetOrLiability VARCHAR(1), 
	@buyOrSell VARCHAR(1),
	@payOrRecieve VARCHAR(1),
    @spotForward VARCHAR(1)
)
RETURNS TABLE 
AS
RETURN 
(
	SELECT lt.ID 
	FROM DWH.LKP_Legtype lt
	WHERE 
		lt.assetOrLiability	= COALESCE(@assetOrLiability ,'-')
		AND lt.buyOrSell		= COALESCE(@buyOrSell,'-')
		AND lt.payOrReceive	= COALESCE(@payOrRecieve,'-')
        AND lt.spotForward = COALESCE(@spotForward, '-')
)
--GO
GO