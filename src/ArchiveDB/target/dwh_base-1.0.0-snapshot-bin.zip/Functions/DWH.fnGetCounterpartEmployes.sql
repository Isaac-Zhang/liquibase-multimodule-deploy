--liquibase formatted sql

--changeSet func:Initial-DWH-fnGetCounterpartEmployes-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnGetCounterpartEmployes', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnGetCounterpartEmployes](@reportDate date,@counterPartIdentity varchar(8)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnGetCounterpartEmployes-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.fnGetCounterpartEmployes(@reportDate DATE, @counterPartIdentity varchar(8))
RETURNS TABLE 
AS
RETURN
(
SELECT 
      c.[counterpartIdentity],
      roleType				= lert.[descr],
      roleName				= ler.[descr],
      mailAdress			= LOWER(le.[shortName] + '@sek.se'),
      le.[firstName],
      le.[lastName]
  FROM [DWH_BASE].[DWH].[counterpartEmployee] ce
  INNER JOIN [DWH_BASE].[DWH].[counterpart] AS C ON [ce].[_counterpart_ID] = [C].[ID]
  INNER JOIN [DWH].[LKP_employeeRole] AS LER ON ce.[_employeeRole_ID] = ler.[ID]
  INNER JOIN dwh.[LKP_employee] AS LE ON ce.[_employee_ID] = le.id
  INNER JOIN dwh.[LKP_employeeRoleType] AS LERT ON ce.[_employeeRoleType_ID] = lert.[ID]
  WHERE (1=1)
   AND LERT.employeeRoleType = 'none'
	AND c.reportDate = @reportDate
	AND 
		(
			c.counterpartIdentity = @counterPartIdentity
			OR @counterPartIdentity IS NULL
		)
)
GO