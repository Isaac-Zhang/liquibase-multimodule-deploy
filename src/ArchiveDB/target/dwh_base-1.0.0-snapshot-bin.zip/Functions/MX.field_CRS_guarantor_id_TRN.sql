--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_guarantor_id_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_guarantor_id_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_guarantor_id_TRN](@mxContractType varchar(10),@IRD_M_GUARANTOR varchar(25),@CRD_M_GUARANTOR varchar(25),@CNTRP_IRD_M_ID numeric(10,0),@CNTRP_SEC_M_ID numeric(10,0),@CNTRP_CRD_M_ID numeric(10,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_guarantor_id_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_guarantor_id_TRN]
(
	@mxContractType varchar(10), 
    @IRD_M_GUARANTOR varchar(25),
    @CRD_M_GUARANTOR varchar(25),
    @CNTRP_IRD_M_ID numeric(10,0),
    @CNTRP_SEC_M_ID numeric(10,0),
    @CNTRP_CRD_M_ID numeric(10,0)
)
RETURNS numeric(10,0)
AS
BEGIN
	RETURN
        CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'BOND', 'CD', 'CS', 'FRA', 'FUT', 'FXD', 'IRS', 'LN_BR', 'REPO', 'XSW', 'CF') THEN 
                CASE --IIF(ISBLANK(GUAR_DEAL)=0, NTBLFIELD('TRN_CPDF.ID','LABEL',TRIM(GUAR_DEAL)), NTBLFIELD('TRN_CPDF.ID','LABEL',TRIM(GUAR_SEC)))
				    WHEN LTRIM(RTRIM(@IRD_M_GUARANTOR))<>'' THEN @CNTRP_IRD_M_ID ELSE @CNTRP_SEC_M_ID END
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType = 'CDS'
			THEN CASE --IIF(ISBLANK(GUAR_DEAL)=0, NTBLFIELD('TRN_CPDF.ID','LABEL',TRIM(GUAR_DEAL)), NTBLFIELD('TRN_CPDF.ID','LABEL',TRIM(GUAR_SEC)))
				WHEN LTRIM(RTRIM(@CRD_M_GUARANTOR))<>''
			THEN @CNTRP_CRD_M_ID
			ELSE @CNTRP_SEC_M_ID
			END
		ELSE NULL
		END
END
GO