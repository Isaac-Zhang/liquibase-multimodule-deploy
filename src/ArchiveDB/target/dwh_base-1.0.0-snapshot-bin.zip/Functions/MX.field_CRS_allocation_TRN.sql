--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_allocation_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_allocation_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_allocation_TRN](@mxContractType varchar(10),@CRD_M_ALLOCATE varchar(45)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_allocation_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_allocation_TRN]
(
	@mxContractType VARCHAR(10),
    @CRD_M_ALLOCATE VARCHAR(45)
)
RETURNS VARCHAR(45)
AS
BEGIN
    RETURN
        CASE WHEN @mxContractType = 'CDS' THEN @CRD_M_ALLOCATE ELSE NULL END
END
GO