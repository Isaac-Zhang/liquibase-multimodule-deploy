--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_potential_risk-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_potential_risk', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_potential_risk](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@reportDate date,@PL_M_TP_BUY varchar(1),@PL_M_TP_RTFV0 varchar(1),@PL_M_TP_RTFV1 varchar(1),@PL_M_TP_RTMAT0 datetime,@PL_M_TP_RTDXC02 datetime,@PL_M_TP_RTMAT1 datetime,@PL_M_TP_RTDXC12 datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_RTDXG02 datetime,@PL_M_TP_DTEFLWL datetime,@PL_M_XARC_DATE datetime,@PL_M_TP_RTCCP02 numeric(19,2),@PL_M_TP_RTCCP12 numeric(19,2),@PL_M_TP_NOMINAL numeric(19,2),@PL_M_TP_LQTY2 numeric(24,8),@PL_M_TP_LQTYS2 numeric(24,8),@PL_M_TP_SECLOT numeric(17,6),@PL_M_TP_PRICE numeric(23,6),@PL_M_TP_QTYEQ numeric(24,8),@PL_M_TP_RTCCP01 numeric(19,2),@PL_M_TP_RPO_AMT numeric(16,2),@PL_M_TP_RPOAMT2 numeric(16,2)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_potential_risk-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_potential_risk]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @reportDate date,

    -- term remain
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTFV0 varchar(1),
    @PL_M_TP_RTFV1 varchar(1),
    @PL_M_TP_RTMAT0 datetime,
    @PL_M_TP_RTDXC02 datetime,
    @PL_M_TP_RTMAT1 datetime,
    @PL_M_TP_RTDXC12 datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_RTDXG02 datetime,
    @PL_M_TP_DTEFLWL datetime ,
    @PL_M_XARC_DATE datetime,

    -- nominal amount
    @PL_M_TP_RTCCP02 numeric(19,2),
    @PL_M_TP_RTCCP12 numeric(19,2),
    @PL_M_TP_NOMINAL numeric(19,2),
    @PL_M_TP_LQTY2 numeric(24,8),
    @PL_M_TP_LQTYS2 numeric(24,8),
    @PL_M_TP_SECLOT numeric(17,6),
    @PL_M_TP_PRICE numeric(23,6),
    @PL_M_TP_QTYEQ numeric(24,8),
    @PL_M_TP_RTCCP01 numeric(19,2),
    @PL_M_TP_RPO_AMT numeric(16,2),
    @PL_M_TP_RPOAMT2 numeric(16,2)

)
RETURNS numeric(28,8)
AS
BEGIN

    DECLARE @XOR_term_remain int;
    DECLARE @XOR_nominal_amount numeric(28,8);

    SELECT @XOR_term_remain =
        MX.field_XOR_term_remain(
            @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
            @COM_leg_LEG, @COM_quantityIndex_TRN, @reportDate,            
            @PL_M_TP_BUY, @PL_M_TP_RTFV0, @PL_M_TP_RTFV1, @PL_M_TP_RTMAT0, @PL_M_TP_RTDXC02,
            @PL_M_TP_RTMAT1, @PL_M_TP_RTDXC12, @PL_M_TP_DTEEXP, @PL_M_TP_RTDXG02,
            @PL_M_TP_DTEFLWL, @PL_M_XARC_DATE);

    SELECT @XOR_nominal_amount =
        MX.field_XOR_nominal_amount(
            @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
            @COM_leg_LEG, @COM_quantityIndex_TRN,
            @PL_M_TP_BUY, @PL_M_TP_RTCCP02, @PL_M_TP_RTCCP12, @PL_M_TP_NOMINAL, 
            @PL_M_TP_LQTY2, @PL_M_TP_LQTYS2, @PL_M_TP_SECLOT, @PL_M_TP_PRICE,
            @PL_M_TP_QTYEQ, @PL_M_TP_RTCCP01, @PL_M_TP_RPO_AMT, @PL_M_TP_RPOAMT2);


	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TERM_REM<1*365,0.00*NOM_AMOUNT, IIF(TERM_REM<5*365,0.005*NOM_AMOUNT, 0.015*NOM_AMOUNT))
			WHEN @XOR_term_remain < 365
			THEN 0 * @XOR_nominal_amount
			WHEN @XOR_term_remain < 5 * 365
			THEN 0.005 * @XOR_nominal_amount
			ELSE 0.015 * @XOR_nominal_amount
			END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN 0
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TERM_REM<1*365,0.00*NOM_AMOUNT, IIF(TERM_REM<5*365,0.005*NOM_AMOUNT, 0.015*NOM_AMOUNT))
			WHEN @XOR_term_remain < 365
			THEN 0 * @XOR_nominal_amount
			WHEN @XOR_term_remain < 5 * 365
			THEN 0.005 * @XOR_nominal_amount
			ELSE 0.015 * @XOR_nominal_amount
			END
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TERM_REM<1*365,0.00*NOM_AMOUNT, IIF(TERM_REM<5*365,0.005*NOM_AMOUNT, 0.015*NOM_AMOUNT))
			WHEN @XOR_term_remain < 365
			THEN 0 * @XOR_nominal_amount
			WHEN @XOR_term_remain < 5 * 365
			THEN 0.005 * @XOR_nominal_amount
			ELSE 0.015 * @XOR_nominal_amount
			END
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN
			CASE --IIF(TERM_REM<1*365,0.01*NOM_AMOUNT, IIF(TERM_REM<5*365,0.05*NOM_AMOUNT, 0.075*NOM_AMOUNT))
			WHEN @XOR_term_remain < 365
			THEN 0.01 * @XOR_nominal_amount
			WHEN @XOR_term_remain < 5 * 365
			THEN 0.05 * @XOR_nominal_amount
			ELSE 0.075 * @XOR_nominal_amount
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TERM_REM<1*365,0.00*NOM_AMOUNT, IIF(TERM_REM<5*365,0.005*NOM_AMOUNT, 0.015*NOM_AMOUNT))
			WHEN @XOR_term_remain < 365
			THEN 0 * @XOR_nominal_amount
			WHEN @XOR_term_remain < 5 * 365
			THEN 0.005 * @XOR_nominal_amount
			ELSE 0.015 * @XOR_nominal_amount
			END
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TERM_REM<1*365,0.06*NOM_AMOUNT, IIF(TERM_REM<5*365,0.08*NOM_AMOUNT, 0.10*NOM_AMOUNT))
			WHEN @XOR_term_remain < 365
			THEN 0.06 * @XOR_nominal_amount
			WHEN @XOR_term_remain < 5 * 365
			THEN 0.08 * @XOR_nominal_amount
			ELSE 0.1 * @XOR_nominal_amount
			END
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN 0
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
			THEN NULL
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN 0
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN 0
		ELSE NULL
		END
END
GO