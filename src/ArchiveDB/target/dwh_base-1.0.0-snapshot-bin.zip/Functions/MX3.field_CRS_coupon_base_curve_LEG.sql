--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_coupon_base_curve_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_coupon_base_curve_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_coupon_base_curve_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTMNDX0 varchar(20),@PL_M_TP_RTMNDX1 varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_coupon_base_curve_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- User Defined Function
ALTER FUNCTION  [MX3].[field_CRS_coupon_base_curve_LEG]
(
	@mxContractType varchar(10),
    @COM_leg_LEG int,
	@PL_M_TP_RTMNDX0 varchar(20),
    @PL_M_TP_RTMNDX1 varchar(20)
)
RETURNS varchar(20)
AS
BEGIN
	RETURN 
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP') THEN
				CASE 
                    WHEN @COM_leg_LEG = 1 THEN NULLIF(@PL_M_TP_RTMNDX0, '')
			        WHEN @COM_leg_LEG = 2 THEN NULLIF(@PL_M_TP_RTMNDX1, '')
			    ELSE NULL
			END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'LN_BR', 'REPO', 'CF') THEN NULLIF(@PL_M_TP_RTMNDX0, '')
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('CDS', 'FUT', 'FXD', 'XSW','SWLEG') THEN NULL
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			WHEN @mxContractType = 'FRA' THEN 
				CASE 
                    WHEN @COM_leg_LEG = 1 THEN NULLIF(@PL_M_TP_RTMNDX0, '')
			        WHEN @COM_leg_LEG = 2 THEN NULLIF(@PL_M_TP_RTMNDX1, '')
			    ELSE NULL
			END
		ELSE NULL

		END

END
GO