--liquibase formatted sql

--changeSet func:Initial-DWH-getCounterPartRoleID-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getCounterPartRoleID', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[getCounterPartRoleID](@role varchar(32)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-getCounterPartRoleID-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- =============================================
-- Author:		H.Winther
-- Create date: 2010-05-26
-- Description:	
-- =============================================
ALTER FUNCTION  DWH.getCounterPartRoleID 
(
	-- Add the parameters for the function here
	@role varchar(32)
)
RETURNS smallint
AS
BEGIN
	-- Declare the return variable here
	DECLARE @Result smallint

	-- Add the T-SQL statements to compute the return value here
	SELECT @Result = ID FROM DWH.LKP_counterPartRole WHERE roleName=@role

	-- Return the result of the function
	RETURN @Result

END
GO