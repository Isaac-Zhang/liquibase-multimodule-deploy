--liquibase formatted sql

--changeSet func:Initial-MX-field_RAW_entity-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_RAW_entity', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_RAW_entity](@PL_M_TP_ENTITY varchar(10)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_RAW_entity-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_RAW_entity]
(
	@PL_M_TP_ENTITY VARCHAR(10)
)
RETURNS VARCHAR(10)
AS
BEGIN
	RETURN @PL_M_TP_ENTITY
END
GO