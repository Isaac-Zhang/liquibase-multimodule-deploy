--liquibase formatted sql

--changeSet func:Initial-DWH-getRatings-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getRatings', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getRatings](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getRatings-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getRatings] (@reportDate date, @extractContext varchar(3))
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t           DWH.getRatings
  -- ! R e t u r n s         TABLE
  -- ! P a r a m e t e r s   Name, DataType, Description
  -- +                       =========================================================================================
  -- !                       @reportDate date
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e     Returns all the ratings and risk weights for all counterparts for a specific date
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !   S A M P L E
  -- !      SELECT * FROM [DWH].[getRatings] ('2013-01-15', 'eod')
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y         Date       Who  What
  -- +                       ========== ==== =========================================================================
  -- !                       2011-02-16 CHTH Initial version ...
  -- !							  2013-02-19 HAWI Added counterpartIdentity	
  -- + ---------------------------------------------------------------------------------------------------------------
RETURNS TABLE AS RETURN 
(
	SELECT 
		_counterpart_ID, 
		[SEK Internal Rating] AS sekInternalRating,
		[Fitch] AS fitchRating,
		[Moodys] AS moodysRating,
		[Standard & Poors] AS spRating,
		[Calculated rating] AS calcRating,
		[Secured rating] as securedRating,
		[Other rating] as otherRating,
		[ALMI] AS almiRating,
		[Computed rating] as computedRating,
		counterpartIdentity -- 2013-02-19, H.Winther, added counterpartIdentity
	FROM (
		  SELECT 
				CR._counterpart_ID, 
				rating, 
				organization, 
				c.counterpartIdentity
		  FROM DWH.counterpart C
		  INNER JOIN DWH.loadContext LC ON C._loadContext_ID = LC.ID
		  INNER JOIN DWH.counterpartRating CR ON C.ID = CR._counterpart_ID
		  INNER JOIN DWH.LKP_ratingMatrix RM ON CR._ratingMatrix_ID = RM.ID
		  INNER JOIN DWH.LKP_rating R ON RM._rating_ID = R.ID
		  INNER JOIN DWH.LKP_ratingOrganization RO ON RM._ratingOrganization_ID = RO.ID
		  WHERE 
				C.reportDate				= @reportDate 
				AND LC.extractContext	= @extractContext
				AND LC.[reportDate]		= @reportDate
	 ) AS P
	 PIVOT (
		  MIN(rating)
		  FOR organization IN ([SEK Internal Rating], [Fitch], [Moodys], [Standard & Poors], [Calculated rating],
				[Secured rating], [Other rating], [ALMI], [Computed rating])
	 ) AS pvt
)
GO