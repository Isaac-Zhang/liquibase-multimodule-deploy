--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_nominal_currency_orig_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_nominal_currency_orig_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_nominal_currency_orig_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTCUR0 varchar(3),@PL_M_TP_RTCUR1 varchar(3),@PL_M_TP_NOMCUR varchar(3),@PL_M_TP_FXUND varchar(3),@PL_M_TP_FXBASE varchar(3),@PL_M_QTY_INDEX numeric(3,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_nominal_currency_orig_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_nominal_currency_orig_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
    @PL_M_TP_RTCUR0 varchar(3),
    @PL_M_TP_RTCUR1 varchar(3),
    @PL_M_TP_NOMCUR varchar(3),
    @PL_M_TP_FXUND varchar(3),
    @PL_M_TP_FXBASE varchar(3),
    @PL_M_QTY_INDEX numeric(3,0)
)
RETURNS varchar(3)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP') THEN
				CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTCUR0
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTCUR1
			        ELSE NULL
			    END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_CD ----------------------------------------------------
            ---------------------------------------------------- CRS_CDS ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
            ---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
            ---------------------------------------------------- CRS_OPT ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'CDS', 'FUT', 'LN_BR', 'OPT', 'CF', 'FDB', 'NDB','SCF')
			THEN @PL_M_TP_NOMCUR
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
            ---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('FRA', 'REPO')
			THEN @PL_M_TP_RTCUR0
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType = 'FXD' THEN
				CASE
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_FXUND
                    WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_FXBASE
			        ELSE NULL
			END
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('XSW','SWLEG') THEN
	            CASE
			        WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 0) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 1) THEN @PL_M_TP_NOMCUR 
                    WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 1) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 0) THEN @PL_M_TP_FXBASE
			        ELSE NULL
			    END
		ELSE NULL
		END
END
GO