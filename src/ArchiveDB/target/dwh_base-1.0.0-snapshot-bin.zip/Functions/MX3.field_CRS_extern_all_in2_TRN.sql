--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_extern_all_in2_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_extern_all_in2_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_extern_all_in2_TRN](@mxContractType varchar(10),@IRD_M_EXTERN2 numeric(6,2),@CURR_M_EXTERN2 numeric(6,2)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_extern_all_in2_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_extern_all_in2_TRN]
(
	@mxContractType varchar(10), 
    @IRD_M_EXTERN2 numeric(6,2),
    @CURR_M_EXTERN2 numeric(6,2)

)
RETURNS numeric(6,2)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
            WHEN @mxContractType IN ('ASWP', 'BOND', 'CD', 'CS', 'FRA', 'FUT', 'IRS', 'LN_BR', 'REPO', 'OSWP'/*, 'CF'*/)
            THEN @IRD_M_EXTERN2
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('FXD', 'XSW','SWLEG')
			THEN @CURR_M_EXTERN2

		ELSE NULL
		END
END
GO