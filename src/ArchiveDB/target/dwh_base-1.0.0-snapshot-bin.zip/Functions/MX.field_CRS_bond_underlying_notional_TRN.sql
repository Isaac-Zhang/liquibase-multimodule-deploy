--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_bond_underlying_notional_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_bond_underlying_notional_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_bond_underlying_notional_TRN](@mxContractType varchar(10),@PL_M_TP_NOMINAL numeric(24,8),@PL_M_TP_IQTY numeric(24,8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_bond_underlying_notional_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_bond_underlying_notional_TRN]
(
	@mxContractType varchar(10),
	@PL_M_TP_NOMINAL numeric(24,8),
    @PL_M_TP_IQTY numeric(24,8)
)
RETURNS numeric(24,8)
AS
BEGIN
	RETURN
        CASE WHEN @mxContractType = 'REPO' THEN @PL_M_TP_NOMINAL * @PL_M_TP_IQTY ELSE NULL END
END
GO