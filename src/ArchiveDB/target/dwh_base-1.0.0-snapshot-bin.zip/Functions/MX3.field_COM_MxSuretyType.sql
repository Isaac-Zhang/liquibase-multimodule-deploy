--liquibase formatted sql

--changeSet func:Initial-MX3-field_COM_MxSuretyType-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_COM_MxSuretyType', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_COM_MxSuretyType](@CNTRP_IRD_M_ID numeric(10,0),@CNTRP_CRD_M_ID numeric(10,0),@CNTRP_SEC_M_ID numeric(10,0),@COM_contractGroup_TRN varchar(5)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_COM_MxSuretyType-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_COM_MxSuretyType]
(
    @CNTRP_IRD_M_ID numeric(10,0),
    @CNTRP_CRD_M_ID numeric(10,0),
    @CNTRP_SEC_M_ID numeric(10,0),
    @COM_contractGroup_TRN varchar(5)
)
RETURNS VARCHAR(15)
AS
BEGIN
	RETURN
        CASE
			WHEN (@CNTRP_IRD_M_ID IS NOT NULL AND @CNTRP_IRD_M_ID <> 0) THEN 'TRADE'
			WHEN (@CNTRP_CRD_M_ID IS NOT NULL AND @CNTRP_CRD_M_ID <> 0) THEN 'TRADE'
			WHEN (@CNTRP_SEC_M_ID IS NOT NULL AND @CNTRP_SEC_M_ID <> 0) AND @COM_contractGroup_TRN = 'BOND' THEN 'BOND'
			ELSE NULL
		END
END
GO