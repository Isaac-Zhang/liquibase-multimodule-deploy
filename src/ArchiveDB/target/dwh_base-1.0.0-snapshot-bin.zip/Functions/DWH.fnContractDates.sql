--liquibase formatted sql

--changeSet func:Initial-DWH-fnContractDates-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnContractDates', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnContractDates](@reportDate date,@loadContextID int,@contractIDs xml) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnContractDates-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
-- User Defined Function
ALTER FUNCTION  [DWH].[fnContractDates] (
   @reportDate date
 , @loadContextID int
 , @contractIDs xml = NULL)
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnContractDates
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate					DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with all contractDates pivoted to columns
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s			:
  -- !								select * from DWH.fnContractDates('2010-05-03');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-06-02 CHTH  Initial version
  -- !                       2012-02-02 JoJo  Added nextCouponDate and currentCouponDate
  -- !						 2012-11-12 AnOh  Added docActionDate and docInOutDate
  -- !						 2013-04-18 MaSo  Added expiryDate
  -- !						 2013-10-17 PEHA  Added terminationDate
  -- !                       2014-05-22 JoJo  Added issueDate
  -- +----------------------------------------------------------------------------------------------------------------

AS RETURN
(
	SELECT  
		_contract_id,
		_contractType_ID,
		_legtype_ID,
		legNumber, 
		tradeDate, 
		maturityDate,
		dealinsertionDateMxG, 
		startDate, 
		lastMarketOperationDate,
		couponNextPayDate,
		couponNextFixingDate,
        drawDownStartDate,
        drawDownEndDate,
        externAllIn2Date,
        couponCalculationStartDate,
		couponCalculationEndDate,
		nextCouponDate,
		currentCouponDate,
		docActionDate,
		docInOutDate,
		expiryDate,
		terminationDate,
		issueDate
	FROM 
		(
			SELECT 
				_contract_id,
				_contractType_ID,
				_legtype_ID,
				legNumber, 
				eventDate, 
				dateType
			FROM @contractIDs.nodes('/row') T1(ContractNode)
			INNER JOIN DWH.contractDate cd ON cd.[_contract_ID] = ContractNode.value('@ID[1]', 'INT') 
			INNER JOIN DWH.LKP_dateType dt on cd._dateType_ID = dt.ID
			WHERE cd.reportDate = @reportDate AND cd._loadContext_ID = @loadContextID AND @contractIDs IS NOT NULL
			UNION ALL
			SELECT 
				_contract_id,
				_contractType_ID,
				_legtype_ID,
				legNumber, 
				eventDate, 
				dateType
			FROM DWH.contractDate cd
			INNER JOIN DWH.LKP_dateType dt on cd._dateType_ID = dt.ID
			WHERE cd.reportDate = @reportDate AND cd._loadContext_ID = @loadContextID AND @contractIDs IS NULL
	) AS p
	PIVOT
	(
		MIN([eventDate])
		FOR dateType IN (
            tradeDate, maturityDate, dealinsertionDateMxG, 
            startDate, lastMarketOperationDate, couponNextPayDate, 
            couponNextFixingDate, drawDownStartDate, drawDownEndDate,
            externAllIn2Date,couponCalculationStartDate,couponCalculationEndDate,
			nextCouponDate, currentCouponDate, docActionDate, docInOutDate, expiryDate,
			terminationDate, issueDate
        )
	) AS pvt
)
GO
GO