--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_coupon_frequency_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_coupon_frequency_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_coupon_frequency_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTMFRP0 varchar(15),@PL_M_TP_RTMFRP1 varchar(15)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_coupon_frequency_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
-- User Defined Function
ALTER FUNCTION  [MX].[field_CRS_coupon_frequency_LEG]
(
	@mxContractType varchar(10),
	@COM_leg_LEG int,
    @PL_M_TP_RTMFRP0 varchar(15),
    @PL_M_TP_RTMFRP1 varchar(15)
)
RETURNS varchar(15)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP') THEN
				CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTMFRP0
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTMFRP1
			        ELSE NULL
			    END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_CD ----------------------------------------------------
            ---------------------------------------------------- CRS_CDS ----------------------------------------------------
            ---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'CDS', 'FUT', 'LN_BR', 'REPO', 'CF') THEN @PL_M_TP_RTMFRP0
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			WHEN @mxContractType IN ('FRA') THEN 
				CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTMFRP0
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTMFRP1
			        ELSE NULL
			    END
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
            ---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('FXD', 'XSW') THEN NULL
		ELSE NULL
		END
END
GO