--liquibase formatted sql

--changeSet func:Initial-DWH-fnInstrumentEventValues-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnInstrumentEventValues', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnInstrumentEventValues](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnInstrumentEventValues-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnInstrumentEventValues](@reportDate date, @extractContext varchar(3))
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnInstrumentEventValues
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate					DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with all instrument event values pivoted to columns
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s			:
  -- !								select * from DWH.fnInstrumentEventValues('2010-05-03');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-10-08 ChTh  Initial version
  -- +----------------------------------------------------------------------------------------------------------------

AS RETURN
(
WITH INST AS (
		SELECT IE.ID, IE._instrument_ID, IE._eventType_ID
		FROM DWH.instrument I
        INNER JOIN DWH.loadContext LC ON I._loadContext_ID = LC.ID
        INNER JOIN DWH.instrumentEvent IE ON I.ID = IE._instrument_ID
		WHERE I.reportDate = @reportDate AND LC.extractContext = @extractContext
)
	SELECT
      _instrument_ID,
      triggerNoticePeriod,
      triggerRepaymentPercent,
      triggerLevel
	FROM
		(
			SELECT 
				_instrument_ID,
            IEV.[value],
            VT.valueType
			FROM DWH.instrumentEventValues IEV
		   INNER JOIN DWH.LKP_valueType VT on IEV._valueType_ID = VT.ID
			INNER JOIN INST ON IEV._instrumentEvent_ID = INST.ID
	) AS p
	PIVOT
	(
		MAX([value])
		FOR valueType IN (triggerNoticePeriod, triggerRepaymentPercent, triggerLevel)
	) AS pvt
)
GO