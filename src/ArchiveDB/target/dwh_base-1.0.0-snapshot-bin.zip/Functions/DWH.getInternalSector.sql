--liquibase formatted sql

--changeSet func:Initial-DWH-getInternalSector-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getInternalSector', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getInternalSector](@reportDate date,@loadContextID int) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getInternalSector-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getInternalSector](@reportDate date, @loadContextID int)
RETURNS TABLE AS RETURN
   WITH CTE AS (
      SELECT C.ID AS _counterpart_ID, C.shortname, C.[_subIndustry]
      FROM DWH.counterpart C
      WHERE reportDate = @reportDate
      AND [_loadContext_ID] = @loadContextID
      --AND shortname = '3IGRO'
   ), SUBS AS (
      SELECT ROW_NUMBER() OVER (ORDER BY sortOrder) AS newSortOrder, subIndustry, counterpartShortname, S.internalSectorName
      FROM DWH.LKP_internalSectorMapping M
      INNER JOIN DWH.LKP_internalSector S ON M.[_internalSector_ID] = S.ID
      LEFT JOIN DWH.fnGetGicsStructure(@reportDate) G ON 
            M.gicsCode = G.subIndustry
        OR  M.gicsCode = G.industry
        OR  M.gicsCode = G.industryGroup
        OR  M.gicsCode = G.sector
      WHERE @reportDate BETWEEN M.validFrom AND M.validTo
   ), REC AS (
      SELECT CP._counterpart_ID, CP.shortname, C.internalSectorName AS counterpartSectorName, S.internalSectorName AS gicsSectorName, C.newSortOrder AS counterpartSortOrder, S.newSortOrder AS gicsSortOrder
      FROM CTE AS CP
      LEFT JOIN SUBS AS S ON S.subIndustry = CP.[_subIndustry]
      LEFT JOIN SUBS AS C ON C.counterpartShortname = CP.shortname
      UNION ALL
      SELECT CP._counterpart_ID, CP.shortname, C.internalSectorName AS counterpartSectorName, C.internalSectorName AS gicsSectorName, C.newSortOrder AS counterpartSortOrder, C.newSortOrder AS gicsSortOrder
      FROM CTE AS CP
      CROSS APPLY (
         SELECT newSortOrder, internalSectorName FROM SUBS WHERE counterpartShortname IS NULL AND subIndustry IS NULL
      ) AS C
   ), MX AS (
      SELECT DISTINCT _counterpart_ID, shortname, COALESCE(counterpartSectorName, gicsSectorName) AS sectorName, COALESCE(counterpartSortOrder, gicsSortOrder) AS sortOrder
      FROM REC  
   ), MM AS (
      SELECT _counterpart_ID, MIN(sortOrder) AS minSortOrder
      FROM MX
      GROUP BY _counterpart_ID
   ), RESULT AS (
      SELECT MM._counterpart_ID, MX.shortname, MX.sectorName, MX.sortOrder
      FROM MM
      INNER JOIN MX ON MM._counterpart_ID = MX._counterpart_ID AND MM.minSortOrder = MX.sortOrder
   )
   SELECT *
   FROM RESULT
GO