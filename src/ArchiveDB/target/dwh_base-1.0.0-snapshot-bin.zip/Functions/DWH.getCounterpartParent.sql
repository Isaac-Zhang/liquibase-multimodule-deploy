--liquibase formatted sql

--changeSet func:Initial-DWH-getCounterpartParent-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getCounterpartParent', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getCounterpartParent](@reportDate date,@extractContext varchar(3),@counterpartID xml) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getCounterpartParent-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getCounterpartParent]
(
	@reportDate date
 , @extractContext varchar(3)
 , @counterpartID xml = NULL
   
)
RETURNS TABLE
--
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! R e t u r n s :                   @counterpartChildParent					 TABLE			   table of counterpartParents to childCounterpart
-- !
-- ! P a r a m e t e r s :             Name                        DataType          Description
-- !                                   -----------------------     -------------     -----------------------------------------------
-- !                                   @reportDate                 DATETIME          The date on which the function will act.
-- !
-- ! O b j e c t i v e :				 Returns a table with nearest parent to all active counterparts.
-- !
-- ! R e v i s i o n   H i s t o r y : Date            Who     What
-- !                                   ----------      ----    ---------------------------------------------------------------------
-- !                                   2010-09-27      DaHj    Initial version...
-- !                                   2013-07-04      CHTH    Added version where we use selective ID's needed for IRT flow
-- +--------------------------------------------------------------------------------------------------------------------------------+
--
AS RETURN
(
  WITH CTE_counterpart AS (
      SELECT      c.ID
                  ,c.counterpartIdentity
                  ,c.shortname
                  ,c.longname
                  ,ch.counterpartIDPath
                  ,counterpartIDPath.GetAncestor(1) AS parent
      FROM        DWH.counterpart AS c
      INNER JOIN  DWH.loadContext LC ON c._loadContext_ID = LC.ID
      INNER JOIN  DWH.counterpartHierarchy AS ch
        ON        c.ID          = ch._counterpart_ID
      INNER JOIN (
         SELECT _counterpart_ID = CounterpartNode.value('@ID[1]', 'INT')
         FROM @counterpartID.nodes('/row') T1(CounterpartNode)  
         WHERE @counterpartID IS NOT NULL
         UNION ALL
         SELECT _counterpart_ID = C.ID
         FROM  DWH.counterpart AS c
         INNER JOIN DWH.loadContext LC ON c._loadContext_ID = LC.ID
         WHERE       C.reportDate  = @reportDate
            AND LC.extractContext = @extractContext
            AND @counterpartID IS NULL
       
      ) FF ON FF._counterpart_ID = C.ID              
      
      WHERE       C.reportDate  = @reportDate
              AND LC.extractContext = @extractContext
  )
  SELECT      cte_cC.ID                                 AS _counterpartChild_ID,
              COALESCE(cte_cP.ID,cte_cC.ID)             AS _counterpartParent_ID,
              cte_cC.counterpartIdentity                AS cpyIdChild
              --< Om motparten inte har någon förälder ska cpyIdParent vara motpartens egna counterpartIdentity. >--
              ,COALESCE(cte_cP.counterpartIdentity, cte_cC.counterpartIdentity) AS cpyIdParent
              --< Om motparten inte har någon förälder ska shortnameParent vara motpartens egna shortname. >--
              ,COALESCE(cte_cP.shortname, cte_cC.shortname) AS shortnameParent
              --< Om motparten inte har någon förälder ska longnameParent vara motpartens egna longname. >--
              ,COALESCE(cte_cP.longname, cte_cC.longname) AS longnameParent

  --< Child >--
  FROM        CTE_counterpart AS cte_cC
  --< Parent >--
  LEFT HASH JOIN   CTE_counterpart AS cte_cP     ON      cte_cP.counterpartIDPath = cte_cC.parent--
)
GO