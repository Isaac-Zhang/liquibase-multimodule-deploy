--liquibase formatted sql

--changeSet func:Initial-MX-field_totalMargin-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_totalMargin', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_totalMargin](@mxContractType varchar(10),@PL_M_TP_BUY char(1),@IRD_M_REMARGIN numeric(6,2)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_totalMargin-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_totalMargin]
(
	@mxContractType varchar(10), 
	@PL_M_TP_BUY    CHAR(1),
	@IRD_M_REMARGIN NUMERIC(6,2)
	
)
RETURNS NUMERIC(6,2)
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType = 'BOND' AND @PL_M_TP_BUY = 'B'
        THEN @IRD_M_REMARGIN
        ELSE NULL
        END
END
GO