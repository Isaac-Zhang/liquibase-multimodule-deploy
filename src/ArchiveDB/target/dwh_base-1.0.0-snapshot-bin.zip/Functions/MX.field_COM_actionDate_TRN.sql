--liquibase formatted sql

--changeSet func:Initial-MX-field_COM_actionDate_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_COM_actionDate_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_COM_actionDate_TRN](@COM_contractFamily varchar(10),@EQD_LTM_ACTION datetime,@IRD_LTM_ACTION datetime,@CURR_LTM_ACTION datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_COM_actionDate_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_COM_actionDate_TRN](
@COM_contractFamily varchar(10), 
@EQD_LTM_ACTION datetime,
@IRD_LTM_ACTION datetime,
@CURR_LTM_ACTION datetime
)
RETURNS datetime
AS
BEGIN
  RETURN
	CASE
		       ---- EQD ----
		WHEN @COM_contractFamily = 'EQD'  THEN
			@EQD_LTM_ACTION
                ---- IRD ----
        WHEN @COM_contractFamily = 'IRD'  THEN
			@IRD_LTM_ACTION
                ---- CURR ----
		WHEN @COM_contractFamily = 'CURR' THEN
			@CURR_LTM_ACTION
                ELSE NULL
			
  	END
END
GO