--liquibase formatted sql

--changeSet func:Initial-PF-field_RAW_entity-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('PF.field_RAW_entity', 'FN') IS NULL EXEC('CREATE FUNCTION [PF].[field_RAW_entity](@portfolio varchar(10)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-PF-field_RAW_entity-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [PF].[field_RAW_entity]
(
	@portfolio VARCHAR(10)
)
RETURNS VARCHAR(10)
AS
BEGIN
	RETURN 'SEK AB'
END
GO