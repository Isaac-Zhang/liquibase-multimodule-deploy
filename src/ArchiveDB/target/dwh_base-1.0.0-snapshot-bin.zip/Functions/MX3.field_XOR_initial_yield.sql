--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_initial_yield-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_initial_yield', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_initial_yield](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_YIELD numeric(9,4),@PL_M_TP_YIELD2 numeric(9,4)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_initial_yield-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_XOR_initial_yield]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_YIELD numeric(9,4),
    @PL_M_TP_YIELD2 numeric(9,4)
)
RETURNS numeric(9,4)
AS
BEGIN
	RETURN 
		CASE
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN @PL_M_TP_YIELD
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
			CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_YIELD
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_YIELD2
			ELSE NULL
			END
		ELSE NULL
		END
END
GO