--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_cpyRefMxg_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_cpyRefMxg_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_cpyRefMxg_TRN](@COM_contractFamily_TRN varchar(10),@IRD_M_CTRP_REF varchar(25),@CRD_M_CTRP_REF varchar(25),@CURR_M_CTRP_REF varchar(25),@EQD_M_CTRP_REF varchar(25)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_cpyRefMxg_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_cpyRefMxg_TRN]
(
	@COM_contractFamily_TRN varchar(10),
    @IRD_M_CTRP_REF varchar(25),
    @CRD_M_CTRP_REF varchar(25),
    @CURR_M_CTRP_REF varchar(25),
    @EQD_M_CTRP_REF varchar(25)
)
RETURNS varchar(25)
AS
BEGIN
	RETURN
		CASE
		  WHEN @COM_contractFamily_TRN = 'IRD' THEN @IRD_M_CTRP_REF
		  WHEN @COM_contractFamily_TRN = 'CRD' THEN @CRD_M_CTRP_REF
		  WHEN @COM_contractFamily_TRN = 'CURR' THEN @CURR_M_CTRP_REF
		  WHEN @COM_contractFamily_TRN = 'EQD' THEN @EQD_M_CTRP_REF
		  ELSE NULL
	    END

END
GO