--liquibase formatted sql

--changeSet func:Initial-MX-field_initialInterestRate-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_initialInterestRate', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_initialInterestRate](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTMRTE0 numeric(12,6),@PL_M_TP_RTMRTE1 numeric(12,6),@PL_M_TP_STRIKE numeric(12,6)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_initialInterestRate-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
-- User Defined Function
ALTER FUNCTION  [MX].[field_initialInterestRate]
(
	@mxContractType varchar(10),
	@COM_leg_LEG int,
    @PL_M_TP_RTMRTE0 numeric(12,6),
    @PL_M_TP_RTMRTE1 numeric(12,6),
    @PL_M_TP_STRIKE numeric(12,6)
)
RETURNS NUMERIC(28,8)
AS
BEGIN
	RETURN 
        CASE 
        WHEN @mxContractType IN ('OPT') THEN @PL_M_TP_STRIKE
        WHEN @mxContractType IN ('ASWP', 'FXD', 'LN_BR', 'CS', 'FUT', 'IRS', 'OSWP', 'XSW', 'FRA') THEN
            CASE 
            WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTMRTE0
            WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTMRTE1
            END
        WHEN @mxContractType IN ('CDS', 'FDB', 'NDB') THEN @PL_M_TP_RTMRTE0
        ELSE NULL
        END       
END
GO