--liquibase formatted sql

--changeSet func:Initial-MX-field_optionStrikeDate-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_optionStrikeDate', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_optionStrikeDate](@mxContractType varchar(10),@PL_M_TP_DTEEXP date) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_optionStrikeDate-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_optionStrikeDate]
(
	@mxContractType varchar(10),
    @PL_M_TP_DTEEXP date
)
RETURNS date
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType IN ('OPT', 'FDB', 'NDB') THEN @PL_M_TP_DTEEXP
        ELSE NULL
        END
END
GO