--liquibase formatted sql

--changeSet func:Initial-MARKETRISK-isJobRunUsingBookingType-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MARKETRISK.isJobRunUsingBookingType', 'FN') IS NULL EXEC('CREATE FUNCTION [MARKETRISK].[isJobRunUsingBookingType](@jobRunIdentifier int,@bookingTypeName varchar(200)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MARKETRISK-isJobRunUsingBookingType-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MARKETRISK].[isJobRunUsingBookingType]
(
	@jobRunIdentifier INT,
	@bookingTypeName VARCHAR(200)
)
RETURNS BIT
AS
BEGIN
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.[isJobUsingBookingType]
  -- ! R e t u r n s       : INT
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @jobRunIdentifier		 INT
  -- !                       @bookingTypeName		 CARCHAR(200)
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns bit to indicate if the job run uses a certain booking type
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2013-07-04 MaSo  Initial version ...
  -- +----------------------------------------------------------------------------------------------------------------
  --
	
	DECLARE @return BIT
	
	IF EXISTS
    (
		SELECT
			1
		FROM
			MARKETRISK.JOB.jobRun JR
			LEFT JOIN MARKETRISK.JOB.jobRun JRP ON
				JRP.ID = JR.[_jobRunParent_ID]
			INNER JOIN MARKETRISK.RULEENGINE.bookingCollection BC ON
				BC.ID = JR.[_bookingCollection_ID] AND
				BC.dateTimeInserted <= COALESCE(JRP.startDateTime,JR.startDateTime)
			INNER JOIN MARKETRISK.RULEENGINE.bookingGroup BG ON
				BG.[_bookingCollection_ID] = BC.ID AND
				BG.dateTimeInserted <= COALESCE(JRP.startDateTime,JR.startDateTime)
			INNER JOIN MARKETRISK.RULEENGINE.bookingGroupCategoryMap BGCM ON
				BGCM.[_bookingGroup_ID] = BG.ID AND
				COALESCE(JRP.startDateTime,JR.startDateTime) BETWEEN BGCM.dateTimeValidFrom AND dateTimeValidTo
			INNER JOIN MARKETRISK.RULEENGINE.bookingType BT ON
				BT.ID = BGCM.[_bookingType_ID]
		WHERE
			JR.ID = @jobRunIdentifier AND
			BT.bookingTypeName = @bookingTypeName
    )
    BEGIN
		SET @return = 1
	END
	ELSE
	BEGIN
		SET @return = 0
	END
	
	RETURN @return
	       
END
GO