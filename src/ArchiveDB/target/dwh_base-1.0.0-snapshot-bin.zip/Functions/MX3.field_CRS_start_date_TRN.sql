--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_start_date_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_start_date_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_start_date_TRN](@mxContractType varchar(10),@PL_M_TP_DTEFLWF datetime,@PL_M_TP_DTEPMT datetime,@PL_M_TP_DTEPMT2 datetime,@PL_M_TP_DTEFST datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_DTETRN datetime,@PL_M_TP_RTDCC01 datetime,@PL_M_TP_RTDCC11 datetime,@PL_M_QTY_INDEX tinyint,@COM_leg_LEG tinyint) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_start_date_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_start_date_TRN]
(
	@mxContractType varchar(10), 
    @PL_M_TP_DTEFLWF datetime,
    @PL_M_TP_DTEPMT datetime,
    @PL_M_TP_DTEPMT2 datetime,
    @PL_M_TP_DTEFST datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_DTETRN datetime,
    @PL_M_TP_RTDCC01 datetime,
    @PL_M_TP_RTDCC11 datetime,
    @PL_M_QTY_INDEX TINYINT,
	@COM_leg_LEG TINYINT
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			WHEN @mxContractType = 'ASWP' THEN 
                CASE --IIF(TP_DTEFLWF<TP_RTDCC11,TP_DTEFLWF,TP_RTDCC11)
				    WHEN @PL_M_TP_DTEFLWF < ISNULL(@PL_M_TP_RTDCC11,'2079-01-01') THEN @PL_M_TP_DTEFLWF
    			    ELSE @PL_M_TP_RTDCC11
			    END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'REPO') THEN @PL_M_TP_DTEPMT
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
            ---------------------------------------------------- CRS_IRS ----------------------------------------------------
            ---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			WHEN @mxContractType IN ('CD', 'CS', 'FRA', 'IRS', 'LN_BR') THEN @PL_M_TP_DTEFLWF
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
            ---------------------------------------------------- CRS_CF ----------------------------------------------------
			WHEN @mxContractType IN ('CDS', 'CF', 'OPT', 'OSWP', 'FDB', 'NDB') THEN @PL_M_TP_DTEFST
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			WHEN @mxContractType IN ('FUT') THEN @PL_M_TP_DTEEXP
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('XSW') 
			THEN CASE 
			     WHEN @PL_M_QTY_INDEX = 0
			     THEN @PL_M_TP_DTEEXP
			     ELSE @PL_M_TP_DTEPMT2
			     END
			WHEN @mxContractType IN ('SWLEG') 
			THEN CASE 
			     WHEN @COM_leg_LEG = 1
			     THEN @PL_M_TP_DTEEXP
			     ELSE @PL_M_TP_DTEPMT2
			     END
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType = 'FXD' THEN @PL_M_TP_DTETRN

		ELSE NULL
		END
END
GO