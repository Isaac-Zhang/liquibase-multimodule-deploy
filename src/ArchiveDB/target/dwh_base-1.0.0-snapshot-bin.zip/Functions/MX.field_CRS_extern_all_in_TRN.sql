--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_extern_all_in_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_extern_all_in_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_extern_all_in_TRN](@mxContractType varchar(10),@IRD_M_EXTERN numeric(6,2),@CURR_M_EXTERN numeric(6,2),@COM_leg_LEG int,@PL_M_TP_RTPR0 varchar(1),@PL_M_TP_RTPR1 varchar(1),@PL_M_TP_BUY varchar(1),@PL_M_TP_RTCCP01 numeric(19,2),@PL_M_QTY_INDEX numeric(3,0),@PL_M_TP_RTNBPHS numeric(2,0),@PL_M_TP_RTVLC01 numeric(19,6),@PL_M_TP_RTVLC11 numeric(19,6),@PL_M_TP_RTMRTE0 numeric(12,6),@PL_M_TP_STRIKE numeric(12,6)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_extern_all_in_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_extern_all_in_TRN]
(
	@mxContractType  varchar(10), 
    @IRD_M_EXTERN    numeric(6,2),
    @CURR_M_EXTERN   numeric(6,2),
    
	@COM_leg_LEG     int,
	@PL_M_TP_RTPR0   varchar(1),
	@PL_M_TP_RTPR1   varchar(1),
	@PL_M_TP_BUY     varchar(1),
	@PL_M_TP_RTCCP01 numeric(19,2),
	@PL_M_QTY_INDEX  numeric(3,0),
	
	@PL_M_TP_RTNBPHS numeric(2,0),
	@PL_M_TP_RTVLC01 numeric(19,6),
	@PL_M_TP_RTVLC11 numeric(19,6),
    @PL_M_TP_RTMRTE0 numeric(12,6),
    @PL_M_TP_STRIKE  numeric(12,6)
)
RETURNS numeric(6,2)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
            WHEN @mxContractType IN ('ASWP', 'BOND', 'CD', 'CS', 'FRA', 'FUT', 'IRS', 'LN_BR', 'REPO', 'OSWP'/*, 'CF'*/)
            THEN @IRD_M_EXTERN
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('FXD', 'XSW')
			THEN @CURR_M_EXTERN
			WHEN @mxContractType = 'CDS' 
			AND [MX].[field_CRS_asset_or_liability_LEG](
			                                            @mxContractType 
			                                           ,@COM_leg_LEG
			                                           ,@PL_M_TP_RTPR0
			                                           ,@PL_M_TP_RTPR1
			                                           ,@PL_M_TP_BUY
			                                           ,@PL_M_TP_RTCCP01
			                                           ,@PL_M_QTY_INDEX
			                                           ) = 'L'
			THEN [MX].[field_CRS_coupon_rate_LEG](
			                                      @mxContractType
			                                     ,@COM_leg_LEG
			                                     ,@PL_M_TP_RTNBPHS
			                                     ,@PL_M_TP_RTVLC01
			                                     ,@PL_M_TP_RTVLC11
			                                     ,@PL_M_TP_RTMRTE0
			                                     ,@PL_M_TP_STRIKE
			                                     ) * 100
		    ELSE NULL
		END
END
GO