--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_contract_status-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_contract_status', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_contract_status](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@reportDate date,@COM_revaluationDate1_TRN datetime,@PL_M_TP_STATUS1 varchar(10),@PL_M_TP_MOPLSTL varchar(10),@PL_M_TP_DTEFST datetime,@PL_M_TP_DTEFLWF datetime,@PL_M_TP_DTEPMT datetime,@PL_M_TP_DTEPMT2 datetime,@PL_M_TP_DTETRN datetime,@PL_M_TP_RTDCC11 datetime,@F_FLOW1_NO_OF_FUTURE_FLOWS int) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_contract_status-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_XOR_contract_status]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @reportDate date,
    @COM_revaluationDate1_TRN datetime,
    @PL_M_TP_STATUS1 varchar(10),
    @PL_M_TP_MOPLSTL varchar(10),
    @PL_M_TP_DTEFST datetime,
    @PL_M_TP_DTEFLWF datetime,
    @PL_M_TP_DTEPMT datetime,
    @PL_M_TP_DTEPMT2 datetime,
    @PL_M_TP_DTETRN datetime,
    @PL_M_TP_RTDCC11 datetime,
    @F_FLOW1_NO_OF_FUTURE_FLOWS int
)
RETURNS varchar(1)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN             
                MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST) = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND 
                    MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(DENV('CRT_BND11')<TP_DTEFLWF.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @COM_revaluationDate1_TRN < @PL_M_TP_DTEFST AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
				THEN 'M'
				ELSE
					CASE
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(DENV('CRT_BND11')<TP_DTEFLWF.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @COM_revaluationDate1_TRN < @PL_M_TP_DTEFLWF AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
				THEN 'M'
				ELSE
					CASE
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
				THEN 'M'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN
			CASE --IIF(DENV('CRT_BND11')<TP_DTEFLWF.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @COM_revaluationDate1_TRN < @PL_M_TP_DTEPMT AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
				THEN 'M'
				ELSE
					CASE
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
					THEN 'D'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
						WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
						THEN 'S'
						ELSE '-'
						END
					END
					END
				END
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(DENV('CRT_BND11')<TP_DTEFLWF.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @COM_revaluationDate1_TRN < @PL_M_TP_DTEPMT AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(DENV('CRT_BND11')<TP_DTEFLWF.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @COM_revaluationDate1_TRN < @PL_M_TP_DTEPMT AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN
			CASE --IIF(DENV('CRT_BND11')<TP_DTEFLWF.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @COM_revaluationDate1_TRN < @PL_M_TP_DTEFST AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
				THEN 'M'
				ELSE
					CASE
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(REP_DATE<TP_DTEPMT2.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP'.AND.ACTIVE=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @reportDate < @PL_M_TP_DTEPMT2 AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP'.AND.ACTIVE=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP') AND
					CASE --IIF(TP_DTEPMT2<=REP_DATE.AND.REP_DATE<=TP_DTEPMT,1,0)
					WHEN @PL_M_TP_DTEPMT2 <= @reportDate AND @reportDate <= @PL_M_TP_DTEPMT
					THEN 1
					ELSE 0
					END
					= 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(REP_DATE<TP_DTEPMT2.AND.TP_STATUS1="LIVE",'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP'.AND.ACTIVE=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN @reportDate < @PL_M_TP_DTEPMT2 AND @PL_M_TP_STATUS1 = 'LIVE'
			THEN 'U'
			ELSE
				CASE --IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP'.AND.ACTIVE=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP') AND
					CASE --IIF(TP_DTEPMT2<=REP_DATE.AND.REP_DATE<=TP_DTEPMT,1,0)
					WHEN @PL_M_TP_DTEPMT2 <= @reportDate AND @reportDate <= @PL_M_TP_DTEPMT
					THEN 1
					ELSE 0
					END
					= 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN
			CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(U_STATUS=1,'U', IIF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))))
			WHEN MX3.field_XOR_U_status(
                    @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN,
                    @reportDate, @COM_leg_LEG,
                    @PL_M_TP_STATUS1, @PL_M_TP_DTEFLWF, @PL_M_TP_DTEPMT, @PL_M_TP_DTETRN, @PL_M_TP_RTDCC11, @PL_M_TP_DTEFST)  = 1
			THEN 'U'
			ELSE
				CASE --IF(TRIM(TP_STATUS1)$'LIVE|MKT_OP','A', IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))))
			WHEN LTRIM(RTRIM(@PL_M_TP_STATUS1)) IN ('LIVE','MKT_OP')
			THEN 'A'
			ELSE
				CASE --IIF(TRIM(TP_MOPLSTL)=='XIT'.AND.XIT_FLOW12=1,'A', IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'XIT' AND MX3.field_XOR_XIT_FLOW(@PL_M_TP_MOPLSTL, @F_FLOW1_NO_OF_FUTURE_FLOWS) = 1
				THEN 'A'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'RPL|RPL_D|RPL_M|XIT','D', IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')))
				WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) IN ('RPL','RPL_D','RPL_M','XIT')
				THEN 'D'
				ELSE
					CASE --IIF(TRIM(TP_MOPLSTL)$'EXP','M', IIF(TRIM(TP_MOPLSTL)=='NET','S', '-'))
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'EXP'
					THEN 'M'
					ELSE
						CASE --IIF(TRIM(TP_MOPLSTL)=='NET','S', '-')
					WHEN LTRIM(RTRIM(@PL_M_TP_MOPLSTL)) = 'NET'
					THEN 'S'
					ELSE '-'
					END
					END
				END
				END
			END
			END
		ELSE NULL
		END
END
GO