--liquibase formatted sql

--changeSet func:Initial-DWH-getCounterpartParentLegal-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getCounterpartParentLegal', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getCounterpartParentLegal](@reportDate date,@extractContext varchar(3),@counterpartID xml) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getCounterpartParentLegal-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getCounterpartParentLegal] (
   @reportDate  date
 , @extractContext varchar(3)
 , @counterpartID XML = NULL
)
RETURNS TABLE 
AS RETURN
(
--
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! R e t u r n s :                   @counterpartChildParent					 TABLE			   table of counterpartLEGALParents to childCounterpart
-- !
-- ! P a r a m e t e r s :             Name                        DataType          Description
-- !                                   -----------------------     -------------     -----------------------------------------------
-- !                                   @reportDate                 DATETIME          The date on which the function will act.
-- !
-- ! O b j e c t i v e :				 Returns a table with nearest LEGALparent to all active counterparts.
-- !
-- ! R e v i s i o n   H i s t o r y : Date            Who     What
-- !                                   ----------      ----    ---------------------------------------------------------------------
-- !                                   2010-09-27      DaHj     Initial version...
-- !                                   2012-01-19      CHTH     Modified somewhat to improve performance
-- !												2012-11-01		 HAWI		 Slaughthered the old functions, the data is populated 
-- !																				 in DWH_BASE.DWH.loadCounterpartInformation
-- !                                   2013-07-04      CHTH    Added version where we use selective ID's needed for IRT flow
-- +--------------------------------------------------------------------------------------------------------------------------------+
--
SELECT 
	_counterpartChild_ID, 
	_counterpartParent_ID, 
	cpyIdChild				= child.[counterpartIdentity], 
	cpyIdParentLegal		= [parent].[counterpartIdentity],	
	shortnameParentLegal	= [parent].[shortname] ,
	longnameParentLegal	= parent.[longname]
FROM DWH.counterpartParent  cpp
INNER JOIN dwh.[counterpart] AS parent ON parent.id=cpp._counterpartParent_ID
INNER JOIN dwh.[counterpart] AS child ON child.id=cpp._counterpartChild_ID
INNER JOIN (
   SELECT _counterpart_ID = CounterpartNode.value('@ID[1]', 'INT')
   FROM @counterpartID.nodes('/row') T1(CounterpartNode)  
   WHERE @counterpartID IS NOT NULL
   UNION ALL
   SELECT _counterpart_ID = C.ID
   FROM  DWH.counterpart AS c
   INNER JOIN DWH.loadContext LC ON c._loadContext_ID = LC.ID
   WHERE       C.reportDate  = @reportDate
      AND C.[_loadContext_ID] = (SELECT lc.id FROM dwh.LoadContext lc WHERE lc.reportDate = @reportDate AND lc.extractContext=@extractContext)
      AND @counterpartID IS NULL
) FF ON FF._counterpart_ID = cpp._counterpartChild_ID
WHERE 
	cpp.ParentType='Legal' 
	AND cpp.reportDate = @reportDate 
	AND cpp._loadContext_ID = (SELECT lc.id FROM dwh.LoadContext lc WHERE lc.reportDate = @reportDate AND lc.extractContext=@extractContext)
)
--BEGIN
----
--  DECLARE @loadContextID int = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)

--  ------------------------------------------------
--  --< 2. Alla motparter som är RISK-motparter. >--
--  ------------------------------------------------
--  DECLARE @counterpartLegal TABLE
--  (
--    ID                  INT             PRIMARY KEY CLUSTERED
--    ,counterpartIDPath  HIERARCHYID
--    ,counterpartIdentity INT
--    ,shortname           varchar(30)
--    ,longname            varchar(255)    
--  );

--  INSERT INTO @counterpartLegal
--  SELECT      c.ID
--              ,ch.counterpartIDPath
--              ,c.counterpartIdentity
--              ,c.shortname
--              ,c.longname              
--  FROM        DWH.counterpartHierarchy  AS ch
--  INNER JOIN  DWH.counterpart           AS c    ON        c.ID = ch._counterpart_ID
--  WHERE       C.reportDate = @reportDate AND C.[_loadContext_ID] = @loadContextID
--   AND (
--      (c.isBranch     = 0) --  AND       c.isSubsidiary IN(0,1)) -- just to show the indifference of this boolean...
--       -- Det finns IsBranch = 1 som inte har någon förälder i hierarkin.
--       OR        (ch.parentCounterpartIDPath = 0x  AND c.isBranch = 1)
--   );
    
--  ---------------------------------------------------------------
--  --< 3. Motparter, vilka inte är Legal, och deras föräldrar. >--
--  ---------------------------------------------------------------

--  WITH CTE_counterpart AS (

--    ---------------------------------
--    --< Barnen som inte är Legal. >--
--    ---------------------------------
--    SELECT      c.ID                        AS _counterpartChild_ID
--                ,c.counterpartIdentity      AS cpyIdChild
--                ,ch.counterpartIDPath
--                ,c.ID                       AS _counterpartParent_ID
--                ,c.counterpartIdentity		AS cpyIdParent
--                ,ch.parentCounterpartIDPath
--                ,c.shortname                            AS parentShortname
--                ,c.longname                             AS parentLongname
--                ,c.isBranch                             AS parentIsBranch                
--    FROM        DWH.counterpartHierarchy  AS ch
--    INNER JOIN  DWH.counterpart           AS c      ON        c.ID  = ch._counterpart_ID
--    INNER JOIN  DWH.loadContext           AS LC     ON        c._loadContext_ID = LC.ID

--    LEFT JOIN   @counterpartLegal         AS cl
--      ON        cl.ID = c.ID
--    WHERE       C.reportDate = @reportDate AND cl.ID IS NULL -- Counterpart is not LegalCounterpart
--                AND LC.extractContext = @extractContext
--    UNION ALL
    
--    ----------------------------------------------------------
--    --< Föräldern till barnet, som inte är en Riskmotpart. >--
--    ----------------------------------------------------------
--    SELECT      cte_c._counterpartChild_ID  AS _counterpartChild_ID
--                ,cte_c.cpyIdChild           AS cpyIdChild
--                ,ch.counterpartIDPath
--                ,c.ID                       AS _counterpartParent_ID
--                ,c.counterpartIdentity      AS cpyIdParent
--                ,ch.parentCounterpartIDPath
--                ,c.shortname                AS parentShortname
--                ,c.longname                 AS parentLongname                
--                ,c.isBranch                 AS parentIsBranch                               
--    FROM        DWH.counterpartHierarchy  AS ch
--    INNER JOIN  CTE_counterpart           AS cte_c
--      ON        cte_c.parentCounterpartIDPath = ch.counterpartIDPath
--      --        För att stanna sökningen om man har hittat en förälder som är RISK-motpart.       --
--      --        Och det är fult och långsamt med NOT IN, men man får ju inte använda sig av       --
--      --        LEFT JOIN i den rekursiva delen...  --
--      AND       cte_c.counterpartIDPath NOT IN( SELECT  counterpartIDPath
--                                                FROM    @counterpartLegal)
--    INNER JOIN  DWH.counterpart           AS c
--      ON        c.ID  = ch._counterpart_ID
--    WHERE C.reportDate = @reportdate
--  )

--  INSERT INTO @counterpartChildParent
--  (
--    _counterpartChild_ID,
--    _counterpartParent_ID,
--    cpyIdChild            
--    ,cpyIdParentLegal     
--    ,shortnameParentLegal 
--    ,longnameParentLegal  
--  )
--  SELECT      cte_c._counterpartChild_ID
--              ,cte_c._counterpartParent_ID
--              ,cte_c.cpyIdChild  
--              ,cte_c.cpyIdParent
--              ,cte_c.parentShortname        AS parentShortName
--              ,cte_c.parentLongname         AS parentLongName
--  FROM        CTE_counterpart AS cte_c
--  WHERE (1=1)
--    --AND       cte_c.parentIsSubsidiary IN(0,1) -- just to show the indifference of this boolean...
--    AND       cte_c.parentIsBranch      = 0 

--  UNION ALL

--  --< Dessa motparter är RISK-motpart och har därmed sig själv som förälder. >--
--  ------------------------------------------------------------------------------
--  SELECT      cr.ID                    AS _counterpartChild_ID
--            , cr.ID                    AS _counterpartParent_ID
--            , cr.counterpartIdentity   AS cpyIdChild
--            , cr.counterpartIdentity  AS cpyIdParent
--            , cr.shortname            AS parentShortName
--            , cr.longname             AS parentLongName
--  FROM        @counterpartLegal AS cr
  
--  RETURN;

----
--END
----  
GO