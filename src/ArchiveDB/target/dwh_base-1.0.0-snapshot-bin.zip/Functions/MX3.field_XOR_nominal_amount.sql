--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_nominal_amount-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_nominal_amount', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_nominal_amount](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_BUY varchar(1),@PL_M_TP_RTCCP02 numeric(19,2),@PL_M_TP_RTCCP12 numeric(19,2),@PL_M_TP_NOMINAL numeric(19,2),@PL_M_TP_LQTY2 numeric(24,8),@PL_M_TP_LQTYS2 numeric(24,8),@PL_M_TP_SECLOT numeric(17,6),@PL_M_TP_PRICE numeric(23,6),@PL_M_TP_QTYEQ numeric(24,8),@PL_M_TP_RTCCP01 numeric(19,2),@PL_M_TP_RPO_AMT numeric(16,2),@PL_M_TP_RPOAMT2 numeric(16,2)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_nominal_amount-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_XOR_nominal_amount]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTCCP02 numeric(19,2),
    @PL_M_TP_RTCCP12 numeric(19,2),
    @PL_M_TP_NOMINAL numeric(19,2),
    @PL_M_TP_LQTY2 numeric(24,8),
    @PL_M_TP_LQTYS2 numeric(24,8),
    @PL_M_TP_SECLOT numeric(17,6),
    @PL_M_TP_PRICE numeric(23,6),
    @PL_M_TP_QTYEQ numeric(24,8),
    @PL_M_TP_RTCCP01 numeric(19,2),
    @PL_M_TP_RPO_AMT numeric(16,2),
    @PL_M_TP_RPOAMT2 numeric(16,2)
)
RETURNS numeric(28,8)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_BUY=='B',TP_RTCCP02,TP_RTCCP12)
				WHEN @PL_M_TP_BUY = 'B'
			THEN @PL_M_TP_RTCCP02
			ELSE @PL_M_TP_RTCCP12
			END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_NOMINAL
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_BUY=='B',TP_RTCCP02,TP_RTCCP12)
				WHEN @PL_M_TP_BUY = 'B'
			THEN @PL_M_TP_RTCCP02
			ELSE @PL_M_TP_RTCCP12
			END
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_LQTY2 * @PL_M_TP_SECLOT * @PL_M_TP_PRICE
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_LQTYS2
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_QTYEQ
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_RTCCP02
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_RTCCP02
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_RTCCP12
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN @PL_M_TP_RTCCP01
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_RTCCP02
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_RTCCP02
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_RTCCP12
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_RTCCP02
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_RTCCP12
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN @PL_M_TP_RPO_AMT
			WHEN @COM_leg_LEG = 2
			THEN @PL_M_TP_RPOAMT2
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN @PL_M_TP_LQTYS2
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN -@PL_M_TP_QTYEQ
			WHEN @COM_leg_LEG = 2
			THEN -@PL_M_TP_LQTYS2
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN @PL_M_TP_LQTYS2
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN @PL_M_TP_LQTYS2
		ELSE NULL
		END
END
GO