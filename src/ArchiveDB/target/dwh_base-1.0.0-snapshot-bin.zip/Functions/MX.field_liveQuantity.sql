--liquibase formatted sql

--changeSet func:Initial-MX-field_liveQuantity-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_liveQuantity', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_liveQuantity](@mxContractType varchar(10),@PL_M_TP_BUY varchar(1),@PL_M_TP_QTYEQ numeric(28,8),@PL_M_TP_LQTY0 numeric(28,8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_liveQuantity-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX].[field_liveQuantity]
(
	@mxContractType varchar(10),
	@PL_M_TP_BUY varchar(1),
    @PL_M_TP_QTYEQ numeric(28,8),
    @PL_M_TP_LQTY0 numeric(28,8)
)
RETURNS NUMERIC(28,8)
AS
BEGIN
	RETURN 
     CASE
        WHEN @mxContractType IN ('ASWP')                                                                      THEN @PL_M_TP_QTYEQ
        WHEN @mxContractType IN ('BOND','CF','FXD','LN_BR','OPT','CS','IRS','REPO','FRA','OSWP','CDS', 'XSW') THEN @PL_M_TP_LQTY0
        WHEN @mxContractType IN ('XSW')                                                                       THEN @PL_M_TP_LQTY0
        WHEN @mxContractType IN ('FUT')                                                                       THEN 
            CASE WHEN @PL_M_TP_BUY = 'B' THEN @PL_M_TP_LQTY0 ELSE -@PL_M_TP_LQTY0 END
     END                                                                                                     
END