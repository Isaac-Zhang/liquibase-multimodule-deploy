--liquibase formatted sql

--changeSet func:Initial-DWH-getContractType-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getContractType', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[getContractType](@contractFamily varchar(20),@contractGroup varchar(20),@contractType varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-getContractType-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [DWH].[getContractType]
(
	@contractFamily varchar(20),
	@contractGroup varchar(20),
	@contractType varchar(20)
)
RETURNS VARCHAR(5)
AS
BEGIN
	DECLARE @type varchar(5)

	SELECT @type =
		CASE 
			WHEN @contractGroup = 'OPT'																		THEN 'OPT' --
            WHEN @contractFamily = 'EQD' AND @contractType = 'FWD'                                          THEN 'OPT' --
            WHEN @contractFamily = 'EQD' AND @contractGroup = 'FUT'                                         THEN 'OPT' --
            WHEN @contractFamily = 'IRD' AND @contractType = 'FWD'                                          THEN 'OPT' --
            WHEN @contractFamily = 'CRD' AND @contractGroup = 'FDB'                                          THEN 'FDB' --
            WHEN @contractFamily = 'CRD' AND @contractGroup = 'NDB'                                          THEN 'NDB' --

			WHEN @contractFamily = 'IRD' AND @contractGroup = 'BOND'										THEN 'BOND' --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'ASWP' AND @contractType = ''					THEN 'ASWP' --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'CD'											THEN 'CD'   --
			WHEN @contractFamily = 'CRD' AND @contractGroup IN ('CDS') AND @contractType = ''	            THEN 'CDS'  --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'CF' AND @contractType = ''					THEN 'CF'   --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'CS' AND @contractType = ''					THEN 'CS'   --
			WHEN @contractFamily = 'EQD' AND @contractGroup = 'EQUIT' AND @contractType = ''				THEN 'EQUIT' --x
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'FRA' AND @contractType = ''					THEN 'FRA' --
			WHEN @contractFamily = 'IRD' AND @contractGroup IN('LFUT','SFUT') AND @contractType = ''		THEN 'FUT' --
			WHEN @contractFamily = 'CURR' AND @contractGroup = 'FXD' AND @contractType IN('FXD','FXDS')		THEN 'FXD' --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'IRS'											THEN 'IRS' --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'LN_BR'										THEN 'LN_BR' --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'OSWP' AND @contractType = ''					THEN 'OSWP' --
			WHEN @contractFamily = 'IRD' AND @contractGroup = 'REPO'										THEN 'REPO' --
			WHEN @contractFamily = 'SCF' AND @contractGroup = 'SCF' AND @contractType = 'SCF'				THEN 'SCF' --
			WHEN @contractFamily = 'CURR' AND @contractGroup = 'FXD' AND @contractType = 'XSW'				THEN 'XSW' --
			WHEN @contractFamily = 'CURR' AND @contractGroup = 'FXD' AND @contractType = 'SWLEG'			THEN 'XSW' -- fulfix?!
			ELSE NULL
		END

	RETURN @type
END
GO