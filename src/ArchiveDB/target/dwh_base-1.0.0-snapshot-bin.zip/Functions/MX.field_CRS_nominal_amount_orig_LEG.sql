--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_nominal_amount_orig_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_nominal_amount_orig_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_nominal_amount_orig_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_NOMINAL numeric(19,2),@PL_M_TP_QTYEQ numeric(24,8),@PL_M_QTY_INDEX numeric(3,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_nominal_amount_orig_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
-- User Defined Function
ALTER FUNCTION  [MX].[field_CRS_nominal_amount_orig_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
    @PL_M_TP_NOMINAL numeric(19,2),
    @PL_M_TP_QTYEQ numeric(24,8),
    @PL_M_QTY_INDEX numeric(3,0)
)
RETURNS numeric(28,8)
AS
BEGIN
	RETURN 
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'IRS', 'OSWP', 'FXD', 'FRA') THEN
				CASE
                    WHEN @COM_leg_LEG = 1 THEN ABS(@PL_M_TP_NOMINAL)
                    WHEN @COM_leg_LEG = 2 THEN ABS(@PL_M_TP_QTYEQ)
			    ELSE NULL
			    END
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			WHEN @mxContractType IN ('CS') THEN
				CASE
                    WHEN @COM_leg_LEG = 2 THEN ABS(@PL_M_TP_NOMINAL)
                    WHEN @COM_leg_LEG = 1 THEN ABS(@PL_M_TP_QTYEQ)
			    ELSE NULL
			    END              
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_CD ----------------------------------------------------
            ---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
            ---------------------------------------------------- CRS_REPO ----------------------------------------------------
            ---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'CF', 'LN_BR', 'REPO', 'CDS', 'FUT') THEN ABS(@PL_M_TP_NOMINAL)
            ------------------------------------------ CRS_XSW ----------------------------------------------------
			WHEN @mxContractType = 'XSW' THEN
                CASE
                    WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 0) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 1) THEN ABS(@PL_M_TP_NOMINAL) 
                    WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 1) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 0) THEN ABS(@PL_M_TP_QTYEQ)
			        ELSE NULL
                END
            ---------------------------------------------------- CRS_OPT ----------------------------------------------------
            WHEN @mxContractType IN ('OPT', 'FDB', 'NDB','SCF') THEN @PL_M_TP_NOMINAL
	    ELSE NULL
	    END

END
GO