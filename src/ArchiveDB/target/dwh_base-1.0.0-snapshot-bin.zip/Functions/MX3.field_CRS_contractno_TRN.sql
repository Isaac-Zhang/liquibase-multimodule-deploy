--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_contractno_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_contractno_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_contractno_TRN](@PL_M_TP_INT varchar(1),@PL_M_TP_INITSD varchar(1),@PL_M_NB numeric(10,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_contractno_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_contractno_TRN]
(
	@PL_M_TP_INT varchar(1),
    @PL_M_TP_INITSD varchar(1),
	@PL_M_NB numeric(10,0)
)
RETURNS varchar(15)
AS
BEGIN
	RETURN
        CASE WHEN @PL_M_TP_INT = 'Y' AND @PL_M_TP_INITSD = 'N' THEN
			RTRIM(LTRIM(@PL_M_NB)) + RTRIM(LTRIM(@PL_M_TP_INITSD))
		ELSE
			RTRIM(LTRIM(@PL_M_NB))
		END
END
GO