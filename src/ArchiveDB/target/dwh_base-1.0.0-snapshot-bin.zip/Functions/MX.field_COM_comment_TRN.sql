--liquibase formatted sql

--changeSet func:Initial-MX-field_COM_comment_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_COM_comment_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_COM_comment_TRN](@COM_contractFamily varchar(10),@CRD_COMMENT varchar(50),@EQD_COMMENT varchar(50),@IRD_COMMENT varchar(50),@CURR_COMMENT varchar(50)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_COM_comment_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_COM_comment_TRN](
@COM_contractFamily varchar(10), 
@CRD_COMMENT varchar(50),
@EQD_COMMENT varchar(50),
@IRD_COMMENT varchar(50),
@CURR_COMMENT varchar(50)
)
RETURNS varchar(50)
AS
BEGIN
  RETURN
	CASE
		       ---- EQD ----
		WHEN @COM_contractFamily = 'EQD'  THEN
			 @EQD_COMMENT
                ---- IRD ----
        WHEN @COM_contractFamily = 'IRD'  THEN
			 @IRD_COMMENT
                ---- CURR ----
		WHEN @COM_contractFamily = 'CURR' THEN
			 @CURR_COMMENT
		        ---- CRD ---	
		WHEN @COM_contractFamily = 'CRD' THEN
              @CRD_COMMENT 
          ELSE NULL
			
  	END
END
GO