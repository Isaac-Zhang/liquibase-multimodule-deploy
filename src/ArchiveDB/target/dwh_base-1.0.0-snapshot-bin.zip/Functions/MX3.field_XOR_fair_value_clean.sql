--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_fair_value_clean-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_fair_value_clean', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_fair_value_clean](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@reportDate date,@PL_M_TP_STATUS1 varchar(10),@PL_M_PL_FMV1 numeric(23,6),@PL_M_PL_FMVCL1 numeric(23,6),@PL_M_PL_FPFRV1 numeric(23,6),@PL_M_TP_LQTYS1 numeric(24,8),@PL_M_PL_CGU1 numeric(23,6),@PL_M_PLIRDFPV11 numeric(16,2),@PL_M_PLIRDFPV21 numeric(16,2),@PL_M_PLIRDACC11 numeric(16,2),@PL_M_PACK_REF numeric(10,0),@PL_M_MP_UPRC1 numeric(21,11),@PL_M_TP_DTEPMT datetime,@M_METHOD varchar(20),@COM_contractTypology_TRN varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_fair_value_clean-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX3].[field_XOR_fair_value_clean]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @reportDate date,
    @PL_M_TP_STATUS1 varchar(10),
    @PL_M_PL_FMV1 numeric(23,6),
    @PL_M_PL_FMVCL1 numeric(23,6),
    @PL_M_PL_FPFRV1 numeric(23,6),
    @PL_M_TP_LQTYS1 numeric(24,8),
    @PL_M_PL_CGU1 numeric(23,6),
    @PL_M_PLIRDFPV11 numeric(16,2),
    @PL_M_PLIRDFPV21 numeric(16,2),
    @PL_M_PLIRDACC11 numeric(16,2),
    @PL_M_PACK_REF numeric(10,0),
    @PL_M_MP_UPRC1 numeric(21,11),
    @PL_M_TP_DTEPMT datetime,
    @M_METHOD varchar(20),
	@COM_contractTypology_TRN varchar(20)
)
RETURNS numeric(28,8)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PL_FMV1)
				WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PL_FMV1
			END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN 0
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PL_FMV1)
				WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PL_FMV1
			END
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PL_CGU1)
				WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PL_CGU1
			END
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV11)
				WHEN @PL_M_TP_STATUS1 = 'DEAD'
				THEN 0
				ELSE @PL_M_PLIRDFPV11
				END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV21)
				WHEN @PL_M_TP_STATUS1 = 'DEAD'
				THEN 0
				ELSE @PL_M_PLIRDFPV21
				END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TP_NBLTI>0.AND.LNK_METHOD='Funding swap',0, IIF(TP_STATUS1='DEAD',0,PL_FMV1-PLIRDACC11))
			WHEN @PL_M_PACK_REF > 0 AND @M_METHOD LIKE '%Funding swap%'
			THEN 0
			ELSE
				CASE --IIF(TP_STATUS1='DEAD',0,PL_FMV1-PLIRDACC11)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PL_FMV1 - @PL_M_PLIRDACC11
			END
			END
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV11)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV11
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV21)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV21
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN
			CASE --IIF(TP_STATUS1='DEAD',0,PL_FMVCL1)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE CASE
				WHEN @reportDate < @PL_M_TP_DTEPMT
				THEN @PL_M_PL_FMVCL1
				ELSE @PL_M_PL_FMVCL1 + @PL_M_PL_FPFRV1
				END
			END
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TP_STATUS1='DEAD',0,PL_FMV1)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PL_FMV1
			END
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV11)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV11
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV21)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV21
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV11)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV11
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV21)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV21
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PL_FMV1)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PL_FMV1
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PL_FMV1)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PL_FMV1
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF' AND @COM_contractTypology_TRN NOT LIKE '%_ED'
			THEN 0
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF' AND @COM_contractTypology_TRN LIKE '%_ED'
			THEN @PL_M_PL_FMV1 --test
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV21)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV21
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_STATUS1='DEAD',0,PLIRDFPV11)
			WHEN @PL_M_TP_STATUS1 = 'DEAD'
			THEN 0
			ELSE @PL_M_PLIRDFPV11
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN @PL_M_TP_LQTYS1 * @PL_M_MP_UPRC1
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN @PL_M_PLIRDFPV11
		ELSE NULL
		END
END

