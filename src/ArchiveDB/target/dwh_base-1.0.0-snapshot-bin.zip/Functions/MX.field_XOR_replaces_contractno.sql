--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_replaces_contractno-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_replaces_contractno', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_replaces_contractno](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@IRD_M_GWB_LNK varchar(12),@EQD_M_GWB_LNK varchar(12),@CRD_M_GWB_LNK varchar(12),@CURR_M_GWB_LNK varchar(12),@PL_M_MRPL_FLAG varchar(1),@PL_M_TP_CREATOR numeric(10,0),@PL_M_TP_VALSTAT varchar(4),@PL_M_TP_TYPO varchar(20),@LTI_TMPL_M_NAME varchar(20),@PL_M_TP_BUY varchar(1),@PL_M_TP_NBLTI numeric(10,0),@PL_M_TP_RTPR0 varchar(1),@PL_M_TP_RTPR1 varchar(1),@LTI_M_METHOD varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_replaces_contractno-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_replaces_contractno]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @IRD_M_GWB_LNK varchar(12),
    @EQD_M_GWB_LNK varchar(12),
    @CRD_M_GWB_LNK varchar(12),
    @CURR_M_GWB_LNK varchar(12),
    @PL_M_MRPL_FLAG varchar(1),
    @PL_M_TP_CREATOR numeric(10,0),
    @PL_M_TP_VALSTAT varchar(4),
    
    -- Felds needed for XOR_assetLiability
    @PL_M_TP_TYPO varchar(20),
    @LTI_TMPL_M_NAME varchar(20),
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_NBLTI numeric(10,0),
    @PL_M_TP_RTPR0 varchar(1),
    @PL_M_TP_RTPR1 varchar(1),
    @LTI_M_METHOD varchar(20)
)
RETURNS varchar(12)
AS
BEGIN
	RETURN
		CASE
			WHEN
				RTRIM(LTRIM(CASE
				------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
				THEN @EQD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
				THEN @CURR_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
				THEN @CRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
				THEN ''
				------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
				THEN @CURR_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
				WHEN @COM_contractGroup_TRN = 'OPT'
				THEN
					CASE
				WHEN @COM_contractFamily_TRN = 'IRD'
				THEN @IRD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CURR'
				THEN @CURR_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'EQD'
				THEN @EQD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CRD'
				THEN @CRD_M_GWB_LNK
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
				THEN
					CASE
				WHEN @COM_contractFamily_TRN = 'IRD'
				THEN @IRD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CURR'
				THEN @CURR_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'EQD'
				THEN @EQD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CRD'
				THEN @CRD_M_GWB_LNK
				ELSE ''
				END
				ELSE ''
				END))
					<>
				''
			THEN
					CASE
				------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
				THEN @EQD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
				THEN @CURR_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
				THEN @CRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
				THEN @IRD_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
				THEN ''
				------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
				THEN @CURR_M_GWB_LNK
				------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
				WHEN @COM_contractGroup_TRN = 'OPT'
				THEN
					CASE
				WHEN @COM_contractFamily_TRN = 'IRD'
				THEN @IRD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CURR'
				THEN @CURR_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'EQD'
				THEN @EQD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CRD'
				THEN @CRD_M_GWB_LNK
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
				THEN
					CASE
				WHEN @COM_contractFamily_TRN = 'IRD'
				THEN @IRD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CURR'
				THEN @CURR_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'EQD'
				THEN @EQD_M_GWB_LNK
				WHEN @COM_contractFamily_TRN = 'CRD'
				THEN @CRD_M_GWB_LNK
				ELSE ''
				END
				ELSE ''
				END
			WHEN
				RTRIM(LTRIM(CASE
				------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(TP_VALSTAT<>'MIGM'.AND.MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_TP_VALSTAT <> 'MIGM' AND @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
				WHEN @COM_contractGroup_TRN = 'OPT'
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				ELSE ''
				END))
					<>
				''
			THEN
					CASE
				------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(TP_VALSTAT<>'MIGM'.AND.MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_TP_VALSTAT <> 'MIGM' AND @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
				WHEN @COM_contractGroup_TRN = 'OPT'
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
				WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
				THEN
					CASE --IIF(MRPL_FLAG='Y'.AND.TP_CREATOR>0,TRIM(STR(TP_CREATOR))+A_OR_L,'')
				WHEN @PL_M_MRPL_FLAG = 'Y' AND @PL_M_TP_CREATOR > 0
				THEN RTRIM(LTRIM(@PL_M_TP_CREATOR)) + 
                    MX.field_XOR_assetLiability(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, @COM_leg_LEG, @COM_quantityIndex_TRN,
                        @PL_M_TP_TYPO, @LTI_TMPL_M_NAME, @PL_M_TP_BUY, @PL_M_TP_NBLTI, @PL_M_TP_RTPR0, @PL_M_TP_RTPR1, @LTI_M_METHOD)
				ELSE ''
				END
				ELSE ''
				END
			ELSE ''
			END
END
GO