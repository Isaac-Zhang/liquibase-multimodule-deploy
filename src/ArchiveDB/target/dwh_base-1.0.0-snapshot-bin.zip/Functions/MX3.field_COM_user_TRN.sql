--liquibase formatted sql

--changeSet func:Initial-MX3-field_COM_user_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_COM_user_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_COM_user_TRN](@COM_contractFamily varchar(10),@CRD_USER varchar(50),@EQD_USER varchar(50),@IRD_USER varchar(50),@CURR_USER varchar(50)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_COM_user_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_COM_user_TRN](
@COM_contractFamily varchar(10), 
@CRD_USER varchar(50),
@EQD_USER varchar(50),
@IRD_USER varchar(50),
@CURR_USER varchar(50)
)
RETURNS varchar(50)
AS
BEGIN
  RETURN
	CASE
		       ---- EQD ----
		WHEN @COM_contractFamily = 'EQD'  THEN
			 @EQD_USER
                ---- IRD ----
        WHEN @COM_contractFamily = 'IRD'  THEN
			 @IRD_USER
                ---- CURR ----
		WHEN @COM_contractFamily = 'CURR' THEN
			 @CURR_USER
		        ---- CRD ---	
		WHEN @COM_contractFamily = 'CRD' THEN
              @CRD_USER
          ELSE NULL
			
  	END
END
GO