--liquibase formatted sql

--changeSet func:Initial-MX-field_barrierWindowStartDate-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_barrierWindowStartDate', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_barrierWindowStartDate](@mxContractType varchar(10),@PL_M_TP_FXBRWSD date) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_barrierWindowStartDate-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_barrierWindowStartDate]
(
	@mxContractType varchar(10), 
	@PL_M_TP_FXBRWSD date
)
RETURNS DATE
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType IN ('OPT', 'FDB', 'NDB') THEN @PL_M_TP_FXBRWSD
        ELSE NULL
        END
END
GO