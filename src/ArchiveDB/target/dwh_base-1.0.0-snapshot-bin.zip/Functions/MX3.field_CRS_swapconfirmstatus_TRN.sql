--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_swapconfirmstatus_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_swapconfirmstatus_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_swapconfirmstatus_TRN](@mxContractType varchar(10),@IRD_M_LTM_STATUS varchar(25)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_swapconfirmstatus_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_swapconfirmstatus_TRN]
(
	@mxContractType varchar(10),
    @IRD_M_LTM_STATUS varchar(25)
)
RETURNS varchar(25)
AS
BEGIN
	RETURN
	    CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'BOND', 'CS', 'IRS', 'OSWP', 'CF')
			THEN @IRD_M_LTM_STATUS
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
		ELSE NULL
		END
END
GO