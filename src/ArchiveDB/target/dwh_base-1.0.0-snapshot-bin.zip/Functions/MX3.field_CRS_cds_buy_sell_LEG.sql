--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_cds_buy_sell_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_cds_buy_sell_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_cds_buy_sell_LEG](@mxContractType varchar(10),@PL_M_TP_RTPR0 varchar(1)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_cds_buy_sell_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_cds_buy_sell_LEG]
(
	@mxContractType varchar(10), 
	@PL_M_TP_RTPR0 varchar(1)
)
RETURNS varchar(1)
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType = 'CDS' THEN @PL_M_TP_RTPR0 ELSE NULL END
END
GO