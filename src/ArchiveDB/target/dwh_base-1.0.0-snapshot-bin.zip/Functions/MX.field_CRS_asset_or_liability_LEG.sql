--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_asset_or_liability_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_asset_or_liability_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_asset_or_liability_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTPR0 varchar(1),@PL_M_TP_RTPR1 varchar(1),@PL_M_TP_BUY varchar(1),@PL_M_TP_RTCCP01 numeric(19,2),@PL_M_QTY_INDEX numeric(3,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_asset_or_liability_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX].[field_CRS_asset_or_liability_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
    @PL_M_TP_RTPR0 varchar(1),
    @PL_M_TP_RTPR1 varchar(1),
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTCCP01 numeric(19,2),
    @PL_M_QTY_INDEX numeric(3,0)
)
RETURNS varchar(1)
AS
BEGIN
    RETURN
        CASE
            ---------------------------------------------------- CRS_ASWP ----------------------------------------------------
	        ---------------------------------------------------- CRS_CS ----------------------------------------------------
	        ---------------------------------------------------- CRS_IRS ----------------------------------------------------
	        WHEN @mxContractType IN ('ASWP', 'CS', 'IRS','OSWP') THEN
		        CASE 
                    WHEN @COM_leg_LEG = 1 THEN 
                        CASE WHEN @PL_M_TP_RTPR0 = 'R' THEN 'A' ELSE 'L' END
	                WHEN @COM_leg_LEG = 2 THEN 
                        CASE WHEN @PL_M_TP_RTPR1 = 'R' THEN 'A' ELSE 'L' END
	                ELSE NULL
	        END
	        ---------------------------------------------------- CRS_BOND ----------------------------------------------------
	        ---------------------------------------------------- CRS_FUT ----------------------------------------------------
	        ---------------------------------------------------- CRS_REPO ----------------------------------------------------
	        WHEN @mxContractType IN ('BOND', 'FUT', 'REPO', 'CF', 'OPT') THEN 
                CASE WHEN @PL_M_TP_BUY = 'B' THEN 'A' ELSE 'L' END
	        ---------------------------------------------------- CRS_CD ----------------------------------------------------
	        WHEN @mxContractType IN ('CD') THEN  
	            CASE WHEN @PL_M_TP_RTCCP01 < 0 THEN 'L' ELSE 'A' END
	        ---------------------------------------------------- CRS_CDS----------------------------------------------------
	        WHEN @mxContractType IN ('CDS') THEN 
	            CASE WHEN @PL_M_TP_RTPR0 = 'R' THEN 'L' ELSE 'A' END
			---------------------------------------------------- SCF ----------------------------------------------------
			WHEN @mxContractType IN ('SCF') THEN --embedded scf test
	            CASE WHEN @PL_M_TP_RTPR0 = 'R' THEN 'A' ELSE 'L' END
	        ---------------------------------------------------- CRS_FRA ----------------------------------------------------
	        WHEN @mxContractType = 'FRA' THEN 
		        CASE 
                    WHEN @COM_leg_LEG = 1 THEN 
                        CASE WHEN @PL_M_TP_RTPR0 = 'R' THEN 'A' ELSE 'L' END
	                WHEN @COM_leg_LEG = 2 THEN 
                        CASE WHEN @PL_M_TP_RTPR1 = 'R' THEN 'A' ELSE 'L' END
	                ELSE NULL
	        END
	        ---------------------------------------------------- CRS_FXD,CRS_XSW---------------------------------------------
	        WHEN @mxContractType IN ('FXD','XSW') THEN 
		        CASE
                    WHEN @COM_leg_LEG = 1 THEN
	                    CASE WHEN @PL_M_TP_BUY = 'B' THEN 'A' ELSE 'L' END
	                WHEN @COM_leg_LEG = 2 THEN
		                CASE WHEN @PL_M_TP_BUY = 'B' THEN 'L' ELSE 'A' END
	                ELSE NULL
	            END
	        ---------------------------------------------------- CRS_XSW ----------------------------------------------------
	        /*
			WHEN @mxContractType = 'XSW' THEN
	            CASE
			        WHEN (@COM_leg_LEG = 1 AND @PL_M_TP_SPTFWD = 'S') OR (@COM_leg_LEG = 2 AND @PL_M_TP_SPTFWD = 'F') THEN
                        CASE WHEN @PL_M_TP_BUY = 'B' THEN 'A' ELSE 'L' END
                    WHEN (@COM_leg_LEG = 1 AND @PL_M_TP_SPTFWD = 'F') OR (@COM_leg_LEG = 2 AND @PL_M_TP_SPTFWD = 'S') THEN
                        CASE WHEN @PL_M_TP_BUY = 'B' THEN 'L' ELSE 'A' END
			        ELSE NULL
			    END
			*/
			/*
			WHEN @mxContractType = 'XSW' THEN
	            CASE @COM_leg_LEG
			        WHEN 1 THEN
			            CASE
			                WHEN @PL_M_QTY_INDEX = 0 AND @PL_M_TP_BUY = 'B' THEN 'A'
                            WHEN @PL_M_QTY_INDEX = 0 AND @PL_M_TP_BUY = 'S' THEN 'L'
                            WHEN @PL_M_QTY_INDEX = 1 AND @PL_M_TP_BUY = 'B' THEN 'L'
                            WHEN @PL_M_QTY_INDEX = 1 AND @PL_M_TP_BUY = 'S' THEN 'A'
                        END
                    WHEN 2 THEN
                        CASE
                            WHEN @PL_M_QTY_INDEX = 0 AND @PL_M_TP_BUY = 'B' THEN 'L'
                            WHEN @PL_M_QTY_INDEX = 0 AND @PL_M_TP_BUY = 'S' THEN 'A'
                            WHEN @PL_M_QTY_INDEX = 1 AND @PL_M_TP_BUY = 'B' THEN 'A'
                            WHEN @PL_M_QTY_INDEX = 1 AND @PL_M_TP_BUY = 'S' THEN 'L'
                        END
			        ELSE NULL
			    END
			*/		    
	        ---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
	        WHEN @mxContractType = 'LN_BR' THEN 
	            CASE WHEN @PL_M_TP_RTPR0 = 'R' THEN 'A' ELSE 'L' END
	        ---------------------------------------------------- CRD_FDB ----------------------------------------------------
			---------------------------------------------------- CRD_NDB ----------------------------------------------------
	        WHEN @mxContractType IN ('FDB', 'NDB') THEN 
	            CASE WHEN @PL_M_TP_RTPR0 = 'R' THEN 'L' ELSE 'A' END
        ELSE NULL
    END
END