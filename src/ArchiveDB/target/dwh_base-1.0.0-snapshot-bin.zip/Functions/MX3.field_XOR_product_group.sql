--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_product_group-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_product_group', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_product_group](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_SPTFWD varchar(1),@PL_M_PACK_REF numeric(10,0),@PL_M_TP_TYPO varchar(20),@PL_M_TP_PFOLIO varchar(15),@M_METHOD varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_product_group-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX3].[field_XOR_product_group]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_SPTFWD varchar(1),
    @PL_M_PACK_REF numeric(10,0),
    @PL_M_TP_TYPO varchar(20),
    @PL_M_TP_PFOLIO varchar(15),
    @M_METHOD varchar(20)
)
RETURNS varchar(40)
AS
BEGIN
	RETURN
		CASE
			  ------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			  THEN 'Derivatives'
			  ------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			  THEN 'Derivatives'
			  ------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			  THEN 'Derivatives'
			  ------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			  THEN 'Derivatives'
			  ------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			  THEN
				  CASE --IIF(TP_SPTFWD='S','Fx spot', IIF(TP_SPTFWD='F','Fx spot','-'))
			  WHEN @COM_leg_LEG = 1
			  THEN CASE
				   WHEN @PL_M_TP_SPTFWD = 'S'
				 THEN 'Fx spot'
				 WHEN @PL_M_TP_SPTFWD = 'F'
				 THEN 'Fx spot'
				 ELSE '-'
				 END
			  WHEN @COM_leg_LEG = 2
			  THEN CASE
				   WHEN @PL_M_TP_SPTFWD = 'S'
				 THEN 'Fx spot'
				 WHEN @PL_M_TP_SPTFWD = 'F'
				 THEN 'Fx spot'
				 ELSE '-'
				 END
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			  THEN CASE --IIF(TP_NBLTI>0.AND.LNK_METHOD='Funding swap','Derivatives', IIF('Rewrite'$TP_TYPO.AND.('IRS'$TP_TYPO.OR.'CS'$TP_TYPO),'Derivatives', IIF(TP_PFOLIO='MARSEK'.OR.TP_PFOLIO='STASEKSEK','Internal','Loan')))
				 WHEN @PL_M_PACK_REF > 0 AND @M_METHOD = 'Funding swap'
			   THEN 'Derivatives'
			   ELSE
				   CASE --IIF('Rewrite'$TP_TYPO.AND.('IRS'$TP_TYPO.OR.'CS'$TP_TYPO),'Derivatives', IIF(TP_PFOLIO='MARSEK'.OR.TP_PFOLIO='STASEKSEK','Internal','Loan'))
				 WHEN @PL_M_TP_TYPO LIKE '%Rewrite%' AND (@PL_M_TP_TYPO LIKE '%IRS%' OR @PL_M_TP_TYPO LIKE '%CS%')
				 THEN 'Derivatives'
				 ELSE
					 CASE --IIF(TP_PFOLIO='MARSEK'.OR.TP_PFOLIO='STASEKSEK','Internal','Loan')
				   WHEN @PL_M_TP_PFOLIO = 'MARSEK' OR @PL_M_TP_PFOLIO = 'STASEKSEK'
				   THEN 'Internal'
				   ELSE 'Loan'
				   END
				 END
			   END
			  ------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN 'Derivatives'
			  WHEN @COM_leg_LEG = 2
			  THEN 'Derivatives'
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			  THEN 'Securities'
			  ------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			  THEN 'Credit Derivatives'
			  ------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN 'Derivatives'
			  WHEN @COM_leg_LEG = 2
			  THEN 'Derivatives'
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN 'Derivatives'
			  WHEN @COM_leg_LEG = 2
			  THEN 'Derivatives'
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN 'Loan'
			  WHEN @COM_leg_LEG = 2
			  THEN 'Loan'
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			  THEN 'Derivatives'
			  ------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN 'Derivatives'
			  WHEN @COM_leg_LEG = 2
			  THEN 'Derivatives'
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			  WHEN @COM_contractGroup_TRN = 'OPT'
			  THEN 'Derivatives'
			  ------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			  THEN 'Derivatives'
		ELSE NULL
		END
END

