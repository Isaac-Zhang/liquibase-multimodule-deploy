--liquibase formatted sql

--changeSet func:Initial-PF-fnAmortizationViewProFinance-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('PF.fnAmortizationViewProFinance', 'TF') IS NULL EXEC('CREATE FUNCTION [PF].[fnAmortizationViewProFinance](@reportDate date,@EODSOD varchar(3)) RETURNS @tab TABLE ([contractno] varchar(30),[CCY_id] varchar(3),[pmnt_date] date,[pmnt_type] varchar(10),[pmnt_amount] numeric(28,8),[pmnt_outstanding] numeric(28,8)) AS BEGIN RETURN END')
GO



--changeSet func:Initial-PF-fnAmortizationViewProFinance-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [PF].[fnAmortizationViewProFinance]
(
	@reportDate		DATE,
	@EODSOD			VARCHAR(3) = 'EOD'
)
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : PF.fnAmortizationViewProFinance
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate             DATE
  -- !                       @EODSOD                 VARCHAR(3)
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with contracts from ProFinance the given date. 
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s      :
  -- !                select * from PF.fnAmortizationViewProFinance('2010-09-20', 'EOD');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2011-02-17 JoJo  Initial version
  -- !                       2011-03-07 JoJo  Changed to join with table variable instead och HISTORY-table
  -- !                       2011-09-16 ChTh  Reworked with recursive CTE
  -- !                       2012-01-13 JoJo  Added split from SC10784
  -- !                       2012-01-30 JoJo  Made loading backwards compatible. Old logic pre 2011-12-31, new otherwise.
  -- +----------------------------------------------------------------------------------------------------------------
RETURNS @proFinanceAmortization TABLE
(
    contractno varchar(30) NOT NULL,
	[CCY_id] [varchar] (3) NOT NULL,
    [pmnt_date] date NOT NULL,
    [pmnt_type] varchar(10) NULL,
    [pmnt_amount] numeric(28,8),
    [pmnt_outstanding] numeric(28,8)
)
AS
BEGIN
	IF DATEDIFF(d, @reportDate, '2011-12-31') >= 0
	BEGIN
		INSERT INTO @proFinanceAmortization(contractno, CCY_id, pmnt_date, pmnt_type, pmnt_amount, pmnt_outstanding)
		SELECT contractno, CCY_id, pmnt_date, pmnt_type, pmnt_amount, pmnt_outstanding
		  FROM [PF].[fnAmortizationViewProFinancePre20111231](@reportDate, @EODSOD);

		RETURN;
	END;

    DECLARE @reportDateEnd date = DATEADD(dd, 1, @reportDate)
	DECLARE @exportDateTime		DATETIME;

    SELECT @exportDateTime = MAX(ExportDate) 
    FROM DWH_HISTORY.DWH.PF_ExportedAmortization 
    WHERE ReportDate >= @reportDate AND ReportDate <= @reportDateEnd

    --------------------------------------------------------------
    --< Skapa temporära tabeller för kontrakt och amorteringar >--
    --------------------------------------------------------------
	-- SC10784 START
	DECLARE @proFinanceContract TABLE
	(
		[id] [int] NOT NULL,
		[value_date] [date] NOT NULL,
		[expt_id] [varchar](25) NOT NULL,
		[contractno] [varchar](15) NOT NULL,
		[currency] [varchar](3) NULL,
		[maturity_date] [datetime] NULL,
		[principal_amount_orig] [numeric](28, 8) NULL,
		[principal_amount_out] [numeric](28, 8) NULL,
		[exposure_type] [varchar](15) NULL,
		[statusCode]    [varchar] (3) NULL,
		[PaidSupplier] [money] NULL,
		[FutureValue] [money] NULL
	);
	-- SC10784 SLUT

    DECLARE @pf_exposure_load TABLE (
        contractno varchar(30),
        contract varchar(30),
        contractLine varchar(5),
        maturity_date date,
        principal_amount_out numeric(28,8),
        currency varchar(3),
        FutureValue money -- SC10784
        PRIMARY KEY CLUSTERED (contract, contractLine)
    )
      
    DECLARE @pf_amortization_load TABLE (
        contract varchar(30),
        contractLine varchar(5),
        period smallint,
        amortizationDate date,
        amortization numeric(28,8),
        PRIMARY KEY CLUSTERED (contract, contractLine, period)
    )
    
    --------------------------------------------------------------
    --< Hämta grunddata                                        >--
    --------------------------------------------------------------
	-- SC10784 START
	INSERT INTO @proFinanceContract(id, value_date, expt_id, contractno, currency, maturity_date, principal_amount_orig, principal_amount_out,
				exposure_type, statusCode, PaidSupplier, FutureValue)
	SELECT id, value_date, expt_id, contractno, currency, maturity_date, principal_amount_orig, principal_amount_out,
				exposure_type, statusCode, PaidSupplier, FutureValue
	FROM PF.fnContractViewProFinance(@reportDate, @EODSOD);
	-- SC10784 SLUT

    INSERT INTO @pf_exposure_load
	-- SC10784 START
    SELECT
      contractno
    , LTRIM(RTRIM(LEFT(RIGHT(contractno, 11), 7))) [Contract]
    --, REPLACE(RIGHT(RIGHT(contractno, 11), 4), '0', '') [ContractLine]
	, RIGHT(LEFT(contractno, 9), 1) [ContractLine]
    , maturity_date
    , principal_amount_out
    , currency
    , FutureValue
    FROM @proFinanceContract
	WHERE expt_id = 'Disbursed'
	UNION ALL
    SELECT
      contractno
    , LTRIM(RTRIM(LEFT(RIGHT(contractno, 11), 7))) [Contract]
    --, REPLACE(RIGHT(RIGHT(contractno, 11), 4), '0', '') [ContractLine]
	, RIGHT(LEFT(contractno, 9), 1) [ContractLine] -- SC10784
    , maturity_date
    , principal_amount_out
    , currency
    , FutureValue
    FROM @proFinanceContract A
	WHERE expt_id = 'Facility'
	AND NOT EXISTS(SELECT * 
					 FROM @proFinanceContract B
					WHERE LTRIM(RTRIM(LEFT(RIGHT(B.contractno, 11), 7))) = LTRIM(RTRIM(LEFT(RIGHT(A.contractno, 11), 7)))
					  AND B.expt_id = 'Disbursed');
	/*
    SELECT
      contractno
    , LTRIM(RTRIM(LEFT(RIGHT(contractno, 11), 7))) [Contract]
    , REPLACE(RIGHT(RIGHT(contractno, 11), 4), '0', '') [ContractLine]
    , maturity_date
    , principal_amount_out
    , currency
    FROM @proFinanceContract
	WHERE expt_id = 'Facility';
	*/
	-- SC10784 SLUT
           
    INSERT INTO @pf_amortization_load           
    SELECT 
        LTRIM(RTRIM(ea.[Contract])) AS Contract
        , LTRIM(RTRIM(ea.ContractLine)) AS ContractLine
        , ea.Period
        , COALESCE(ea.DueDate, ea.EndDate) AS amortizationDate
        , ea.Amortization
    FROM DWH_HISTORY.DWH.PF_ExportedAmortization ea
    WHERE ea.ExportDate = @exportDateTime
    AND ea.[Contract] <> '5000101-1'

   ;WITH FIRSTAMO AS (
      --------------------------------------------------------------
      --< Bestäm vilken av amorteringarna som är den första      >--
      --< giltiga amorteringen                                   >--
      --------------------------------------------------------------
      SELECT A.Contract, A.ContractLine, MIN(Period) AS minPeriod
      FROM @pf_amortization_load AS A
      WHERE @reportDate < A.amortizationDate
      GROUP BY A.Contract, A.ContractLine
      
   ), CTE AS (
      --------------------------------------------------------------
      --< Rekursivt anrop för att minska ner utestående belopp   >--
      --< per amortering. Observera att detta även kan öka på    >--
      --< beloppet om amorteringen är negativ                    >--
      --------------------------------------------------------------
      SELECT 
           A.Contract
         , A.ContractLine
         , A.Period
         , A.amortizationDate
         , E.principal_amount_out
         , A.Amortization
         , CONVERT(numeric(28,8), E.principal_amount_out - A.amortization) AS nominal_amount_out
      FROM @pf_exposure_load AS E
      INNER JOIN @pf_amortization_load A 
         ON E.Contract = A.Contract 
         AND E.ContractLine = A.ContractLine
      INNER JOIN FIRSTAMO AS F 
         ON A.Contract = F.Contract 
         AND A.ContractLine = F.ContractLine 
         AND A.Period = F.minPeriod
      UNION ALL
      SELECT 
           THIS.Contract
         , THIS.ContractLine
         , THIS.Period
         , THIS.amortizationDate
         , PREV.nominal_amount_out
         , THIS.Amortization
         , CONVERT(numeric(28,8), PREV.nominal_amount_out - THIS.Amortization)
      FROM @pf_amortization_load AS THIS
      INNER JOIN CTE AS PREV 
         ON THIS.Contract = PREV.Contract 
         AND THIS.ContractLine = PREV.ContractLine 
         AND THIS.Period = PREV.Period + 1
      WHERE THIS.Period > 1 AND @reportDate < THIS.amortizationDate

   ), LASTAMO AS (
      --------------------------------------------------------------
      --< Ta reda på den sista posten i rekursionen ovan.        >--
      --< Detta för att kunna bestämma återstående belopp för    >--
      --< att minska ner hela utestående beloppet till noll vid  >--
      --< maturity för kontraktet                                >--
      --------------------------------------------------------------
      SELECT Contract, ContractLine, MAX(Period) AS maxPeriod
      FROM CTE AS A
      GROUP BY Contract, ContractLine
   )
   INSERT INTO @proFinanceAmortization (
      contractno            , CCY_id                        , pmnt_date
    , pmnt_type             , pmnt_amount                   , pmnt_outstanding
   )
   --------------------------------------------------------------
   --< Hämta alla amorteringar och nedskrivet belopp från     >--
   --< rekursionen.                                           >--
   --------------------------------------------------------------  
   SELECT 
        E.contractno        , E.currency                    , CTE.amortizationDate
      , NULL                , -1 * CTE.Amortization         , CTE.nominal_amount_out
   FROM CTE
   INNER JOIN @pf_exposure_load E 
      ON CTE.Contract = E.Contract 
      AND CTE.ContractLine = E.ContractLine  
   
   UNION ALL
   --------------------------------------------------------------
   --< Skapa upp en sista post med typen 'RESIDUAL' om        >--
   --< utestående belopp inte har dragits ner till noll vid   >--
   --< sista amorteringen                                     >--
   --------------------------------------------------------------  
   SELECT 
        E.contractno        , E.currency                    , E.maturity_date
      , 'RESIDUAL'          , -ISNULL(E.FutureValue, 0) /* SC10784 -1 * A.nominal_amount_out*/     , 0
   FROM LASTAMO
   INNER JOIN CTE AS A 
      ON LASTAMO.Contract = A.Contract 
      AND LASTAMO.ContractLine = A.ContractLine 
      AND LASTAMO.maxPeriod = A.Period
   INNER JOIN @pf_exposure_load E 
      ON A.Contract = E.Contract 
      AND A.ContractLine = E.ContractLine
   WHERE A.nominal_amount_out > 0

	--START SC10784
	-- Splitta i CLCM och CLDD / Facility och Disbursed
	DECLARE @contractShare TABLE(
		[mainContract] [varchar](7) NULL,
		[paidContract] [varchar](15) NULL,
		[notPaidContract] [varchar](15) NULL,
		[totalNominal] [numeric](28, 8) NULL,
		[paidNominal] [numeric](28, 8) NULL,
		[notPaidNominal] [numeric](28, 8) NULL,
		[paidShare] [numeric](18, 12) NULL,
		[notPaidShare] [numeric](18, 12) NULL
	);

	INSERT INTO @contractShare(mainContract, paidContract, notPaidContract, totalNominal, paidNominal, notPaidNominal, paidShare, notPaidShare)
	SELECT LEFT(e.contractno, 7) AS mainContract,
		   (SELECT MIN(e2.contractno) FROM @proFinanceContract e2 WHERE e2.contractno = LEFT(e.contractno, 9) + '01') AS paidContract,
		   (SELECT MIN(e2.contractno) FROM @proFinanceContract e2 WHERE e2.contractno = LEFT(e.contractno, 9) + '00') AS notPaidContract,
		   (SELECT SUM(ISNULL(e2.principal_amount_out, 0)) FROM @proFinanceContract e2 WHERE e2.contractno LIKE LEFT(e.contractno, 9) + '0%') AS totalNominal,
		   (SELECT SUM(ISNULL(e2.principal_amount_out, 0)) FROM @proFinanceContract e2 WHERE e2.contractno = LEFT(e.contractno, 9) + '01') AS paidNominal,
		   (SELECT SUM(ISNULL(e2.principal_amount_out, 0)) FROM @proFinanceContract e2 WHERE e2.contractno = LEFT(e.contractno, 9) + '00') AS notPaidNominal,
		   CAST(000.00000 AS NUMERIC(18, 12)) AS paidShare,
		   CAST(000.00000 AS NUMERIC(18, 12)) AS notPaidShare
	  FROM @proFinanceContract e
	 WHERE e.expt_id = 'Facility';

	UPDATE @contractShare
	   SET paidShare = CAST(CASE WHEN totalNominal = 0 THEN 0 ELSE paidNominal / totalNominal END AS NUMERIC(18, 12)),
		   notPaidShare = CAST(CASE WHEN totalNominal = 0 THEN 0 ELSE notPaidNominal / totalNominal END AS NUMERIC(18, 12));

	WITH PAID AS (
		SELECT pe.contractno AS contractno,
			   a.CCY_id, a.pmnt_date, a.pmnt_type, a.pmnt_amount * cs.paidShare AS pmnt_amount, a.pmnt_outstanding
		  FROM @proFinanceContract pe
			INNER JOIN @contractShare cs ON pe.contractno = cs.paidContract
			INNER JOIN @proFinanceContract npe ON npe.contractno = cs.notPaidContract
			INNER JOIN @proFinanceAmortization a ON npe.contractno = a.contractno
	)
	INSERT INTO @proFinanceAmortization(contractno, CCY_id, pmnt_date, pmnt_type, pmnt_amount, pmnt_outstanding)
	SELECT contractno, CCY_id, pmnt_date, pmnt_type, pmnt_amount, pmnt_outstanding
	  FROM PAID;

	UPDATE a
	   SET pmnt_amount = a.pmnt_amount * cs.notPaidShare
	  FROM @proFinanceContract npe
		INNER JOIN @contractShare cs ON npe.contractno = cs.notPaidContract
		INNER JOIN @proFinanceAmortization a ON npe.contractno = a.contractno;

	-- Skapa inga 0-poster
	DELETE @proFinanceAmortization
	 WHERE pmnt_amount = 0;
	--SLUT SC10784

	RETURN;
END;
GO