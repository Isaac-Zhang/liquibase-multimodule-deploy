--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_product_type-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_product_type', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_product_type](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_SPTFWD varchar(1),@PL_M_PACK_REF numeric(10,0),@PL_M_TP_TYPO varchar(20),@PL_M_TP_PFOLIO varchar(15),@PL_M_TP_RTCUR0 varchar(3),@PL_M_TP_RTCUR1 varchar(3),@PL_M_TP_RTFV0 varchar(1),@PL_M_TP_RTFV1 varchar(1),@PL_M_TP_RTMRTE0 numeric(12,6),@PL_M_TP_DTETRN datetime,@M_METHOD varchar(20),@SECUDF_M_STRUCT_TYP varchar(25),@PL_M_TP_BUY varchar(1),@PL_M_TP_DTELST datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_DTEFLWL datetime,@PL_M_TP_RTMAT0 datetime,@PL_M_TP_RTMAT1 datetime,@SEC_M_SE_MAT datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_product_type-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX3].[field_XOR_product_type]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_SPTFWD varchar(1),
    @PL_M_PACK_REF numeric(10,0),
    @PL_M_TP_TYPO varchar(20),
    @PL_M_TP_PFOLIO varchar(15),
    @PL_M_TP_RTCUR0 varchar(3),
    @PL_M_TP_RTCUR1 varchar(3),
    @PL_M_TP_RTFV0 varchar(1),
    @PL_M_TP_RTFV1 varchar(1),
    @PL_M_TP_RTMRTE0 numeric(12,6),
    @PL_M_TP_DTETRN datetime,
    @M_METHOD varchar(20),
    @SECUDF_M_STRUCT_TYP varchar(25),

    --fields needed for XOR_maturity_date
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_DTELST datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_DTEFLWL datetime,
    @PL_M_TP_RTMAT0 datetime,
    @PL_M_TP_RTMAT1 datetime,
    @SEC_M_SE_MAT datetime
)
RETURNS varchar(40)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN 'cf'
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN --TRIM(PROD_T_CUR)+TRIM(PROD_T_EQD)+TRIM(PROD_T_IRD)
			CASE --PROD_T_CUR=IIF(TRIM(TRN_FMLY)$'CURR',IIF(TRIM(TRN_TYPE)$'SMP|SMPS','currvanopt',IIF(TRIM(TRN_TYPE)$'BAR','currbar','')),'')
			WHEN LTRIM(RTRIM(@COM_contractFamily_TRN)) LIKE '%CURR%'
			THEN
				CASE --IIF(TRIM(TRN_TYPE)$'SMP|SMPS','currvanopt',IIF(TRIM(TRN_TYPE)$'BAR','currbar',''))
			WHEN LTRIM(RTRIM(@COM_contractGroup_TRN)) IN ('SMP','SMPS')
			THEN 'currvanopt'
			ELSE
				CASE --IIF(TRIM(TRN_TYPE)$'BAR','currbar','')
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%BAR%'
				THEN 'currbar'
				ELSE ''
				END
			END
			ELSE ''
			END
			+
			CASE --PROD_T_EQD=IIF(TRIM(TRN_FMLY)$'EQD',IIF(TRIM(TRN_TYPE)$'OTC','eqdvanopt',IIF(TRIM(TRN_TYPE)$'BAR','eqdbaropt',IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt',''))),'')
			WHEN LTRIM(RTRIM(@COM_contractFamily_TRN)) LIKE '%EQD%'
			THEN
				CASE --IIF(TRIM(TRN_TYPE)$'OTC','eqdvanopt',IIF(TRIM(TRN_TYPE)$'BAR','eqdbaropt',IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt','')))
			WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%OTC%'
			THEN 'eqdvanopt'
			ELSE
				CASE --IIF(TRIM(TRN_TYPE)$'BAR','eqdbaropt',IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt',''))
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%BAR%'
				THEN 'eqdbaropt'
				ELSE
					CASE --IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt','')
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%ASI%'
				THEN 'eqdasiopt'
				ELSE ''
				END
				END
			END
			ELSE ''
			END
			+
			CASE --PROD_T_IRD=IIF(TRIM(TRN_FMLY)$'IRD',IIF(TRIM(TRN_GRP)$'OCF','capopt/floopt',IIF(TRIM(TRN_TYPE)$'OTC','irdbondvanopt','')),'')
			WHEN LTRIM(RTRIM(@COM_contractFamily_TRN)) LIKE '%IRD%'
			THEN
				CASE --IIF(TRIM(TRN_GRP)$'OCF','capopt/floopt',IIF(TRIM(TRN_TYPE)$'OTC','irdbondvanopt',''))
			WHEN LTRIM(RTRIM(@COM_contractGroup_TRN)) LIKE '%OCF%'
			THEN 'capopt/floopt'
			ELSE
				CASE --IIF(TRIM(TRN_TYPE)$'OTC','irdbondvanopt','')
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%OTC%'
				THEN 'irdbondvanopt'
				ELSE ''
				END
			END
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN 'fra'
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN 'fut'
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE ----IIF(TP_SPTFWD='S','fxspot', IIF(TP_SPTFWD='F','fxfwd','-'))
			WHEN @PL_M_TP_SPTFWD = 'S'
			THEN 'fxspot'
			WHEN @PL_M_TP_SPTFWD = 'F'
			THEN 'fxfwd'
			ELSE '-'
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE ----IIF(TP_SPTFWD='S','fxspot', IIF(TP_SPTFWD='F','fxfwd','-'))
			WHEN @PL_M_TP_SPTFWD = 'S'
			THEN 'fxspot'
			WHEN @PL_M_TP_SPTFWD = 'F'
			THEN 'fxfwd'
			ELSE '-'
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF(TP_NBLTI>0.AND.LNK_METHOD='Funding swap','fxsw', IIF('Rewrite'$TP_TYPO.AND.'leg'$TP_TYPO,'-1', IIF(TP_PFOLIO='MARSEK'.OR.TP_PFOLIO='STASEKSEK','intmmloan','mmln')))
			WHEN @PL_M_PACK_REF > 0 AND @M_METHOD = 'Funding swap'
			THEN 'fxsw'
			ELSE
				CASE --IIF('Rewrite'$TP_TYPO.AND.'leg'$TP_TYPO,'-1', IIF(TP_PFOLIO='MARSEK'.OR.TP_PFOLIO='STASEKSEK','intmmloan','mmln'))
			WHEN @PL_M_TP_TYPO LIKE '%Rewrite%' AND @PL_M_TP_TYPO LIKE '%leg%'
			THEN '-1'
			ELSE
				CASE --IIF(TP_PFOLIO='MARSEK'.OR.TP_PFOLIO='STASEKSEK','intmmloan','mmln')
				WHEN @PL_M_TP_PFOLIO = 'MARSEK' OR @PL_M_TP_PFOLIO = 'STASEKSEK'
				THEN 'intmmloan'
				ELSE 'mmln'
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF('PRDC'$LTI_TYPEN(),'powrevsw', IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw')))
			WHEN @M_METHOD LIKE '%PRDC%'
			THEN 'powrevsw'
			ELSE
				CASE --IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw'))
				WHEN @PL_M_TP_RTCUR0 = @PL_M_TP_RTCUR1
				THEN 'irs'
				ELSE
					CASE --IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw')
				WHEN @PL_M_TP_RTFV0 = @PL_M_TP_RTFV1
				THEN 'bassw'
				ELSE 'fxirsw'
				END
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF('PRDC'$LTI_TYPEN(),'powrevsw', IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw')))
			WHEN @M_METHOD LIKE '%PRDC%'
			THEN 'powrevsw'
			ELSE
				CASE --IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw'))
				WHEN @PL_M_TP_RTCUR0 = @PL_M_TP_RTCUR1
				THEN 'irs'
				ELSE
					CASE --IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw')
				WHEN @PL_M_TP_RTFV0 = @PL_M_TP_RTFV1
				THEN 'bassw'
				ELSE 'fxirsw'
				END
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN
			CASE --IIF('zbond'$PROD_TYPE1, IIF(ISBLANK(LTI_TYPEN())=1.OR.'FUND-Plain Vanilla'$LTI_TYPEN().OR.'ASWP'$LTI_TYPEN(),'zbond','fixcoupbo'), PROD_TYPE1)
			WHEN
				CASE --PROD_TYPE1=IIF('PRDC'$LTI_TYPEN(),'powrevbo',IIF('Asset Backed Security'$STRUCT_TYP,'abs',IIF(FIX_VAR='V','frn',IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo'))))
			WHEN LTRIM(RTRIM(@M_METHOD)) LIKE '%PRDC%'
			THEN 'powrevbo'
			ELSE
				CASE --IIF('Asset Backed Security'$STRUCT_TYP,'abs',IIF(FIX_VAR='V','frn',IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo')))
				WHEN @SECUDF_M_STRUCT_TYP LIKE '%Asset Backed Security%'
				THEN 'abs'
				ELSE
					CASE --IIF(FIX_VAR='V','frn',IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo'))
				WHEN @PL_M_TP_RTFV0 = 'V'
				THEN 'frn'
				ELSE
					CASE --IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo')
					WHEN @PL_M_TP_RTMRTE0 = 0
					THEN
						CASE --IIF(MATURITY-TP_DTETRN>547,'zbond','dispap')
					WHEN MX3.field_XOR_maturity_date(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, 
                        @COM_leg_LEG, @COM_quantityIndex_TRN, 
                        @PL_M_TP_BUY, @PL_M_TP_DTELST, @PL_M_TP_DTEEXP, @PL_M_TP_DTEFLWL,
                        @PL_M_TP_RTMAT0, @PL_M_TP_RTMAT1, @SEC_M_SE_MAT)
                        - @PL_M_TP_DTETRN > 547
					THEN 'zbond'
					ELSE 'dispap'
					END
					ELSE 'fixcoupbo'
					END
				END
				END
			END
				LIKE
			'%zbond%'
			THEN
				CASE --IIF(ISBLANK(LTI_TYPEN())=1.OR.'FUND-Plain Vanilla'$LTI_TYPEN().OR.'ASWP'$LTI_TYPEN(),'zbond','fixcoupbo')
			WHEN LTRIM(RTRIM(@M_METHOD)) = '' OR LTRIM(RTRIM(@M_METHOD)) LIKE '%FUND-Plain Vanilla%' OR LTRIM(RTRIM(@M_METHOD)) LIKE '%ASWP%'
			THEN 'zbond'
			ELSE 'fixcoupbo'
			END
			ELSE
				CASE --PROD_TYPE1=IIF('PRDC'$LTI_TYPEN(),'powrevbo',IIF('Asset Backed Security'$STRUCT_TYP,'abs',IIF(FIX_VAR='V','frn',IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo'))))
			WHEN LTRIM(RTRIM(@M_METHOD)) LIKE '%PRDC%'
			THEN 'powrevbo'
			ELSE
				CASE --IIF('Asset Backed Security'$STRUCT_TYP,'abs',IIF(FIX_VAR='V','frn',IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo')))
				WHEN @SECUDF_M_STRUCT_TYP LIKE '%Asset Backed Security%'
				THEN 'abs'
				ELSE
					CASE --IIF(FIX_VAR='V','frn',IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo'))
				WHEN @PL_M_TP_RTFV0 = 'V'
				THEN 'frn'
				ELSE
					CASE --IIF(TP_RTMRTE0=0,IIF(MATURITY-TP_DTETRN>547,'zbond','dispap'),'fixcoupbo')
					WHEN @PL_M_TP_RTMRTE0 = 0
					THEN
						CASE --IIF(MATURITY-TP_DTETRN>547,'zbond','dispap')
					WHEN MX3.field_XOR_maturity_date(
                        @COM_contractFamily_TRN, @COM_contractGroup_TRN, @COM_contractType_TRN, 
                        @COM_leg_LEG, @COM_quantityIndex_TRN, 
                        @PL_M_TP_BUY, @PL_M_TP_DTELST, @PL_M_TP_DTEEXP, @PL_M_TP_DTEFLWL,
                        @PL_M_TP_RTMAT0, @PL_M_TP_RTMAT1, @SEC_M_SE_MAT)
                        - @PL_M_TP_DTETRN > 547
					THEN 'zbond'
					ELSE 'dispap'
					END
					ELSE 'fixcoupbo'
					END
				END
				END
			END
			END
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN 'cdsw'
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw'))
			WHEN @PL_M_TP_RTCUR0 = @PL_M_TP_RTCUR1
			THEN 'irs'
			ELSE
				CASE
				WHEN @PL_M_TP_RTFV0 = @PL_M_TP_RTFV1
				THEN 'bassw'
				ELSE 'fxirsw'
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw'))
			WHEN @PL_M_TP_RTCUR0 = @PL_M_TP_RTCUR1
			THEN 'irs'
			ELSE
				CASE
				WHEN @PL_M_TP_RTFV0 = @PL_M_TP_RTFV1
				THEN 'bassw'
				ELSE 'fxirsw'
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN
				CASE --IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw'))
			WHEN @PL_M_TP_RTCUR0 = @PL_M_TP_RTCUR1
			THEN 'irs'
			ELSE
				CASE
				WHEN @PL_M_TP_RTFV0 = @PL_M_TP_RTFV1
				THEN 'bassw'
				ELSE 'fxirsw'
				END
			END
			WHEN @COM_leg_LEG = 2
			THEN
				CASE --IIF(TP_RTCUR0=TP_RTCUR1,'irs', IIF(TP_RTFV0=TP_RTFV1,'bassw', 'fxirsw'))
			WHEN @PL_M_TP_RTCUR0 = @PL_M_TP_RTCUR1
			THEN 'irs'
			ELSE
				CASE
				WHEN @PL_M_TP_RTFV0 = @PL_M_TP_RTFV1
				THEN 'bassw'
				ELSE 'fxirsw'
				END
			END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN 'repo'
			WHEN @COM_leg_LEG = 2
			THEN 'repo'
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN
			CASE --IIF('Interest Payment'$TP_TYPO.AND.('IRS'$TP_TYPO.OR.'CS'$TP_TYPO),'-1','')
			WHEN @PL_M_TP_TYPO LIKE '%Interest Payment%' AND (@PL_M_TP_TYPO LIKE '%IRS%' OR @PL_M_TP_TYPO LIKE '%CS%')
			THEN '-1'
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN 'fxsw'
			WHEN @COM_leg_LEG = 2
			THEN 'fxsw'
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN
			CASE --IIF('PRDC'$LTI_TYPEN(),'PRDC', TRIM(PROD_T_CUR)+TRIM(PROD_T_EQD)+TRIM(PROD_T_IRD))
			WHEN LTRIM(RTRIM(@M_METHOD)) LIKE '%PRDC%'
			THEN 'PRDC'
			ELSE
				CASE --PROD_T_CUR=IIF(TRIM(TRN_FMLY)$'CURR',IIF(TRIM(TRN_TYPE)$'SMP|SMPS','currvanopt',IIF(TRIM(TRN_TYPE)$'BAR','currbar','')),'')
			WHEN LTRIM(RTRIM(@COM_contractFamily_TRN)) LIKE '%CURR%'
			THEN
				CASE --IIF(TRIM(TRN_TYPE)$'SMP|SMPS','currvanopt',IIF(TRIM(TRN_TYPE)$'BAR','currbar',''))
				WHEN LTRIM(RTRIM(@COM_contractGroup_TRN)) IN ('SMP','SMPS')
				THEN 'currvanopt'
				ELSE
					CASE --IIF(TRIM(TRN_TYPE)$'BAR','currbar','')
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%BAR%'
				THEN 'currbar'
				ELSE ''
				END
				END
			ELSE ''
			END
			+
			CASE --PROD_T_EQD=IIF(TRIM(TRN_FMLY)$'EQD',IIF(TRIM(TRN_TYPE)$'OTC','eqdvanopt',IIF(TRIM(TRN_TYPE)$'BAR','eqdbaropt',IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt',''))),'')
			WHEN LTRIM(RTRIM(@COM_contractFamily_TRN)) LIKE '%EQD%'
			THEN
				CASE --IIF(TRIM(TRN_TYPE)$'OTC','eqdvanopt',IIF(TRIM(TRN_TYPE)$'BAR','eqdbaropt',IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt','')))
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%OTC%'
				THEN 'eqdvanopt'
				ELSE
					CASE --IIF(TRIM(TRN_TYPE)$'BAR','eqdbaropt',IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt',''))
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%BAR%'
				THEN 'eqdbaropt'
				ELSE
					CASE --IIF(TRIM(TRN_TYPE)$'ASI','eqdasiopt','')
					WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%ASI%'
					THEN 'eqdasiopt'
					ELSE ''
					END
				END
				END
			ELSE ''
			END
			+
			CASE --PROD_T_IRD=IIF(TRIM(TRN_FMLY)$'IRD',IIF(TRIM(TRN_GRP)$'OCF','capopt/floopt',IIF(TRIM(TRN_TYPE)$'OTC','irdbondvanopt','')),'')
			WHEN LTRIM(RTRIM(@COM_contractFamily_TRN)) LIKE '%%'
			THEN
				CASE --IIF(TRIM(TRN_GRP)$'OCF','capopt/floopt',IIF(TRIM(TRN_TYPE)$'OTC','irdbondvanopt',''))
				WHEN LTRIM(RTRIM(@COM_contractGroup_TRN)) LIKE '%OCF%'
				THEN 'capopt/floopt'
				ELSE
					CASE --IIF(TRIM(TRN_TYPE)$'OTC','irdbondvanopt','')
				WHEN LTRIM(RTRIM(@COM_contractType_TRN)) LIKE '%OTC%'
				THEN 'irdbondvanopt'
				ELSE ''
				END
				END
			ELSE ''
			END
			END
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN
			CASE --IIF('PRDC'$LTI_TYPEN(),'PRDC', 'swpopt')
			WHEN LTRIM(RTRIM(@M_METHOD)) LIKE '%PRDC%'
			THEN 'PRDC'
			ELSE 'swpopt'
			END
		ELSE NULL
		END
END

