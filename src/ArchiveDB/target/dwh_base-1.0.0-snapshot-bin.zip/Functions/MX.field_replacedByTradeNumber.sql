--liquibase formatted sql

--changeSet func:Initial-MX-field_replacedByTradeNumber-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_replacedByTradeNumber', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_replacedByTradeNumber](@MKTOP_LNK_M_BROTHER int) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_replacedByTradeNumber-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX].[field_replacedByTradeNumber]
(
  @MKTOP_LNK_M_BROTHER INT
)
RETURNS VARCHAR(20)
AS
BEGIN
RETURN
     CASE
     WHEN @MKTOP_LNK_M_BROTHER > 0
     THEN CAST(@MKTOP_LNK_M_BROTHER AS VARCHAR(20))
     ELSE NULL
     END
END