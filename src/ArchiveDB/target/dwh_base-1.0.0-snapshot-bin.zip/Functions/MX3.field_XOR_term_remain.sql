--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_term_remain-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_term_remain', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_term_remain](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@reportDate date,@PL_M_TP_BUY varchar(1),@PL_M_TP_RTFV0 varchar(1),@PL_M_TP_RTFV1 varchar(1),@PL_M_TP_RTMAT0 datetime,@PL_M_TP_RTDXC02 datetime,@PL_M_TP_RTMAT1 datetime,@PL_M_TP_RTDXC12 datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_RTDXG02 datetime,@PL_M_TP_DTEFLWL datetime,@PL_M_XARC_DATE datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_term_remain-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_XOR_term_remain]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @reportDate date,
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTFV0 varchar(1),
    @PL_M_TP_RTFV1 varchar(1),
    @PL_M_TP_RTMAT0 datetime,
    @PL_M_TP_RTDXC02 datetime,
    @PL_M_TP_RTMAT1 datetime,
    @PL_M_TP_RTDXC12 datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_RTDXG02 datetime,
    @PL_M_TP_DTEFLWL datetime ,
    @PL_M_XARC_DATE datetime   
)
RETURNS INT
AS
BEGIN
	DECLARE @ret int 

   DECLARE @nextBusinessDay date = DWH_TOOLKIT.DWH.getNextBusinessDay(@reportDate)

   SET @ret =
	    CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_BUY=='B', MAX(IIF(TP_RTFV0='F',TP_RTMAT0-REP_DATE+1,TP_RTDXC02-REP_DATE+1),0), MAX(IIF(TP_RTFV1='F',TP_RTMAT1-REP_DATE+1,TP_RTDXC12-REP_DATE+1),0))
				WHEN @PL_M_TP_BUY = 'B'
				THEN DWH_TOOLKIT.DWH.max_XY(CASE -- IIF(TP_RTFV0='F',TP_RTMAT0-REP_DATE+1,TP_RTDXC02-REP_DATE+1)
							WHEN @PL_M_TP_RTFV0='F'
							THEN DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTMAT0)
							ELSE DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTDXC02)
							END, 0)
				ELSE DWH_TOOLKIT.DWH.max_XY(CASE -- IIF(TP_RTFV1='F',TP_RTMAT1-REP_DATE+1,TP_RTDXC12-REP_DATE+1),0)
							WHEN @PL_M_TP_RTFV1='F'
							THEN DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTMAT1)
							ELSE DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTDXC12)
							END, 0)
				END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
				------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_BUY=='B',MAX(IIF(TP_RTFV0='F',TP_RTMAT0-REP_DATE+1,TP_RTDXC02-REP_DATE+1),0),MAX(IIF(TP_RTFV1='F',TP_RTMAT1-REP_DATE+1,TP_RTDXC12-REP_DATE+1),0))
				WHEN @PL_M_TP_BUY = 'B'
				THEN DWH_TOOLKIT.DWH.max_XY(CASE --IIF(TP_RTFV0='F',TP_RTMAT0-REP_DATE+1,TP_RTDXC02-REP_DATE+1)
							WHEN @PL_M_TP_RTFV0='F'
							THEN DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTMAT0)
							ELSE DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTDXC02)
							END, 0)
				ELSE DWH_TOOLKIT.DWH.max_XY(CASE --IIF(TP_RTFV1='F',TP_RTMAT1-REP_DATE+1,TP_RTDXC12-REP_DATE+1)
							WHEN @PL_M_TP_RTFV1='F'
							THEN DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTMAT1)
							ELSE DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTDXC12)
							END, 0)
				END
				------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN CASE
				WHEN @COM_leg_LEG = 1
				THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
				WHEN @COM_leg_LEG = 2
				THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
				END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN --MAX(IIF(TP_RTFV0='F',TP_RTMAT0-REP_DATE+1,TP_RTDXG02-REP_DATE+1),0)
				ISNULL(DWH_TOOLKIT.DWH.max_XY(CASE
						WHEN @PL_M_TP_RTFV0='F'
						THEN DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTMAT0)
						ELSE DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_RTDXG02)
						END, 0), 0)
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN @COM_leg_LEG = 1
				THEN --MAX(IIF(TP_RTFV0='F',TP_RTMAT0-XARC_DATE+1,TP_RTDXC02-XARC_DATE+1),0)
					DWH_TOOLKIT.DWH.max_XY(CASE
							WHEN @PL_M_TP_RTFV0='F'
							THEN DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTMAT0)
							ELSE DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTDXC02)
							END, 0)
				WHEN @COM_leg_LEG = 2
				THEN --MAX(IIF(TP_RTFV1='F',TP_RTMAT1-XARC_DATE+1,TP_RTDXC12-XARC_DATE+1),0)
					DWH_TOOLKIT.DWH.max_XY(CASE 
							WHEN @PL_M_TP_RTFV1='F'
							THEN DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTMAT1)
							ELSE DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTDXC12)
							END, 0)
				END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN @COM_leg_LEG = 1
				THEN --MAX(IIF(TP_RTFV0='F',TP_RTMAT0-XARC_DATE+1,TP_RTDXC02-XARC_DATE+1),0)
					DWH_TOOLKIT.DWH.max_XY(CASE
							WHEN @PL_M_TP_RTFV0='F'
							THEN DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTMAT0)
							ELSE DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTDXC02)
							END, 0)
				WHEN @COM_leg_LEG = 2
				THEN --MAX(IIF(TP_RTFV1='F',TP_RTMAT1-XARC_DATE+1,TP_RTDXC12-XARC_DATE+1),0)
					DWH_TOOLKIT.DWH.max_XY(CASE
							WHEN @PL_M_TP_RTFV1='F'
							THEN DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTMAT1)
							ELSE DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_RTDXC12)
							END, 0)
				END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN @COM_leg_LEG = 1
				THEN --MAX(TP_DTEFLWL-XARC_DATE+1,0)
					DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_DTEFLWL), 0)
				WHEN @COM_leg_LEG = 2
				THEN --MAX(TP_DTEFLWL-XARC_DATE+1,0)
					DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_DTEFLWL), 0)
				END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
			THEN CASE
				WHEN @COM_leg_LEG = 1
				THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_DTEEXP),0)
				WHEN @COM_leg_LEG = 2
				THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@PL_M_XARC_DATE+1,@PL_M_TP_DTEEXP),0)
				END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN DWH_TOOLKIT.DWH.max_XY(DATEDIFF(dd,@nextBusinessDay,@PL_M_TP_DTEEXP),0)
	    END

   RETURN @ret
END
GO