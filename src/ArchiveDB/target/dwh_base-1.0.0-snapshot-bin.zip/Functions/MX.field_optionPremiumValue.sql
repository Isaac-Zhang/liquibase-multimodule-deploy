--liquibase formatted sql

--changeSet func:Initial-MX-field_optionPremiumValue-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_optionPremiumValue', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_optionPremiumValue](@mxContractType varchar(10),@PL_M_TP_PRICE numeric(28,8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_optionPremiumValue-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_optionPremiumValue]
(
	@mxContractType varchar(10), 
	@PL_M_TP_PRICE numeric(28,8)
)
RETURNS numeric(28,8)
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType IN ('OPT','CDS','FDB','NDB') THEN @PL_M_TP_PRICE
        ELSE NULL
        END
END
GO