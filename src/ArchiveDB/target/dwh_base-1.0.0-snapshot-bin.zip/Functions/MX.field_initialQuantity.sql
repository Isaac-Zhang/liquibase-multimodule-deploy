--liquibase formatted sql

--changeSet func:Initial-MX-field_initialQuantity-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_initialQuantity', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_initialQuantity](@mxContractType varchar(10),@PL_M_TP_BUY varchar(1),@PL_M_TP_IQTY numeric(28,8),@PL_M_TP_NOMINAL numeric(19,2)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_initialQuantity-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_initialQuantity]
(
	@mxContractType varchar(10),
	@PL_M_TP_BUY varchar(1),
    @PL_M_TP_IQTY numeric(28,8),
    @PL_M_TP_NOMINAL numeric(19,2)
)
RETURNS NUMERIC(28,8)
AS
BEGIN
	RETURN
      CASE
        WHEN @mxContractType IN ('ASWP','BOND','FXD','LN_BR','OPT','CS','IRS','REPO','CDS', 'XSW')  THEN @PL_M_TP_IQTY
        WHEN @mxContractType IN ('CF','FRA','OSWP')                                                 THEN @PL_M_TP_NOMINAL
        WHEN @mxContractType IN ('FUT')                                                             THEN 
            CASE WHEN @PL_M_TP_BUY = 'B' THEN @PL_M_TP_NOMINAL ELSE -@PL_M_TP_NOMINAL END
      END
    
END
GO