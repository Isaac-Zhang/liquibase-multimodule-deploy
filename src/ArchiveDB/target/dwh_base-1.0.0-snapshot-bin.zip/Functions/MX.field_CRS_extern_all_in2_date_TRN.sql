--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_extern_all_in2_date_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_extern_all_in2_date_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_extern_all_in2_date_TRN](@mxContractType varchar(10),@IRD_M_MARG_DATE datetime,@CURR_M_MARG_DATE datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_extern_all_in2_date_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_extern_all_in2_date_TRN]
(
	@mxContractType varchar(10),
    @IRD_M_MARG_DATE datetime,
    @CURR_M_MARG_DATE datetime
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
            WHEN @mxContractType IN ('ASWP', 'BOND', 'CD', 'CS', 'FRA', 'FUT', 'IRS', 'LN_BR', 'REPO', 'OSWP'/*, 'CF'*/)
            THEN @IRD_M_MARG_DATE
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('FXD', 'XSW')
			THEN @CURR_M_MARG_DATE
		ELSE NULL
		END
END
GO