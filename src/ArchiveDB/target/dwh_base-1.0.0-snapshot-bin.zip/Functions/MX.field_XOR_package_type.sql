--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_package_type-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_package_type', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_package_type](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@LTI_TMPL_M_NAME varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_package_type-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_package_type]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @LTI_TMPL_M_NAME varchar(20)
)
RETURNS varchar(20)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'IR Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'Equity Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'IR Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'IR Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'Fx Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN CASE --IIF(ISBLANK(LTI_TYPEN())=1,'NONE', IIF('PRDC'$LTI_TYPEN(),'Fx Linked', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))))
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'NONE'
			ELSE
				CASE --IIF('PRDC'$LTI_TYPEN(),'Fx Linked', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())))
				WHEN @LTI_TMPL_M_NAME LIKE '%PRDC%'
				THEN 'PRDC'
				ELSE
					CASE --IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))
				WHEN @LTI_TMPL_M_NAME LIKE '%Com. Linked%'
				THEN 'Commodity Linked'
				ELSE
					CASE --IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())
					WHEN @LTI_TMPL_M_NAME LIKE '%-%'
					THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
					ELSE @LTI_TMPL_M_NAME
					END
				END
				END
			END
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN CASE --IIF('PRDC'$LTI_TYPEN(),'PRDC', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())))
				WHEN @LTI_TMPL_M_NAME LIKE '%PRDC%'
			THEN 'PRDC'
			ELSE
				CASE --IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))
				WHEN @LTI_TMPL_M_NAME LIKE '%Com. Linked%'
				THEN 'Commodity Linked'
				ELSE
					CASE --IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
				END
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN CASE --IIF(ISBLANK(LTI_TYPEN())=1,'NONE', IIF('PRDC'$LTI_TYPEN(),'PRDC', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))))
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'NONE'
			ELSE
				CASE --IIF('PRDC'$LTI_TYPEN(),'Fx Linked', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())))
				WHEN @LTI_TMPL_M_NAME LIKE '%PRDC%'
				THEN 'PRDC'
				ELSE
					CASE --IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))
				WHEN @LTI_TMPL_M_NAME LIKE '%Com. Linked%'
				THEN 'Commodity Linked'
				ELSE
					CASE --IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())
					WHEN @LTI_TMPL_M_NAME LIKE '%-%'
					THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
					ELSE @LTI_TMPL_M_NAME
					END
				END
				END
			END
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'NONE'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN
				CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'Fx Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN
				CASE
				WHEN ISNULL(RTRIM(LTRIM(@LTI_TMPL_M_NAME)), '') = ''
			THEN 'IR Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
				CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'NONE'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'NONE'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
			THEN CASE
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'Fx Linked'
			ELSE
				CASE
				WHEN @LTI_TMPL_M_NAME LIKE '%-%'
				THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
				ELSE @LTI_TMPL_M_NAME
				END
			END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN CASE --IIF(ISBLANK(LTI_TYPEN())=1,'NONE', IIF('PRDC'$LTI_TYPEN(),'Fx Linked', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))))
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'NONE'
			ELSE
				CASE --IIF('PRDC'$LTI_TYPEN(),'Fx Linked', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())))
				WHEN @LTI_TMPL_M_NAME LIKE '%PRDC%'
				THEN 'PRDC'
				ELSE
					CASE --IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))
				WHEN @LTI_TMPL_M_NAME LIKE '%Com. Linked%'
				THEN 'Commodity Linked'
				ELSE
					CASE --IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())
					WHEN @LTI_TMPL_M_NAME LIKE '%-%'
					THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
					ELSE @LTI_TMPL_M_NAME
					END
				END
				END
			END
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(ISBLANK(LTI_TYPEN())=1,'NONE', IIF('PRDC'$LTI_TYPEN(),'Fx Linked', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))))
				WHEN RTRIM(LTRIM(@LTI_TMPL_M_NAME)) = ''
			THEN 'NONE'
			ELSE
				CASE --IIF('PRDC'$LTI_TYPEN(),'Fx Linked', IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())))
				WHEN @LTI_TMPL_M_NAME LIKE '%PRDC%'
				THEN 'PRDC'
				ELSE
					CASE --IIF('Com. Linked'$LTI_TYPEN(),'Commodity Linked', IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN()))
				WHEN @LTI_TMPL_M_NAME LIKE '%Com. Linked%'
				THEN 'Commodity Linked'
				ELSE
					CASE --IIF('-'$LTI_TYPEN(),SUBFIELD(LTI_TYPEN(),2,'-'),LTI_TYPEN())
					WHEN @LTI_TMPL_M_NAME LIKE '%-%'
					THEN SUBSTRING(@LTI_TMPL_M_NAME,PATINDEX('%-%',@LTI_TMPL_M_NAME)+1,LEN(@LTI_TMPL_M_NAME))
					ELSE @LTI_TMPL_M_NAME
					END
				END
				END
			END
	    ELSE NULL
	    END
END
GO