--liquibase formatted sql

--changeSet func:Initial-MX3-field_calculationEndDate-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_calculationEndDate', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_calculationEndDate](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTDKC01 date,@PL_M_TP_RTDKC11 date) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_calculationEndDate-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_calculationEndDate]
(
	@mxContractType varchar(10),
	@COM_leg_LEG INT,
	@PL_M_TP_RTDKC01 DATE,
	@PL_M_TP_RTDKC11 DATE
)
RETURNS DATE
AS
BEGIN
	RETURN 
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP')
			THEN CASE 
                 WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTDKC01
			     WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTDKC11
			     END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'CDS', 'LN_BR', 'CF')
			THEN @PL_M_TP_RTDKC01
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
            ---------------------------------------------------- CRS_FUT ----------------------------------------------------
            ---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType IN ('FRA')
			THEN @PL_M_TP_RTDKC11
			WHEN @mxContractType IN ('FUT', 'FXD', 'XSW','SWLEG')
			THEN NULL
		ELSE NULL
		END
END
GO