--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_earlyTerm-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_earlyTerm', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_earlyTerm](@COM_contractFamily varchar(10),@CURR_M_EARLY_TERM varchar(1),@EQD_M_EARLY_TERM varchar(1),@IRD_M_EARLY_TERM varchar(1),@REP_M_EARLY_TERM varchar(1),@extractContext varchar(3)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_earlyTerm-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_earlyTerm]
(
	@COM_contractFamily varchar(10), 
    @CURR_M_EARLY_TERM varchar(1),
    @EQD_M_EARLY_TERM varchar(1),
    @IRD_M_EARLY_TERM varchar(1),
	@REP_M_EARLY_TERM varchar(1),
	@extractContext varchar(3) 
)
RETURNS varchar(1)
AS
BEGIN
	RETURN
	    CASE
            WHEN @COM_contractFamily = 'CURR' THEN
			     CASE
                     WHEN @extractContext = 'IND' THEN
					     @REP_M_EARLY_TERM
                     ELSE
						     @CURR_M_EARLY_TERM
                     END
            WHEN @COM_contractFamily = 'EQD' THEN
			    CASE
                    WHEN @extractContext = 'IND' THEN
					    @REP_M_EARLY_TERM
                    ELSE
					    @EQD_M_EARLY_TERM
                END
            WHEN @COM_contractFamily = 'IRD' THEN
			    CASE
                    WHEN @extractContext = 'IND' THEN
				         @REP_M_EARLY_TERM
                    ELSE
				         @IRD_M_EARLY_TERM
                END
            ELSE
			    NULL
        END

END
GO