--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_value_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_value_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_value_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@m_plirdfpv11 numeric(16,2),@m_plirdfpv21 numeric(16,2),@m_pl_fmv1 numeric(23,6),@PL_M_QTY_INDEX numeric(3,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_value_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_value_LEG]
(
	@mxContractType VARCHAR(10), 
    @COM_leg_LEG    INT,
    @m_plirdfpv11   NUMERIC(16,2),
    @m_plirdfpv21   NUMERIC(16,2),
    @m_pl_fmv1      NUMERIC(23,6),
    @PL_M_QTY_INDEX numeric(3,0)
    )
RETURNS NUMERIC(28,8)
AS
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- ! O b j e c t i v e :           
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-12-22      DaHj    Initial version...
  -- !									 2011-01-03		 DaHj	 Added contracttypes.
  -- !									 2011-01-05		 DaHj	 Removed ABS.
  -- +--------------------------------------------------------------------------------------------------------------------------------+

BEGIN
	RETURN 
		CASE
      WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'FXD', 'OSWP', 'FRA') THEN
		CASE  WHEN @COM_leg_LEG = 1 
				THEN @m_plirdfpv11
              WHEN @COM_leg_LEG = 2 
                THEN @m_plirdfpv21
        ELSE
          NULL END
    ------------------------------------------ CRS_XSW ----------------------------------------------------
	WHEN @mxContractType = 'XSW' THEN
	    CASE
			WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 0) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 1) THEN @m_plirdfpv11 
            WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 1) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 0) THEN @m_plirdfpv21
			ELSE NULL
		END

      WHEN @mxContractType IN ('BOND', 'CD', 'CF', 'LN_BR', 'REPO', 'CDS', 'FUT', 'OPT', 'FDB', 'NDB') 
        THEN @m_pl_fmv1
    ELSE NULL
    END
END
GO