--liquibase formatted sql

--changeSet func:Initial-DWH-get_MinRating-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_MinRating', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[get_MinRating](@MoodyRating varchar(5),@SPRating varchar(5)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-get_MinRating-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.get_MinRating ( @MoodyRating VARCHAR(5), @SPRating VARCHAR(5) )
RETURNS   VARCHAR(5)
AS
BEGIN
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.get_MinRating
  -- ! R e t u r n s       : INT
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       MoodyRating			 VARCHAR (5)
  -- !                       SPRating				 VARCHAR (5)
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returnerar ratingen för den av de två som har lägst sorteringsordning
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-05-10 JoJo  Initial version by JoJo
  -- !                       2010-06-16 JoJo  Change to return SEK internal rating instead of SP/MOODY
  -- +----------------------------------------------------------------------------------------------------------------
  --
	DECLARE @retRating VARCHAR(5)
	--
	-- Om det är MOODY som ska returneras görs så med motsvarande ratingbetckning från SP eftersom det är denna som
	-- står listad i tabellen DWH.LKP_numberOfA
	SELECT @retRating = CASE WHEN R1.sortOrder < R2.sortOrder THEN 
								(SELECT r.rating
								   FROM DWH.LKP_ratingMatrix rm
									INNER JOIN DWH.LKP_ratingOrganization ro ON rm._ratingOrganization_ID = ro.ID
									INNER JOIN DWH.LKP_rating r ON rm._rating_ID = r.ID
								  WHERE ro.ID = 10 /*SEK*/
								    AND rm.sortOrder = R2.sortOrder)
							 ELSE
								(SELECT r.rating
								   FROM DWH.LKP_ratingMatrix rm
									INNER JOIN DWH.LKP_ratingOrganization ro ON rm._ratingOrganization_ID = ro.ID
									INNER JOIN DWH.LKP_rating r ON rm._rating_ID = r.ID
								  WHERE ro.ID = 10 /*SEK*/
								    AND rm.sortOrder = R1.sortOrder)
						 END
	  FROM (SELECT r.rating, rm.sortOrder
			  FROM DWH.LKP_ratingMatrix rm
				INNER JOIN DWH.LKP_ratingOrganization ro ON rm._ratingOrganization_ID = ro.ID
				INNER JOIN DWH.LKP_rating r ON rm._rating_ID = r.ID
			 WHERE ro.ID = 11 /*SP*/) AS R1, 
	       (SELECT r.rating, rm.sortOrder
			  FROM DWH.LKP_ratingMatrix rm
				INNER JOIN DWH.LKP_ratingOrganization ro ON rm._ratingOrganization_ID = ro.ID
				INNER JOIN DWH.LKP_rating r ON rm._rating_ID = r.ID
			 WHERE ro.ID = 12 /*MOODY*/) AS R2
	 WHERE R1.rating = @SPRating
	   AND R2.rating = @MoodyRating
	--
	RETURN @retRating
END
GO