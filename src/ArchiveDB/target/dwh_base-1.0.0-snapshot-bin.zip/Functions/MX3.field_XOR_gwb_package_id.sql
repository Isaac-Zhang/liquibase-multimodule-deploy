--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_gwb_package_id-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_gwb_package_id', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_gwb_package_id](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@IRD_M_GWB_LNK_PK varchar(16),@EQD_M_GWB_LNK_PK varchar(16),@CRD_M_GWB_LNK_PK varchar(16),@CURR_M_GWB_LNK_PK varchar(16)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_gwb_package_id-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_XOR_gwb_package_id]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @IRD_M_GWB_LNK_PK varchar(16),
    @EQD_M_GWB_LNK_PK varchar(16),
    @CRD_M_GWB_LNK_PK varchar(16),
    @CURR_M_GWB_LNK_PK varchar(16)
)
RETURNS varchar(16)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN @EQD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN @CURR_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN @CRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN @IRD_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN NULL
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('XSW','SWLEG') AND @COM_quantityIndex_TRN = 1
			THEN @CURR_M_GWB_LNK_PK
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN
			CASE
			WHEN @COM_contractFamily_TRN = 'IRD'
			THEN @IRD_M_GWB_LNK_PK
			WHEN @COM_contractFamily_TRN = 'CURR'
			THEN @CURR_M_GWB_LNK_PK
			WHEN @COM_contractFamily_TRN = 'EQD'
			THEN @EQD_M_GWB_LNK_PK
			WHEN @COM_contractFamily_TRN = 'CRD'
			THEN @CRD_M_GWB_LNK_PK
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN
			CASE
			WHEN @COM_contractFamily_TRN = 'IRD'
			THEN @IRD_M_GWB_LNK_PK
			WHEN @COM_contractFamily_TRN = 'CURR'
			THEN @CURR_M_GWB_LNK_PK
			WHEN @COM_contractFamily_TRN = 'EQD'
			THEN @EQD_M_GWB_LNK_PK
			WHEN @COM_contractFamily_TRN = 'CRD'
			THEN @CRD_M_GWB_LNK_PK
			ELSE NULL
			END
		ELSE NULL
		END
END
GO