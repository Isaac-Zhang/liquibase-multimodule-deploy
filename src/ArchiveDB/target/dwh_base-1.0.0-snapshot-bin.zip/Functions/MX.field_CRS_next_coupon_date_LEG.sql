--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_next_coupon_date_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_next_coupon_date_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_next_coupon_date_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@reportDate date,@COM_contractType_TRN varchar(10),@PL_M_TP_BUY varchar(1),@PL_M_TP_RTFV0 varchar(1),@PL_M_TP_RTFV1 varchar(1),@PL_M_TP_RTDXG01 datetime,@PL_M_TP_RTDXG11 datetime,@PL_M_TP_RTDKN01 datetime,@PL_M_TP_RTDKN11 datetime,@PL_M_TP_RTDXC01 datetime,@PL_M_TP_RTDXC11 datetime,@PL_M_TP_RTDKC01 datetime,@PL_M_TP_RTDKC11 datetime,@PL_M_TP_RTDPC01 datetime,@PL_M_TP_RTDPC11 datetime,@PL_M_TP_RTDPN01 datetime,@PL_M_TP_RTDPN11 datetime,@PL_M_TP_RTDPP01 datetime,@PL_M_TP_RTDPP11 datetime,@PL_M_TP_RTMAT0 datetime,@PL_M_TP_RTMAT1 datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_DTEPMT2 datetime,@SEC_M_SE_MAT datetime,@PL_M_TP_STATUS1 varchar(10),@PL_M_QTY_INDEX tinyint) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_next_coupon_date_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_next_coupon_date_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
    @reportDate date,
    @COM_contractType_TRN varchar(10),
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTFV0 varchar(1),
    @PL_M_TP_RTFV1 varchar(1),
    @PL_M_TP_RTDXG01 datetime,
    @PL_M_TP_RTDXG11 datetime,
    @PL_M_TP_RTDKN01 datetime,
    @PL_M_TP_RTDKN11 datetime,
    @PL_M_TP_RTDXC01 datetime,
    @PL_M_TP_RTDXC11 datetime,
    @PL_M_TP_RTDKC01 datetime,
    @PL_M_TP_RTDKC11 datetime,
    @PL_M_TP_RTDPC01 datetime,
    @PL_M_TP_RTDPC11 datetime,
    @PL_M_TP_RTDPN01 datetime,
    @PL_M_TP_RTDPN11 datetime,
    @PL_M_TP_RTDPP01 datetime,
    @PL_M_TP_RTDPP11 datetime,
    @PL_M_TP_RTMAT0 datetime,
    @PL_M_TP_RTMAT1 datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_DTEPMT2 datetime,
    @SEC_M_SE_MAT datetime,
    @PL_M_TP_STATUS1 varchar(10),
    @PL_M_QTY_INDEX TINYINT
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
            -- Set next fixing to NULL if contract is dead
            WHEN @PL_M_TP_STATUS1 = 'DEAD' THEN NULL
            ---------------------------------------------------- CRS_ASWP ----------------------------------------------------
            WHEN @mxContractType = 'ASWP'
            THEN CASE
                 WHEN @COM_leg_LEG = 1
                 THEN CASE
                      WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                      WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                      WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                      ELSE NULL
                      END
                 WHEN @COM_leg_LEG = 2
                 THEN CASE 
                      WHEN @PL_M_TP_RTDPP11 > @reportDate THEN @PL_M_TP_RTDPP11
                      WHEN @PL_M_TP_RTDPC11 > @reportDate THEN @PL_M_TP_RTDPC11
                      WHEN @PL_M_TP_RTDPN11 > @reportDate THEN @PL_M_TP_RTDPN11
                      ELSE NULL
                      END
                 END
            ---------------------------------------------------- CRS_BOND ----------------------------------------------------
            WHEN  @mxContractType = 'BOND'
            THEN CASE
                 WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                 WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                 WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                 ELSE NULL
                 END
            ---------------------------------------------------- CRS_CD ----------------------------------------------------
            WHEN  @mxContractType = 'CD'
            THEN CASE
                 WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                 WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                 WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                 ELSE NULL
                 END
            ---------------------------------------------------- CRS_CF ----------------------------------------------------
            WHEN  @mxContractType = 'CF'
            THEN CASE
                 WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                 WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                 WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                 ELSE NULL
                 END
            ---------------------------------------------------- CRS_CDS ----------------------------------------------------
            WHEN @mxContractType = 'CDS'
            THEN CASE
                 WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                 WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                 WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                 ELSE NULL
                 END
            ---------------------------------------------------- CRS_CS ----------------------------------------------------
            WHEN @mxContractType = 'CS'
            THEN CASE
                 WHEN @COM_leg_LEG = 1
                 THEN CASE
                      WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                      WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                      WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                      ELSE NULL
                      END
                 WHEN @COM_leg_LEG = 2
                 THEN CASE 
                      WHEN @PL_M_TP_RTDPP11 > @reportDate THEN @PL_M_TP_RTDPP11
                      WHEN @PL_M_TP_RTDPC11 > @reportDate THEN @PL_M_TP_RTDPC11
                      WHEN @PL_M_TP_RTDPN11 > @reportDate THEN @PL_M_TP_RTDPN11
                      ELSE NULL
                      END
                 END
            ---------------------------------------------------- FRA, FUT ----------------------------------------------------
            WHEN @mxContractType IN ('FRA', 'FUT')
            THEN CASE
                 WHEN MX.field_CRS_maturity_date_LEG(
                                 @mxContractType, @COM_contractType_TRN, @PL_M_TP_RTMAT0, @PL_M_TP_DTEEXP, @PL_M_TP_BUY, @PL_M_TP_RTMAT1, @PL_M_TP_DTEPMT2, @SEC_M_SE_MAT, @PL_M_QTY_INDEX)
                      >  @reportDate
                 THEN MX.field_CRS_maturity_date_LEG(
                                 @mxContractType, @COM_contractType_TRN, @PL_M_TP_RTMAT0, @PL_M_TP_DTEEXP, @PL_M_TP_BUY, @PL_M_TP_RTMAT1, @PL_M_TP_DTEPMT2, @SEC_M_SE_MAT, @PL_M_QTY_INDEX)
                 ELSE NULL
                 END              
            ---------------------------------------------------- FXD, XSW ----------------------------------------------------
            WHEN @mxContractType IN ('FXD', 'XSW')
            THEN NULL
            ---------------------------------------------------- CRS_IRS ----------------------------------------------------
            WHEN @mxContractType = 'IRS'
            THEN CASE
                 WHEN @COM_leg_LEG = 1
                 THEN CASE
                      WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                      WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                      WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                      ELSE NULL
                      END
                 WHEN @COM_leg_LEG = 2
                 THEN CASE 
                      WHEN @PL_M_TP_RTDPP11 > @reportDate THEN @PL_M_TP_RTDPP11
                      WHEN @PL_M_TP_RTDPC11 > @reportDate THEN @PL_M_TP_RTDPC11
                      WHEN @PL_M_TP_RTDPN11 > @reportDate THEN @PL_M_TP_RTDPN11
                      ELSE NULL
                      END
                 END
            ---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
            WHEN @mxContractType = 'LN_BR'
            THEN CASE
                 WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                 WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                 WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                 ELSE NULL
                 END
            ---------------------------------------------------- CRS_REPO ----------------------------------------------------
            WHEN @mxContractType = 'REPO'
            THEN CASE
                 WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                 WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                 WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                 ELSE NULL
                 END
			---------------------------------------------------- CRS_OSWP ----------------------------------------------------
            WHEN @mxContractType = 'OSWP'
            THEN CASE
                 WHEN @COM_leg_LEG = 1
                 THEN CASE
                      WHEN @PL_M_TP_RTDPP01 > @reportDate THEN @PL_M_TP_RTDPP01
                      WHEN @PL_M_TP_RTDPC01 > @reportDate THEN @PL_M_TP_RTDPC01
                      WHEN @PL_M_TP_RTDPN01 > @reportDate THEN @PL_M_TP_RTDPN01
                      ELSE NULL
                      END
                 WHEN @COM_leg_LEG = 2
                 THEN CASE 
                      WHEN @PL_M_TP_RTDPP11 > @reportDate THEN @PL_M_TP_RTDPP11
                      WHEN @PL_M_TP_RTDPC11 > @reportDate THEN @PL_M_TP_RTDPC11
                      WHEN @PL_M_TP_RTDPN11 > @reportDate THEN @PL_M_TP_RTDPN11
                      ELSE NULL
                      END
                 END
		END
END
GO