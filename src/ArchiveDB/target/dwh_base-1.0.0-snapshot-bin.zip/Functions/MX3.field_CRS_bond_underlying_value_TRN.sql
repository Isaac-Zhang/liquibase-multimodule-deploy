--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_bond_underlying_value_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_bond_underlying_value_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_bond_underlying_value_TRN](@mxContractType varchar(10),@PL_M_TP_NOMINAL numeric(24,8),@PL_M_TP_IQTY numeric(24,8),@PL_M_P_DIRTY numeric(24,8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_bond_underlying_value_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_bond_underlying_value_TRN]
(
	@mxContractType varchar(10),
	@PL_M_TP_NOMINAL numeric(24,8),
    @PL_M_TP_IQTY numeric(24,8),
    @PL_M_P_DIRTY numeric(24,8)
)
RETURNS numeric(24,8)
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType = 'REPO' THEN @PL_M_TP_NOMINAL * @PL_M_TP_IQTY * @PL_M_P_DIRTY / 100 ELSE NULL END
END
GO