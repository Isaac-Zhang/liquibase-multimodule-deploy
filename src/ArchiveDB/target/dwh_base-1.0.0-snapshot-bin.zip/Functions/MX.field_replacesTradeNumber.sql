--liquibase formatted sql

--changeSet func:Initial-MX-field_replacesTradeNumber-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_replacesTradeNumber', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_replacesTradeNumber](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@IRD_M_GWB_LNK varchar(12),@EQD_M_GWB_LNK varchar(12),@CRD_M_GWB_LNK varchar(12),@CURR_M_GWB_LNK varchar(12),@PL_M_MRPL_FLAG varchar(1),@PL_M_TP_CREATOR numeric(10,0),@PL_M_TP_VALSTAT varchar(4)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_replacesTradeNumber-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX].[field_replacesTradeNumber]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),

    @IRD_M_GWB_LNK varchar(12),
    @EQD_M_GWB_LNK varchar(12),
    @CRD_M_GWB_LNK varchar(12),
    @CURR_M_GWB_LNK varchar(12),

    @PL_M_MRPL_FLAG varchar(1),
    @PL_M_TP_CREATOR numeric(10,0),
    @PL_M_TP_VALSTAT varchar(4)
)
RETURNS VARCHAR(20)
AS
BEGIN
RETURN
  NULLIF(COALESCE(CASE WHEN  @COM_contractGroup_TRN = 'CDS' 
                  AND @PL_M_TP_CREATOR > 0 
                  AND @PL_M_MRPL_FLAG = 'Y' 
                  AND @PL_M_TP_VALSTAT <> 'MIGM'
                THEN  CAST(@PL_M_TP_CREATOR AS VARCHAR(20))
                WHEN  @COM_contractGroup_TRN <> 'CDS' 
                  AND @PL_M_TP_CREATOR > 0 
                  AND @PL_M_MRPL_FLAG = 'Y'
                THEN CAST(@PL_M_TP_CREATOR AS VARCHAR(20))
                ELSE NULL
           END
            , 
            CASE @COM_contractFamily_TRN
            WHEN 'IRD' THEN @IRD_M_GWB_LNK
            WHEN 'CURR'THEN @CURR_M_GWB_LNK
            WHEN 'EQD' THEN @EQD_M_GWB_LNK
            WHEN 'CRD' THEN @CRD_M_GWB_LNK
            ELSE NULL
            END
           ),'')
END
GO