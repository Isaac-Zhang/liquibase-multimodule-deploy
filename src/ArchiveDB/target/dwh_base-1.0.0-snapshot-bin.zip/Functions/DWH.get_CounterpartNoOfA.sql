--liquibase formatted sql

--changeSet func:Initial-DWH-get_CounterpartNoOfA-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_CounterpartNoOfA', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[get_CounterpartNoOfA](@counterpartId int) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-get_CounterpartNoOfA-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[get_CounterpartNoOfA] ( @counterpartId INT )
RETURNS   INT
AS
BEGIN
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.get_CounterpartNoOfA
  -- ! R e t u r n s       : INT
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       counterpartId			 INT
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returnerar AntalA för den motpart vars id skickas till funktionen.
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-05-10 JoJo  Initial version by JoJo
  -- !
  -- +----------------------------------------------------------------------------------------------------------------
  --
	DECLARE @shortname VARCHAR(15)
	DECLARE @grpName VARCHAR(30)
	DECLARE @noOfA	INT
	--
	SELECT @shortname = C.shortname FROM DWH.counterpart C WHERE Id = @counterpartId
	--
	IF EXISTS(SELECT * FROM DWH.LKP_CounterpartNumberOfAGroup WHERE Shortname = @shortname AND NumberOfAGroupType = 'NumberOfA')
	BEGIN
		-- Detta är en motpart som ska specialbehandlas
		SELECT @noOfA = DWH.get_NoOfAForGroup( CG.NumberOfAGroupName, DWH.get_MinRating(MOODY.rating, SP.rating) )
		  FROM DWH.counterpart C
			INNER JOIN (SELECT CR._counterpart_ID, R.rating
						  FROM DWH.counterpartRating CR
							INNER JOIN DWH.LKP_ratingMatrix RM ON CR._ratingMatrix_ID = RM.ID
							INNER JOIN DWH.LKP_ratingOrganization RO ON RM._ratingOrganization_ID = RO.ID
							INNER JOIN DWH.LKP_rating R ON RM._rating_ID = R.ID
						 WHERE RO.organization = 'Moodys' AND CR._counterpart_ID = @counterpartId) MOODY ON C.ID = MOODY._counterpart_ID
			INNER JOIN (SELECT CR._counterpart_ID, R.rating
						  FROM DWH.counterpartRating CR
							INNER JOIN DWH.LKP_ratingMatrix RM ON CR._ratingMatrix_ID = RM.ID
							INNER JOIN DWH.LKP_ratingOrganization RO ON RM._ratingOrganization_ID = RO.ID
							INNER JOIN DWH.LKP_rating R ON RM._rating_ID = R.ID
						 WHERE RO.organization = 'Standard & Poors' AND CR._counterpart_ID = @counterpartId) SP ON C.ID = SP._counterpart_ID
			INNER JOIN DWH.LKP_CounterpartNumberOfAGroup CG ON C.shortname = CG.Shortname
		 WHERE C.Id = @counterpartId
		   AND CG.NumberOfAGroupType = 'NumberOfA'
	END
	ELSE
	BEGIN
		-- Detta är en motpart som skall standardbehandlas
		SELECT @noOfA = DWH.get_NoOfAForGroup( 'SP', SP.rating ) + DWH.get_NoOfAForGroup( 'MOODY', MOODY.rating )
		  FROM DWH.counterpart C
			INNER JOIN (SELECT CR._counterpart_ID, R.rating
						  FROM DWH.counterpartRating CR
							INNER JOIN DWH.LKP_ratingMatrix RM ON CR._ratingMatrix_ID = RM.ID
							INNER JOIN DWH.LKP_ratingOrganization RO ON RM._ratingOrganization_ID = RO.ID
							INNER JOIN DWH.LKP_rating R ON RM._rating_ID = R.ID
						 WHERE RO.organization = 'Moodys' AND CR._counterpart_ID = @counterpartId) MOODY ON C.ID = MOODY._counterpart_ID
			INNER JOIN (SELECT CR._counterpart_ID, R.rating
						  FROM DWH.counterpartRating CR
							INNER JOIN DWH.LKP_ratingMatrix RM ON CR._ratingMatrix_ID = RM.ID
							INNER JOIN DWH.LKP_ratingOrganization RO ON RM._ratingOrganization_ID = RO.ID
							INNER JOIN DWH.LKP_rating R ON RM._rating_ID = R.ID
						 WHERE RO.organization = 'Standard & Poors' AND CR._counterpart_ID = @counterpartId) SP ON C.ID = SP._counterpart_ID
			--INNER JOIN DWH.LKP_CounterpartNumberOfAGroup CG ON C.shortname = CG.Shortname
		 WHERE C.Id = @counterpartId
	END
	--
	RETURN @noOfA         
END
GO