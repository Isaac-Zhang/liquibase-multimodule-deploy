--liquibase formatted sql

--changeSet func:Initial-MX3-field_COM_inOutDate_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_COM_inOutDate_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_COM_inOutDate_TRN](@COM_contractFamily varchar(10),@EQD_inOutDate datetime,@IRD_inOutDate datetime,@CURR_inOutDate datetime,@CRD_inOutDate datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_COM_inOutDate_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_COM_inOutDate_TRN](
@COM_contractFamily varchar(10), 
@EQD_inOutDate datetime,
@IRD_inOutDate datetime,
@CURR_inOutDate datetime,
@CRD_inOutDate datetime
)
RETURNS datetime
AS
BEGIN
  RETURN
	CASE
		       ---- EQD ----
		WHEN @COM_contractFamily = 'EQD'  THEN
			 @EQD_inOutDate
                ---- IRD ----
         WHEN @COM_contractFamily = 'IRD'  THEN
			  @IRD_inOutDate
                ---- CURR ----
		WHEN @COM_contractFamily = 'CURR' THEN
			 @CURR_inOutDate
			    ---- CRD ---
		WHEN @COM_contractFamily = 'CRD' THEN
			 @CRD_inOutDate	 
                ELSE NULL
			
  	END
END
GO