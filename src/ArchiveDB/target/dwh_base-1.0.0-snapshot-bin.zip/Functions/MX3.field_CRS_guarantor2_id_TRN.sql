--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_guarantor2_id_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_guarantor2_id_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_guarantor2_id_TRN](@mxContractType varchar(10),@IRD_M_GUARANTOR2 varchar(25),@CNTRP_IRD2_M_ID numeric(10,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_guarantor2_id_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_guarantor2_id_TRN]
(
	@mxContractType varchar(10), 
    @IRD_M_GUARANTOR2 varchar(25),
    @CNTRP_IRD2_M_ID numeric(10,0)
)
RETURNS numeric(10,0)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------

			WHEN @mxContractType IN ('ASWP', 'BOND', 'CD', 'CS', 'FRA', 'FUT', 'FXD', 'IRS', 'LN_BR', 'OSWP','REPO', 'XSW', 'CF','SWLEG') THEN
			    CASE --IIF(ISBLANK(CTABLE('Deal [IRD]',STR(NB),'GUARANTOR2'))=0, NTBLFIELD('TRN_CPDF.ID','LABEL',TRIM(CTABLE('Deal [IRD]',STR(NB),'GUARANTOR2'))), 0)
				    WHEN LTRIM(RTRIM(@IRD_M_GUARANTOR2))<>'' THEN @CNTRP_IRD2_M_ID ELSE 0 END

            ---------------------------------------------------- CRS_CDS ----------------------------------------------------
            --################################## CRD.M_GUARANTOR2 fältet finns inte ############################
            WHEN @mxContractType = 'CDS' THEN 0

		ELSE NULL
		END
END
GO