--liquibase formatted sql

--changeSet func:Initial-DWH-getRatingsWithOverride-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getRatingsWithOverride', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getRatingsWithOverride](@reportDate date,@extractContext varchar(3),@scenarioID int) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getRatingsWithOverride-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getRatingsWithOverride]
(
    @reportDate date
  , @extractContext varchar(3)
  , @scenarioID int
)
RETURNS TABLE AS RETURN 
(
    WITH MAT AS (
        SELECT RM.ID AS _ratingMatrix_ID, RO.organization, RM._ratingOrganization_ID, R.rating, RM.sortOrder
        FROM DWH.LKP_ratingMatrix RM
        INNER JOIN DWH.LKP_rating AS R ON RM.[_rating_ID] = R.ID
        INNER JOIN DWH.LKP_ratingOrganization RO ON RM._ratingOrganization_ID = RO.ID       
    ), CP AS (
        SELECT C.ID AS _counterpart_ID, C.shortname, C.counterpartIdentity
        FROM DWH.counterpart AS C
        INNER JOIN DWH.loadContext AS LC ON C.[_loadContext_ID] = LC.ID
        WHERE (1=1)
        AND C.reportDate = @reportDate 
        AND LC.extractContext = @extractContext
   ), CPMAT AS (
      SELECT 
          CP.counterpartIdentity   
        , CP.shortname   
        , CR._counterpart_ID
        , MAT._ratingMatrix_ID
        , MAT.organization
        , MAT._ratingOrganization_ID
        , MAT.rating
        , MAT.sortOrder

        FROM CP
        INNER JOIN DWH.counterpartRating CR ON CR.[_counterpart_ID] = CP.[_counterpart_ID]
        LEFT JOIN MAT ON CR.[_ratingMatrix_ID] = MAT._ratingMatrix_ID
   ), NOTCH AS (
      SELECT CPMAT.counterpartIdentity
          , CPMAT.shortname
          , CPMAT.[_counterpart_ID]
          , CPMAT.[_ratingMatrix_ID]
          , CPMAT.organization
          , CPMAT.[_ratingOrganization_ID]
          , CPMAT.rating
          , CPMAT.sortOrder
          , SRN.notch
        , CASE 
            WHEN CPMAT.sortOrder > (
                CASE 
                    WHEN organization IN ('Standard & Poors', 'Moodys', 'Fitch', 'Secured Rating', 'Other Rating') THEN 21 
                    WHEN organization IN ('SEK Internal Rating', 'Calculated Rating') THEN 19 
                    ELSE 21
                END
            ) THEN CPMAT.sortOrder
            WHEN CPMAT.sortOrder - notch < 1 THEN 1
            WHEN CPMAT.sortOrder - notch > (
                CASE 
                    WHEN organization IN ('Standard & Poors', 'Moodys', 'Fitch', 'Secured Rating', 'Other Rating') THEN 21 
                    WHEN organization IN ('SEK Internal Rating', 'Calculated Rating') THEN 19 
                    ELSE 21
                END
            ) THEN 21
            ELSE CPMAT.sortOrder - notch
          END AS newSortOrder
      FROM CPMAT
      LEFT JOIN DWH.LKP_stressRatingNotch AS SRN ON CPMAT.shortname = SRN.shortname
      AND SRN._scenario_ID = @scenarioID
   ), STAT AS (
        SELECT 
          CP._counterpart_ID
        , SR._ratingMatrix_ID
        , MAT.organization
        , MAT._ratingOrganization_ID
        , MAT.rating
        , MAT.sortOrder
        FROM DWH.LKP_stressRating SR
        INNER JOIN CP ON SR.shortname = CP.shortname      
        INNER JOIN MAT ON SR.[_ratingMatrix_ID] = MAT.[_ratingMatrix_ID]
        WHERE (1=1)
        AND SR._scenario_ID = @scenarioID
   ) 
    SELECT 
      CPMAT.counterpartIdentity          
    , CPMAT._counterpart_ID
    , CPMAT.organization
    , CPMAT.[_ratingOrganization_ID]
    , COALESCE(STAT._ratingMatrix_ID, NOTCHED._ratingMatrix_ID, CPMAT._ratingMatrix_ID) AS _ratingMatrix_ID
    , CASE WHEN STAT._ratingMatrix_ID IS NOT NULL OR (NOTCH.notch IS NOT NULL AND NOTCH.newSortOrder <= (
                CASE 
                    WHEN CPMAT.organization IN ('Standard & Poors', 'Moodys', 'Fitch', 'Secured Rating', 'Other Rating') THEN 21 
                    WHEN CPMAT.organization IN ('SEK Internal Rating', 'Calculated Rating') THEN 19 
                    ELSE 21
                END
            )
    ) THEN 1 ELSE 0 END AS isOverridden
    , NOTCH.notch
    , COALESCE(STAT.rating, NOTCHED.rating, CPMAT.rating) AS rating
    , COALESCE(STAT.sortOrder, NOTCHED.sortOrder, CPMAT.sortOrder) AS sortOrder  
   FROM CPMAT
   -- 2012-10-31 MaSo - Nedan använder vi HASH JOINs för att SQL Server inte fattar det själv
   LEFT HASH JOIN STAT 
    ON CPMAT._counterpart_ID = STAT._counterpart_ID 
    AND CPMAT._ratingOrganization_ID = STAT._ratingOrganization_ID
   LEFT HASH JOIN NOTCH
    ON CPMAT._counterpart_ID = NOTCH._counterpart_ID
    AND CPMAT._ratingOrganization_ID = NOTCH._ratingOrganization_ID
   LEFT HASH JOIN MAT AS NOTCHED
      ON NOTCH.[_ratingOrganization_ID] = NOTCHED.[_ratingOrganization_ID]
      AND NOTCH.newSortOrder = NOTCHED.sortOrder
)
GO