--liquibase formatted sql

--changeSet func:Initial-ACBS-field_RAW_entity-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('ACBS.field_RAW_entity', 'FN') IS NULL EXEC('CREATE FUNCTION [ACBS].[field_RAW_entity](@portfolio varchar(8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-ACBS-field_RAW_entity-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [ACBS].[field_RAW_entity]
(
	@portfolio VARCHAR(8)
)
RETURNS VARCHAR(10)
AS
BEGIN
	RETURN
		CASE
			WHEN @portfolio = 'TRADSEC'		THEN 'SEK SEC'
			WHEN @portfolio = 'FUNDCIRR'	THEN 'SEK S-SECT'
			WHEN @portfolio = 'FUNDSIDA'	THEN 'SEK S-SECT'
			WHEN @portfolio = 'STRFCIRR'	THEN 'SEK S-SECT'
			WHEN @portfolio = 'STRFSIDA'	THEN 'SEK S-SECT'
			WHEN @portfolio = 'SEKADV'		THEN 'SEK ADV'
			ELSE 'SEK AB'
		END
END