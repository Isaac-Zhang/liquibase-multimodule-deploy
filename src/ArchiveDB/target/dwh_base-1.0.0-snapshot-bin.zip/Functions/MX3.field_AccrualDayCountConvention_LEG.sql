--liquibase formatted sql

--changeSet func:Initial-MX3-field_AccrualDayCountConvention_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_AccrualDayCountConvention_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_AccrualDayCountConvention_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@m_tp_rtmcnv0 varchar(50),@m_tp_rtmcnv1 varchar(50)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_AccrualDayCountConvention_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_AccrualDayCountConvention_LEG]
(
	@mxContractType	VARCHAR(10),
	@COM_leg_LEG		int,
   @m_tp_rtmcnv0		VARCHAR(50),
   @m_tp_rtmcnv1		VARCHAR(50)
)
RETURNS VARCHAR(50)
AS
BEGIN
	RETURN
		CASE
			WHEN @COM_leg_LEG = 1 THEN NULLIF(@m_tp_rtmcnv0,'')
			WHEN @COM_leg_LEG = 2 THEN NULLIF(@m_tp_rtmcnv1,'')
		END
END
GO