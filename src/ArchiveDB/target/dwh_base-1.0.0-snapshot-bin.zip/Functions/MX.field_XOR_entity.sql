--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_entity-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_entity', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_entity](@PL_M_TP_ENTITY varchar(10)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_entity-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_entity]
(
	@PL_M_TP_ENTITY varchar(10)
)
RETURNS varchar(5)
AS
BEGIN
	RETURN
		CASE
			WHEN @PL_M_TP_ENTITY = 'SEK'
			THEN 'KONC'
			ELSE
					CASE
				WHEN @PL_M_TP_ENTITY = 'SEK AB'
				THEN 'SEK'
				ELSE
					CASE
					WHEN @PL_M_TP_ENTITY = 'SEK S-SECT'
				THEN 'SEKS'
				ELSE
						CASE
						WHEN @PL_M_TP_ENTITY = 'SEK SEC'
					THEN 'SUB2'
					ELSE
						CASE
						WHEN @PL_M_TP_ENTITY = 'SEK-TIONEN'
						THEN 'SUB1'
						ELSE 'ERR'
						END
					END
				END
				END
			END
END
GO