--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_maturity_date-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_maturity_date', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_maturity_date](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_BUY varchar(1),@PL_M_TP_DTELST datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_DTEFLWL datetime,@PL_M_TP_RTMAT0 datetime,@PL_M_TP_RTMAT1 datetime,@SEC_M_SE_MAT datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_maturity_date-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_maturity_date]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5),
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_DTELST datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_DTEFLWL datetime,
    @PL_M_TP_RTMAT0 datetime,
    @PL_M_TP_RTMAT1 datetime,
    @SEC_M_SE_MAT datetime
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
			  ------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			  THEN @PL_M_TP_DTELST
			  ------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			  THEN @PL_M_TP_DTEEXP
			  ------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			  THEN CASE
				 WHEN @PL_M_TP_BUY = 'B'
			   THEN @PL_M_TP_RTMAT0
			   ELSE @PL_M_TP_RTMAT1
			   END
			  ------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			  THEN @PL_M_TP_DTEEXP
			  ------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN @PL_M_TP_DTEEXP
			  WHEN @COM_leg_LEG = 2
			  THEN @PL_M_TP_DTEEXP
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			  THEN @PL_M_TP_RTMAT0
			  ------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN @PL_M_TP_RTMAT0
			  WHEN @COM_leg_LEG = 2
			  THEN @PL_M_TP_RTMAT1
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			  THEN CASE
				 WHEN @COM_contractType_TRN = 'CALL'
			   THEN @SEC_M_SE_MAT
			   ELSE @PL_M_TP_DTEEXP
			   END
			  ------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			  THEN @PL_M_TP_RTMAT0
			  ------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN @PL_M_TP_RTMAT0
			  WHEN @COM_leg_LEG = 2
			  THEN @PL_M_TP_RTMAT1
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			  THEN
				  CASE
			  WHEN @COM_leg_LEG = 1
			  THEN @PL_M_TP_RTMAT0
			  WHEN @COM_leg_LEG = 2
			  THEN @PL_M_TP_RTMAT1
			  ELSE NULL
			  END
			  ------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			  THEN @PL_M_TP_DTEFLWL
			  ------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			  THEN @PL_M_TP_DTEEXP
			  ------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
			  THEN @PL_M_TP_DTEEXP
			  ------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			  WHEN @COM_contractGroup_TRN = 'OPT'
			  THEN @PL_M_TP_DTEEXP
			  ------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			  WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			  THEN @PL_M_TP_DTEEXP
		ELSE NULL
		END
END
GO