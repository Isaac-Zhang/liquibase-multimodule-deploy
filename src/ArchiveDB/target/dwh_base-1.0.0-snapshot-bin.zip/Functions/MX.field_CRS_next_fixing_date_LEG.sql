--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_next_fixing_date_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_next_fixing_date_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_next_fixing_date_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@reportDate date,@PL_M_TP_RTDXG01 datetime,@PL_M_TP_RTDXG11 datetime,@PL_M_TP_RTDKN01 datetime,@PL_M_TP_RTDKN11 datetime,@PL_M_TP_RTDXC01 datetime,@PL_M_TP_RTDXC11 datetime,@PL_M_TP_RTDXP01 datetime,@PL_M_TP_RTDXP11 datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_STATUS1 varchar(10)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_next_fixing_date_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_next_fixing_date_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
    @reportDate date,
    @PL_M_TP_RTDXG01 datetime,
    @PL_M_TP_RTDXG11 datetime,
    @PL_M_TP_RTDKN01 datetime,
    @PL_M_TP_RTDKN11 datetime,
    @PL_M_TP_RTDXC01 datetime,
    @PL_M_TP_RTDXC11 datetime,
    @PL_M_TP_RTDXP01 datetime,
    @PL_M_TP_RTDXP11 datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_STATUS1 varchar(10)
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
            -- Set next fixing to NULL if contract is dead
            WHEN @PL_M_TP_STATUS1 = 'DEAD' THEN NULL
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			WHEN @mxContractType = 'ASWP'
			THEN CASE
			     WHEN @COM_leg_LEG = 1
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			          WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			          WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			          ELSE NULL
			          END
			     WHEN @COM_leg_LEG = 2
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP11 > @reportDate THEN @PL_M_TP_RTDXP11
			          WHEN @PL_M_TP_RTDXC11 > @reportDate THEN @PL_M_TP_RTDXC11
			          WHEN @PL_M_TP_RTDXG11 > @reportDate THEN @PL_M_TP_RTDXG11
			          ELSE NULL
			          END
			     END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			WHEN @mxContractType = 'BOND'
			THEN CASE
                 WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			     WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			     WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			     ELSE NULL
			     END
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			WHEN @mxContractType = 'CD'
			THEN CASE
                 WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			     WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			     WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			     ELSE NULL
			     END
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			WHEN @mxContractType = 'CF'
			THEN CASE
                 WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			     WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			     WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			     ELSE NULL
			     END
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType = 'CDS'
			THEN NULL
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			WHEN @mxContractType = 'CS'
			THEN CASE
			     WHEN @COM_leg_LEG = 1
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			          WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			          WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			          ELSE NULL
			          END
			     WHEN @COM_leg_LEG = 2
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP11 > @reportDate THEN @PL_M_TP_RTDXP11
			          WHEN @PL_M_TP_RTDXC11 > @reportDate THEN @PL_M_TP_RTDXC11
			          WHEN @PL_M_TP_RTDXG11 > @reportDate THEN @PL_M_TP_RTDXG11
			          ELSE NULL
			          END
			     END
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			WHEN @mxContractType = 'FRA'
			THEN CASE
			     WHEN @PL_M_TP_RTDXC11 > @reportDate 
			     THEN @PL_M_TP_RTDXC11 
			     ELSE NULL 
			     END
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			WHEN @mxContractType = 'FUT'
			THEN CASE
			     WHEN DATEADD(dd,-2,@PL_M_TP_DTEEXP) > @reportDate 
			     THEN DATEADD(dd,-2,@PL_M_TP_DTEEXP)
			     ELSE NULL
			     END
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType = 'FXD'
			THEN NULL
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType = 'IRS'
			THEN CASE
			     WHEN @COM_leg_LEG = 1
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			          WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			          WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			          ELSE NULL
			          END
			     WHEN @COM_leg_LEG = 2
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP11 > @reportDate THEN @PL_M_TP_RTDXP11
			          WHEN @PL_M_TP_RTDXC11 > @reportDate THEN @PL_M_TP_RTDXC11
			          WHEN @PL_M_TP_RTDXG11 > @reportDate THEN @PL_M_TP_RTDXG11
			          ELSE NULL
			          END
			     END
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			WHEN @mxContractType = 'LN_BR'
			THEN CASE
                 WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			     WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			     WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			     ELSE NULL
			     END
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType = 'REPO'
			THEN CASE
                 WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			     WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			     WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			     ELSE NULL
			     END
			---------------------------------------------------- CRS_OSWP ----------------------------------------------------
            WHEN @mxContractType = 'OSWP'
			THEN CASE
			     WHEN @COM_leg_LEG = 1
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP01 > @reportDate THEN @PL_M_TP_RTDXP01
			          WHEN @PL_M_TP_RTDXC01 > @reportDate THEN @PL_M_TP_RTDXC01
			          WHEN @PL_M_TP_RTDXG01 > @reportDate THEN @PL_M_TP_RTDXG01
			          ELSE NULL
			          END
			     WHEN @COM_leg_LEG = 2
			     THEN CASE
                      WHEN @PL_M_TP_RTDXP11 > @reportDate THEN @PL_M_TP_RTDXP11
			          WHEN @PL_M_TP_RTDXC11 > @reportDate THEN @PL_M_TP_RTDXC11
			          WHEN @PL_M_TP_RTDXG11 > @reportDate THEN @PL_M_TP_RTDXG11
			          ELSE NULL
			          END
			     END
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType = 'XSW'
			THEN NULL

		ELSE NULL
		END
END
GO