--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_XIT_FLOW-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_XIT_FLOW', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_XIT_FLOW](@PL_M_TP_MOPLSTL varchar(10),@F_FLOW_NO_OF_FUTURE_FLOWS int) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_XIT_FLOW-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_XIT_FLOW]
(
	@PL_M_TP_MOPLSTL varchar(10), 
	@F_FLOW_NO_OF_FUTURE_FLOWS int
)
RETURNS BIT
AS
BEGIN
	RETURN
        CASE WHEN @PL_M_TP_MOPLSTL = 'XIT' AND @F_FLOW_NO_OF_FUTURE_FLOWS > 0 THEN 1 ELSE 0 END
END
GO