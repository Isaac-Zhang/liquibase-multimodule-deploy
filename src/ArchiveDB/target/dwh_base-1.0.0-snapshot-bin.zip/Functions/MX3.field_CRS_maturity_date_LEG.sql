--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_maturity_date_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_maturity_date_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_maturity_date_LEG](@mxContractType varchar(10),@COM_contractType_TRN varchar(10),@PL_M_TP_RTMAT0 datetime,@PL_M_TP_DTEEXP datetime,@PL_M_TP_BUY varchar(1),@PL_M_TP_RTMAT1 datetime,@PL_M_TP_DTEPMT2 datetime,@SEC_M_SE_MAT datetime,@PL_M_QTY_INDEX tinyint) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_maturity_date_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX3].[field_CRS_maturity_date_LEG]
(
	@mxContractType varchar(10), 
    @COM_contractType_TRN varchar(10),
	@PL_M_TP_RTMAT0 datetime,
    @PL_M_TP_DTEEXP datetime,
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_RTMAT1 datetime,
    @PL_M_TP_DTEPMT2 datetime,
    @SEC_M_SE_MAT datetime,
    @PL_M_QTY_INDEX TINYINT
)
RETURNS datetime
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------@------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CD', 'CDS', 'CS', 'IRS', 'LN_BR', 'OSWP', 'FDB', 'NDB', 'CF') THEN @PL_M_TP_RTMAT0
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			WHEN @mxContractType IN ('BOND') THEN
			    CASE WHEN @COM_contractType_TRN = 'CALL' THEN @SEC_M_SE_MAT ELSE @PL_M_TP_DTEEXP END
			--IIF('CALL'$TRN_TYPE,DTBLFIELD('SE_HEAD.SE_MAT','SE_LABEL',INSTRMNT), TP_DTEEXP)
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			WHEN @mxContractType = 'FRA' THEN 
                CASE
			        WHEN @PL_M_TP_BUY = 'B' THEN @PL_M_TP_RTMAT0 ELSE @PL_M_TP_RTMAT1 END
			    --IIF(TP_BUY=='B',TP_RTMAT0,TP_RTMAT1)
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			WHEN @mxContractType = 'FUT' THEN DATEADD(dd,90,@PL_M_TP_DTEEXP)
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType IN ('FXD', 'REPO', 'OPT') THEN @PL_M_TP_DTEEXP
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('XSW') THEN @PL_M_TP_DTEEXP

		    WHEN @mxContractType = 'SCF' THEN @PL_M_TP_DTEEXP
		ELSE NULL
		END
END
