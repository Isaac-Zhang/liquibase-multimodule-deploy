--liquibase formatted sql

--changeSet func:Initial-DWH-fnContractValues-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnContractValues', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnContractValues](@reportDate date,@loadContextID int,@contractIDs xml) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnContractValues-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
-- User Defined Function
ALTER FUNCTION  [DWH].[fnContractValues](
   @reportDate date
 , @loadContextID int
 , @contractIDs xml = NULL)
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnContractValues
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate               DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with all contractValues pivoted to columns
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s         :
  -- !                        select * from DWH.fnContractValues('2010-05-03', 'EOD');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-06-02 HAWI  Initial version by Håkan Winther, SQL Service AB
  -- !                       2012-04-15 ChTh  Modified to use loadContext to improve performance
  -- !                       2012-04-17 MaSo  Added discountedFutureCF, IRAdjustedMarketValue, spreadBP, spreadNonDiscounted, spreadDiscounted
  -- !                       2012-05-11 MaSo  Name change of optionPremiumValue columns
  -- !                       2013-04-17 MaSo  Added lotSize
  -- !                       2013-09-10 PEHA  Added interestMargin
  -- !                       2013-09-10 PEHA  Added BrokerageFee
  -- !                       2014-11-20 GoLu  CHG0011354 - added Mid, _midCurrency_ID, midCurrencyCode
-- +----------------------------------------------------------------------------------------------------------------
AS RETURN
(
   -- Get all contracts as CTE
   -- Get all contract values into CTE
   WITH CV AS (
      SELECT 
          CV._contract_id,
          CV._contractType_ID, 
          CV._legtype_ID,
          CV.legNumber,
          CV._currency_ID, 
          CCY.currencyCode,
          CV.value, 
          VT.valueType

      FROM @contractIDs.nodes('/row') T1(ContractNode)
	   INNER JOIN DWH.contractValues CV			ON ContractNode.value('@ID[1]', 'INT') = CV._contract_ID
	   INNER JOIN DWH.contractValueType CVT      ON CV._contractValueType_ID = CVT.ID
	   INNER JOIN DWH.LKP_valueType VT           ON CVT._valueType_ID = VT.ID
	   INNER JOIN DWH.LKP_currency CCY           ON CV._currency_ID = CCY.ID
      WHERE 
         CV.reportDate = @reportDate 
         AND CV._loadContext_ID = @loadContextID
         AND @contractIDs IS NOT NULL
      UNION ALL   
      SELECT 
          CV._contract_id,
          CV._contractType_ID, 
          CV._legtype_ID,
          CV.legNumber,
          CV._currency_ID, 
          CCY.currencyCode,
          CV.value, 
          VT.valueType
      FROM DWH.contractValues CV
      INNER JOIN DWH.contractValueType CVT      ON  CV._contractValueType_ID = CVT.ID
      INNER JOIN DWH.LKP_valueType VT           ON  CVT._valueType_ID = VT.ID
      INNER JOIN DWH.LKP_currency CCY           ON CV._currency_ID = CCY.ID
      WHERE 
         CV.reportDate = @reportDate 
         AND CV._loadContext_ID = @loadContextID
         AND @contractIDs IS NULL
   )
   -- Select result from joins and inner selects
   SELECT 
        VAL._contract_ID      
      , VAL._contractType_ID      
      , VAL._legType_ID       
      , VAL.legNumber
      , VAL.sourceSystemFairValue
      , CURR._sourceSystemFairValueCurrency_ID
      , CODE.sourceSystemFairValueCurrencyCode
      , VAL.nominalAmountOrig
      , CURR._nominalAmountOrigCurrency_ID
      , CODE.nominalAmountOrigCurrencyCode
      , VAL.nominalAmount
      , CURR._nominalAmountCurrency_ID
      , CODE.nominalAmountCurrencyCode
      , VAL.interestRate AS couponRate
      , VAL.interestRateSpread AS couponRateSpread
      , VAL.accruedInterest, CURR._accruedInterestCurrency_ID, CODE.accruedInterestCurrencyCode
      , VAL.externAllIn, CURR._externAllInCurrency_ID, CODE.externAllInCurrencyCode
      , VAL.externAllIn2, CURR._externAllIn2Currency_ID, CODE.externAllIn2CurrencyCode
      , VAL.optionMarketValue
      , VAL.optionQuantity
      , VAL.optionPremiumValue AS premium
      , CURR._optionPremiumValueCurrency_ID AS _premiumCurrency_ID
      , CODE.optionPremiumValueCurrencyCode AS premiumCurrencyCode
      , VAL.optionStrikeValue
      , VAL.optionCapLevel
      , VAL.optionBarrier
      , VAL.optionBarrierRebate
      , VAL.totalMargin
      , VAL.initialPrice
      , VAL.cleanPrice
      , VAL.dirtyPrice
      , VAL.initialQuantity
      , VAL.liveQuantity
      , VAL.initialInterestRate
      , VAL.discountedFutureCF
      , VAL.IRAdjustedMarketValue
      , VAL.spreadBP
      , VAL.spreadNonDiscounted
      , VAL.spreadDiscounted
      , VAL.lotSize
      , VAL.interestMargin
      , VAL.brokerageFee
      , VAL.Mid
      , CURR._midCurrency_ID
      , CODE.midCurrencyCode
   FROM (
      ------------------------------------------------------------------------------------------
      -- Get all values and pivot them
      ------------------------------------------------------------------------------------------
    SELECT 
        _contract_id,
        _contractType_ID, 
        _legtype_ID, 
        legNumber,
        sourceSystemFairValue, 
        nominalAmountOrig,
        nominalAmount,
        interestRate,
        interestRateSpread,
        accruedInterest,
        externAllIn,
        externAllIn2,
        optionMarketValue,
        optionQuantity,
        optionPremiumValue,
        optionStrikeValue,
        optionCapLevel,
        optionBarrier,
        optionBarrierRebate,
        totalMargin,
        initialPrice,
        cleanPrice,
        dirtyPrice,
        initialQuantity,
        liveQuantity,
        initialInterestRate,
        discountedFutureCF,
        IRAdjustedMarketValue,
        spreadBP,
        spreadNonDiscounted,
        spreadDiscounted,
        lotSize,
        interestMargin,
        brokerageFee,
		Mid
    FROM ( 
         SELECT 
            _contract_id, 
            _contractType_ID, 
            _legtype_ID,
            legNumber,
            value, 
            valueType   
         FROM CV 
      ) A
      PIVOT
      (
         MAX([Value])
         FOR valueType IN
         (
            sourceSystemFairValue, 
            nominalAmountOrig, 
            nominalAmount,
            interestRate, 
            interestRateSpread, 
            accruedInterest,
            externAllIn,
            externAllIn2,
            optionMarketValue,
            optionQuantity,
            optionPremiumValue,
            optionStrikeValue,
            optionCapLevel,
            optionBarrier,
            optionBarrierRebate,
            totalMargin,
            initialPrice,
            cleanPrice,
            dirtyPrice,
            initialQuantity,
            liveQuantity,
            initialInterestRate,
            discountedFutureCF,
            IRAdjustedMarketValue,
            spreadBP,
            spreadNonDiscounted,
            spreadDiscounted,
            lotSize,
            interestMargin,
            brokerageFee,
            Mid
         )
      ) AS pvt
   ) VAL

   ------------------------------------------------------------------------------------------
   -- Get all currency ID's and pivot them
   ------------------------------------------------------------------------------------------
   LEFT JOIN (
      SELECT 
         _contract_id,
         _contractType_ID, 
         _legtype_ID, 
            legNumber,
         sourceSystemFairValue   AS _sourceSystemFairValueCurrency_ID, 
         nominalAmountOrig       AS _nominalAmountOrigCurrency_ID,
            nominalAmount        AS _nominalAmountCurrency_ID,
            accruedInterest      AS _accruedInterestCurrency_ID,
            externAllIn          AS _externAllInCurrency_ID,
            externAllIn2         AS _externAllIn2Currency_ID,
            optionPremiumValue   AS _optionPremiumValueCurrency_ID,
            mid                  AS _midCurrency_ID
      FROM (
        SELECT 
            _contract_ID, 
            _contractType_ID, 
            _legType_ID, 
            legNumber,
            _currency_ID, 
            valueType 
         FROM CV 
      ) A
      PIVOT
      (
         MAX([_currency_ID])
         FOR valueType IN (
            sourceSystemFairValue, 
            nominalAmountOrig,
            nominalAmount,
            accruedInterest,
            externAllIn,
            externAllIn2,
            optionPremiumValue,
            mid            
         )
      ) AS pvt
   ) CURR   ON   VAL._contract_ID      = CURR._contract_ID
         AND   VAL._contractType_ID   = CURR._contractType_ID
         AND VAL._legType_ID         = CURR._legType_ID
            AND VAL.legNumber           = CURR.legNumber

   ------------------------------------------------------------------------------------------
   -- Get all currencyCodes and pivot them
   ------------------------------------------------------------------------------------------
   LEFT JOIN (
      SELECT 
         _contract_id,
         _contractType_ID, 
         _legtype_ID, 
            legNumber,
         sourceSystemFairValue       AS sourceSystemFairValueCurrencyCode, 
         nominalAmountOrig           AS nominalAmountOrigCurrencyCode,
            nominalAmount            AS nominalAmountCurrencyCode,
            accruedInterest          AS accruedInterestCurrencyCode,
            externAllIn              AS externAllInCurrencyCode,
            externAllIn2             AS externAllIn2CurrencyCode,
            optionPremiumValue       AS optionPremiumValueCurrencyCode,
            mid						 AS midCurrencyCode
      FROM (
         SELECT 
            _contract_ID, 
            _contractType_ID, 
            _legType_ID, 
            legNumber,
            currencyCode, 
            valueType 
         FROM CV 
      ) A
      PIVOT
      (
         MAX([currencyCode])
         FOR valueType IN (
            sourceSystemFairValue, 
            nominalAmountOrig,
            nominalAmount,
            accruedInterest,
            externAllIn,
            externAllIn2,
            optionPremiumValue,
            mid          
         )
      ) AS pvt
   ) CODE   ON   VAL._contract_ID      = CODE._contract_ID
         AND   VAL._contractType_ID   = CODE._contractType_ID
         AND VAL._legType_ID         = CODE._legType_ID
            AND VAL.legNumber           = CODE.legNumber
)
GO