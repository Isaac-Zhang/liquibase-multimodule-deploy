--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_bond_leg-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_bond_leg', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_bond_leg](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@PL_M_PACK_REF numeric(10,0),@PL_M_TP_TYPO varchar(20),@SEC_M_SE_GROUP varchar(10)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_bond_leg-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [MX3].[field_XOR_bond_leg]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5), 
    @COM_leg_LEG int,
    @PL_M_PACK_REF numeric(10,0),
    @PL_M_TP_TYPO varchar(20),
    @SEC_M_SE_GROUP varchar(10)
)
RETURNS BIT
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN
				CASE
				WHEN @PL_M_PACK_REF > 0
			THEN 1
			ELSE 0
			END
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN 1
			WHEN @COM_leg_LEG = 2
			THEN 0
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN
				CASE
				WHEN @PL_M_PACK_REF > 0
			THEN 1
			ELSE 0
			END
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN
				CASE
				WHEN LTRIM(RTRIM(@PL_M_TP_TYPO)) = 'Bond_ED'
			THEN 1
			ELSE 0
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN @SEC_M_SE_GROUP
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN
				CASE
				WHEN @PL_M_PACK_REF > 0
			THEN 1
			ELSE 0
			END
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN
				CASE
				WHEN @PL_M_PACK_REF > 0
			THEN 1
			ELSE 0
			END
		ELSE NULL
		END

END

