--liquibase formatted sql

--changeSet func:Initial-DWH-fnInstrumentTriggerEvent-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnInstrumentTriggerEvent', 'TF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnInstrumentTriggerEvent](@reportDate date,@extractContext char(3)) RETURNS @tab TABLE ([_instrument_ID] int,[triggerEventType] varchar(50),[triggerRepaymentPercent] numeric(28,8),[triggerLevel] numeric(28,8),[triggerNoticePeriod] numeric(28,8),[triggerStartDate] date,[triggerEndDate] date,[triggerStartCallDate] date,[triggerEndCallDate] date,[accrualsPaid] bit) AS BEGIN RETURN END')
GO



--changeSet func:Initial-DWH-fnInstrumentTriggerEvent-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnInstrumentTriggerEvent]
(
@reportDate DATE
,@extractContext CHAR(3)
)

RETURNS @instrumentEventTable TABLE
(
_instrument_ID           int
,triggerEventType        varchar(50)
,triggerRepaymentPercent NUMERIC(28,8)
,triggerLevel            NUMERIC(28,8)
,triggerNoticePeriod     NUMERIC(28,8)
,triggerStartDate        DATE
,triggerEndDate          DATE
,triggerStartCallDate    DATE
,triggerEndCallDate      DATE
,accrualsPaid            BIT
)

AS 
BEGIN

DECLARE @loadContextID int = (SELECT ID 
                              FROM DWH.loadContext
                              WHERE reportDate = @reportDate AND extractContext = @extractContext
                             )

DECLARE @INSTRUMENTEVENT TABLE (id INT, _instrument_ID int, eventType varchar(50), accrualsPaid bit, PRIMARY KEY CLUSTERED (id))
DECLARE @EVENTVALUES TABLE (id INT, VALUE NUMERIC(28,8), valueType VARCHAR(50), PRIMARY KEY CLUSTERED(id, valueType))
DECLARE @EVENTDATES TABLE (id INT, VALUE DATE, dateType VARCHAR(50), PRIMARY KEY CLUSTERED (id, dateType))
--
INSERT INTO @INSTRUMENTEVENT
  SELECT IE.ID, IE._instrument_ID, LET.eventType, IE.accrualsPaid
  FROM DWH.instrumentEvent IE
  INNER JOIN DWH.LKP_eventType AS LET ON IE.[_eventType_ID] = LET.ID
  WHERE IE.reportDate = @reportDate
  AND IE.[_loadContext_ID] = @loadContextID
--
INSERT INTO @EVENTVALUES
  SELECT IE.ID, IEV.value, VT.valueType
  FROM DWH.instrumentEvent IE
  INNER JOIN DWH.instrumentEventValues IEV
    ON IEV._instrumentEvent_ID = IE.ID
  INNER JOIN DWH.LKP_valueType VT
    ON IEV._valueType_ID = VT.ID
  WHERE IE.reportDate = @reportDate
  AND IE._loadContext_ID = @loadContextID
  AND VT.valueType IN ('triggerRepaymentPercent','triggerLevel', 'triggerNoticePeriod')
--
INSERT INTO @EVENTDATES
  SELECT IE.ID, IED.value, DT.dateType
  FROM DWH.instrumentEvent IE 
  INNER JOIN DWH.instrumentEventDate IED ON IED._instrumentEvent_ID = IE.ID
  INNER JOIN DWH.LKP_dateType DT on IED._dateType_ID = DT.ID
  WHERE IE.reportDate = @reportDate
  AND IE._loadContext_ID = @loadContextID
  AND DT.dateType IN ('triggerStartDate', 'triggerEndDate', 'triggerStartCallDate', 'triggerEndCallDate')
--
INSERT INTO @instrumentEventTable
SELECT 
  IE._instrument_ID AS _instrument_ID
, IE.eventType      AS triggerEventType
, trp.value         AS triggerRepaymentPercent
, tl.value          AS triggerLevel
, tnp.value         AS triggerNoticePeriod
, tsd.value         AS triggerStartDate
, ted.value         AS triggerEndDate
, tscd.value        AS triggerStartCallDate
, tecd.value        AS triggerEndCallDate
, IE.accrualsPaid   AS accrualsPaid
FROM @INSTRUMENTEVENT IE
INNER  JOIN @EVENTVALUES AS trp
   ON trp.ID = IE.ID
   AND trp.valueType = 'triggerRepaymentPercent'
-- Puts don't have triggerLevel
LEFT  JOIN @EVENTVALUES AS tl
  ON IE.id = tl.ID
  AND tl.valueType = 'triggerLevel'
INNER  JOIN @EVENTVALUES AS tnp
  ON IE.id = tnp.ID
  AND tnp.valueType = 'triggerNoticePeriod'
INNER  JOIN @EVENTDATES AS tsd 
  ON IE.id = tsd.ID
  AND tsd.dateType = 'triggerStartDate'
INNER  JOIN @EVENTDATES AS ted
  ON IE.id = ted.ID
  AND ted.dateType = 'triggerEndDate'
INNER  JOIN @EVENTDATES AS tscd
  ON IE.id = tscd.ID
  AND tscd.dateType = 'triggerStartCallDate'
INNER  JOIN @EVENTDATES AS tecd
  ON IE.id = tecd.ID
  AND tecd.dateType = 'triggerEndCallDate'

RETURN
END
GO