--liquibase formatted sql

--changeSet func:Initial-MX-field_optionDeliveryDate-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_optionDeliveryDate', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_optionDeliveryDate](@mxContractType varchar(10),@OP_M_EQ_CCONVP date) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_optionDeliveryDate-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_optionDeliveryDate]
(
	@mxContractType varchar(10),
    @OP_M_EQ_CCONVP date
)
RETURNS date
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType IN ('OPT', 'FDB', 'NDB') THEN @OP_M_EQ_CCONVP
        ELSE NULL
        END
END
GO