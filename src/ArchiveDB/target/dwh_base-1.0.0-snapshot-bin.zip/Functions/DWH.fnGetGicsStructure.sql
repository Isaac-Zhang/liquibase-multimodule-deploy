--liquibase formatted sql

--changeSet func:Initial-DWH-fnGetGicsStructure-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnGetGicsStructure', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnGetGicsStructure](@reportDate date) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnGetGicsStructure-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.fnGetGicsStructure(@reportDate date)
RETURNS TABLE AS RETURN
   WITH GICS AS (
      SELECT G.number, G.parent, G.[level], GD.descr, GD.internalDescription FROM DWH.LKP_GICS G
      INNER JOIN DWH.LKP_GICSdescription GD 
         ON GD.number = G.number
         AND @reportDate BETWEEN GD.validFrom AND GD.validTo
   )
   SELECT 
      sector                                 = GICS_SEC.number 
    , sectorDescription                      = GICS_SEC.descr
    , sectorInternalDescription              = GICS_SEC.internalDescription

    ,  industryGroup                         = GICS_GROUP.number 
    , industryGroupDescription               = GICS_GROUP.descr
    , industryGroupInternalDescription       = GICS_GROUP.internalDescription

    , industry                               = GICS_IND.number 
    , industryDescription                    = GICS_IND.descr
    , industryInternalDescription            = GICS_IND.internalDescription

    , subIndustry                            = GICS_SUB.number 
    , subIndustryDescription                 = GICS_SUB.descr
    , subIndustryInternalDescription         = GICS_SUB.internalDescription
   FROM GICS AS GICS_SUB
   INNER JOIN GICS AS GICS_IND ON GICS_SUB.parent = GICS_IND.number
   INNER JOIN GICS AS GICS_GROUP ON GICS_IND.parent = GICS_GROUP.number
   INNER JOIN GICS AS GICS_SEC ON GICS_GROUP.parent = GICS_SEC.number
   WHERE GICS_SUB.[level] = 4
GO