--liquibase formatted sql

--changeSet func:Initial-DWH-fnContractStatus-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnContractStatus', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnContractStatus](@reportDate date,@loadContextID int,@contractIDs xml) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnContractStatus-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnContractStatus]
(
	@reportDate date
 , @loadContextID int
 , @contractIDs xml = NULL
)
RETURNS TABLE AS RETURN 
(
	SELECT  
      _contract_id,
      _contractType_ID,
		_legType_ID,
		legNumber,
      contractStatus,
      contractStatusStartOfDay,
      revaluationContractStatus0,
      revaluationContractStatus1,
      revaluationContractStatus2,
		sekContractStatusLevel1,
		sekContractStatusLevel2,
      flowState
	FROM 
		(
			SELECT 
				_contract_id,
				_contractType_ID,
				_legType_ID,
				legNumber,
				LKP.[status], 
				CST.[statusType]
			FROM @contractIDs.nodes('/row') T1(ContractNode)
			INNER JOIN DWH.contractStatus CS ON ContractNode.value('@ID[1]', 'INT') = CS._contract_ID
         INNER JOIN DWH.LKP_contractStatus LKP ON CS._contractStatus_ID = LKP.ID
			INNER JOIN DWH.LKP_contractStatusType CST ON CS._contractStatusType_ID = CST.ID
         WHERE 
            CS.reportDate = @reportDate 
            AND CS._loadContext_ID = @loadContextID
            AND @contractIDs IS NOT NULL
		   UNION ALL
			SELECT 
				_contract_id,
				_contractType_ID,
				_legType_ID,
				legNumber,
				LKP.[status], 
				CST.[statusType]
			FROM DWH.contractStatus CS
         INNER JOIN DWH.LKP_contractStatus LKP ON CS._contractStatus_ID = LKP.ID
			INNER JOIN DWH.LKP_contractStatusType CST ON CS._contractStatusType_ID = CST.ID
         WHERE 
            CS.reportDate = @reportDate 
            AND CS._loadContext_ID = @loadContextID
            AND @contractIDs IS NULL
	) AS p
	PIVOT
	(
		MIN([status])
		FOR [statusType] IN
		(
         contractStatus,
         contractStatusStartOfDay,
         revaluationContractStatus0,
         revaluationContractStatus1,
         revaluationContractStatus2,
		 sekContractStatusLevel1,
		 sekContractStatusLevel2,
       flowState
      )
	) AS pvt
 )
GO