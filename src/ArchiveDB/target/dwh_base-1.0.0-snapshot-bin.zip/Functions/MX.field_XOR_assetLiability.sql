--liquibase formatted sql

--changeSet func:Initial-MX-field_XOR_assetLiability-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_XOR_assetLiability', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_XOR_assetLiability](@COM_contractFamily_TRN varchar(5),@COM_contractGroup_TRN varchar(5),@COM_contractType_TRN varchar(5),@COM_leg_LEG int,@COM_quantityIndex_TRN int,@PL_M_TP_TYPO varchar(20),@LTI_TMPL_M_NAME varchar(20),@PL_M_TP_BUY varchar(1),@PL_M_TP_NBLTI numeric(10,0),@PL_M_TP_RTPR0 varchar(1),@PL_M_TP_RTPR1 varchar(1),@LTI_M_METHOD varchar(20)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_XOR_assetLiability-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_XOR_assetLiability]
(
    @COM_contractFamily_TRN varchar(5),
    @COM_contractGroup_TRN varchar(5),
    @COM_contractType_TRN varchar(5), 
    @COM_leg_LEG int,
    @COM_quantityIndex_TRN int,
    @PL_M_TP_TYPO varchar(20),
    @LTI_TMPL_M_NAME varchar(20),
    @PL_M_TP_BUY varchar(1),
    @PL_M_TP_NBLTI numeric(10,0),
    @PL_M_TP_RTPR0 varchar(1),
    @PL_M_TP_RTPR1 varchar(1),
    @LTI_M_METHOD varchar(20)
)
RETURNS varchar(1)
AS
BEGIN
	RETURN
		CASE
			------------------------------------------------------------------------- Contracts_CF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CF' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_TYPO='Hedge_ED', IIF('FUND-'=TRIM(LTI_TYPEN()),'A','L'), '')
				WHEN @PL_M_TP_TYPO = 'Hedge_ED'
			THEN CASE --IIF('FUND-'=TRIM(LTI_TYPEN()),'A','L')
				WHEN LTRIM(RTRIM(@LTI_TMPL_M_NAME)) LIKE '%FUND-%'
			THEN 'A'
			ELSE 'L'
			END
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_EQUIT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'EQD' AND @COM_contractGroup_TRN = 'EQUIT' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_BUY='B','','')
				WHEN @PL_M_TP_BUY = 'B'
			THEN ''
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_M1_FRA --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'FRA' AND @COM_contractType_TRN = ''
			THEN ''
			------------------------------------------------------------------------- Contracts_M1_FUT --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'SFUT' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_BUY='B','','')
				WHEN @PL_M_TP_BUY = 'B'
			THEN ''
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_M1_FXD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN IN ('FXDS','FXD')
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN CASE --IIF(TP_BUY='B','A','L')
				WHEN @PL_M_TP_BUY = 'B'
				THEN 'A'
				ELSE 'L'
				END
			WHEN @COM_leg_LEG = 2
			THEN CASE --IIF(TP_BUY='B','L','A')
				WHEN @PL_M_TP_BUY = 'B'
				THEN 'L'
				ELSE 'A'
				END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M1_LN_BR/CD --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN IN ('LN_BR','CD') AND @COM_contractType_TRN = ''
			THEN CASE --IIF(ISBLANK(A_L_FUND)=0,A_L_FUND, IIF(ISBLANK(A_L_REWRTE)=0,A_L_REWRTE,''))
				WHEN LTRIM(RTRIM(
				CASE--A_L_FUND:IIF(TP_NBLTI>0.AND.LNK_METHOD='Funding swap', IIF(TP_RTPR0='P','A','L'),'')
			WHEN @PL_M_TP_NBLTI > 0 AND @LTI_M_METHOD LIKE '%Funding swap%'
			THEN CASE --IIF(TP_RTPR0='P','A','L')
					WHEN @PL_M_TP_RTPR0 = 'P'
				THEN 'A'
				ELSE 'L'
				END
			ELSE ''
			END
			))
			<>
			''
			THEN CASE--A_L_FUND:IIF(TP_NBLTI>0.AND.LNK_METHOD='Funding swap', IIF(TP_RTPR0='P','A','L'),'')
			WHEN @PL_M_TP_NBLTI > 0 AND @LTI_M_METHOD LIKE '%Funding swap%'
			THEN CASE --IIF(TP_RTPR0='P','A','L')
					WHEN @PL_M_TP_RTPR0 = 'P'
				THEN 'A'
				ELSE 'L'
				END
			ELSE ''
			END
			ELSE CASE --IIF(ISBLANK(A_L_REWRTE)=0,A_L_REWRTE,'')
				WHEN LTRIM(RTRIM(
					CASE--A_L_REWRTE:IIF('Rewrite'$TP_TYPO.AND.'leg'$TP_TYPO, IIF('Rec'$TP_TYPO,'A', IIF('Pay'$TP_TYPO,'L','')),'')
				WHEN @PL_M_TP_TYPO LIKE '%Rewrite%' AND @PL_M_TP_TYPO LIKE '%leg%'
				THEN CASE --IIF('Rec'$TP_TYPO,'A', IIF('Pay'$TP_TYPO,'L',''))
					WHEN @PL_M_TP_TYPO LIKE '%Rec%'
					THEN 'A'
					ELSE CASE --IIF('Pay'$TP_TYPO,'L',''))
						WHEN @PL_M_TP_TYPO LIKE '%Pay%'
						THEN 'L'
						ELSE ''
						END
					END
				ELSE ''
				END
				))
				<>
				''
			THEN CASE--A_L_REWRTE:IIF('Rewrite'$TP_TYPO.AND.'leg'$TP_TYPO, IIF('Rec'$TP_TYPO,'A', IIF('Pay'$TP_TYPO,'L','')),'')
				WHEN @PL_M_TP_TYPO LIKE '%Rewrite%' AND @PL_M_TP_TYPO LIKE '%leg%'
				THEN CASE --IIF('Rec'$TP_TYPO,'A', IIF('Pay'$TP_TYPO,'L',''))
					WHEN @PL_M_TP_TYPO LIKE '%Rec%'
					THEN 'A'
					ELSE CASE --IIF('Pay'$TP_TYPO,'L',''))
						WHEN @PL_M_TP_TYPO LIKE '%Pay%'
						THEN 'L'
						ELSE ''
						END
					END
				ELSE ''
				END
			ELSE ''
			END
			END
			------------------------------------------------------------------------- Contracts_M2_ASWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'ASWP' AND @COM_contractType_TRN = ''
			THEN CASE
			WHEN @COM_leg_LEG = 1
			THEN CASE --IIF(TP_RTPR0='P','L','A')
				WHEN @PL_M_TP_RTPR0 = 'P'
				THEN 'L'
				ELSE 'A'
				END
			WHEN @COM_leg_LEG = 2
			THEN CASE --IIF(TP_RTPR1='P','L','A')
				WHEN @PL_M_TP_RTPR1 = 'P'
				THEN 'L'
				ELSE 'A'
				END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_BOND --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'BOND' AND @COM_contractType_TRN IN ('FWD','','CALL')
			THEN CASE --IIF(TP_BUY='B','','')
				WHEN @PL_M_TP_BUY = 'B'
			THEN ''
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_M2_CDS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CRD' AND @COM_contractGroup_TRN IN ('CDS','FDB','NDB') AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_TYPO='Hedge_ED', IIF(TP_RTPR0='R','A','L'), '')
				WHEN @PL_M_TP_TYPO = 'Hedge_ED'
			THEN CASE --IIF(TP_RTPR0='R','A','L')
				WHEN @PL_M_TP_RTPR0 = 'R'
			THEN 'A'
			ELSE 'L'
			END
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_M2_CS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'CS' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN CASE --IIF(TP_RTPR0='P','L','A')
				WHEN @PL_M_TP_RTPR0 = 'P'
				THEN 'L'
				ELSE 'A'
				END
			WHEN @COM_leg_LEG = 2
			THEN CASE --IIF(TP_TYPO='Bond_ED', '', IIF(TP_RTPR1='P','L','A'))
				WHEN @PL_M_TP_TYPO LIKE '%Bond_ED%'
				THEN ''
				ELSE CASE
					WHEN @PL_M_TP_RTPR1 = 'P'
				THEN 'L'
				ELSE 'A'
				END
				END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_IRS --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'IRS' AND @COM_contractType_TRN = ''
			THEN CASE
			WHEN @COM_leg_LEG = 1
			THEN CASE --IIF(TP_RTPR0='P','L','A')
				WHEN @PL_M_TP_RTPR0 = 'P'
				THEN 'L'
				ELSE 'A'
				END
			WHEN @COM_leg_LEG = 2
			THEN CASE --IIF(TP_RTPR1='P','L','A')
				WHEN @PL_M_TP_RTPR1 = 'P'
				THEN 'L'
				ELSE 'A'
				END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_REPO --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'REPO' AND @COM_contractType_TRN = ''
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN ''
			WHEN @COM_leg_LEG = 2
			THEN CASE --IIF(TP_BUY='B','L','A')
				WHEN @PL_M_TP_BUY = 'B'
				THEN 'L'
				ELSE 'A'
				END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M2_SCF --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'SCF' AND @COM_contractGroup_TRN = 'SCF' AND @COM_contractType_TRN = 'SCF'
			THEN CASE --IIF('Interest Payment'$TP_TYPO.AND.('IRS'$TP_TYPO.OR.'CS'$TP_TYPO), IIF('P'$TP_RTPR0,'L','A'), '')
				WHEN @PL_M_TP_TYPO LIKE '%Interest Payment%' AND (@PL_M_TP_TYPO LIKE '%IRS%' OR @PL_M_TP_TYPO LIKE '%CS%')
			THEN CASE --IIF('P'$TP_RTPR0,'L','A')
				WHEN @PL_M_TP_RTPR0 = 'P'
			THEN 'L'
			ELSE 'A'
			END
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_M2_XSW --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'CURR' AND @COM_contractGroup_TRN = 'FXD' AND @COM_contractType_TRN = 'XSW' AND @COM_quantityIndex_TRN = 1
			THEN
				CASE
			WHEN @COM_leg_LEG = 1
			THEN CASE --IIF(TP_BUY='B','A','L')
				WHEN @PL_M_TP_BUY = 'B'
				THEN 'A'
				ELSE 'L'
				END
			WHEN @COM_leg_LEG = 2
			THEN CASE --IIF(TP_BUY='B','L','A')
				WHEN @PL_M_TP_BUY = 'B'
				THEN 'L'
				ELSE 'A'
				END
			ELSE NULL
			END
			------------------------------------------------------------------------- Contracts_M3_OPT --------------------------------------------------------------------------------
			WHEN @COM_contractGroup_TRN = 'OPT'
			THEN CASE --IIF(TP_TYPO='Hedge_ED', IIF('FUND-'=TRIM(LTI_TYPEN()),'A','L'), '')
				WHEN @PL_M_TP_TYPO = 'Hedge_ED'
			THEN CASE --IIF('FUND-'=TRIM(LTI_TYPEN()),'A','L')
				WHEN LTRIM(RTRIM(@LTI_TMPL_M_NAME)) LIKE '%FUND-%'
			THEN 'A'
			ELSE 'L'
			END
			ELSE ''
			END
			------------------------------------------------------------------------- Contracts_OSWP --------------------------------------------------------------------------------
			WHEN @COM_contractFamily_TRN = 'IRD' AND @COM_contractGroup_TRN = 'OSWP' AND @COM_contractType_TRN = ''
			THEN CASE --IIF(TP_TYPO='Hedge_ED', IIF('FUND-'=TRIM(LTI_TYPEN()),'A','L'), '')
				WHEN @PL_M_TP_TYPO = 'Hedge_ED'
			THEN CASE --IIF('FUND-'=TRIM(LTI_TYPEN()),'A','L')
				WHEN LTRIM(RTRIM(@LTI_TMPL_M_NAME)) LIKE '%FUND-%'
			THEN 'A'
			ELSE 'L'
			END
			ELSE ''
			END
	    ELSE NULL
	    END
END
GO