--liquibase formatted sql

--changeSet func:Initial-DWH-getEntityMapping-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getEntityMapping', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getEntityMapping](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getEntityMapping-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.getEntityMapping(@reportDate date, @extractContext varchar(3))
RETURNS TABLE AS RETURN
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t           DWH.getEntityMapping 
  -- ! R e t u r n s         INT
  -- ! P a r a m e t e r s   Name, DataType, Description
  -- +                       =========================================================================================
  -- !                       @reportDate date
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e
  -- !   Returns a cross-reference list of all registered entities and counterparts and returns if each combination
  -- !   is included in different reporting entities. The function is based on the table LKP_entityMapping
  -- !   which has to be mantained manually.
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !   S A M P L E
  -- !      SELECT * FROM DWH.getEntityMapping('2011-03-11', 'EOD')
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y         Date       Who  What
  -- +                       ========== ==== =========================================================================
  -- !                       2011-03-11 CHTH Initial version ...
  -- !                       2011-03-11 CHTH Added _reportingEntity_ID
  -- + ---------------------------------------------------------------------------------------------------------------
  --
(
   WITH MAXEM AS (
      SELECT contractEntity, counterpartShortname, _reportingEntity_ID, MAX(validFrom) as maxValidFrom
      FROM DWH.LKP_entityMapping
      GROUP BY contractEntity, counterpartShortname, _reportingEntity_ID
   ),
   EM AS (
      SELECT M.contractEntity, M.counterpartShortname, M._reportingEntity_ID, M.isIncluded
      FROM DWH.LKP_entityMapping M
      INNER JOIN MAXEM 
         ON M.contractEntity = MAXEM.contractEntity
         AND M.counterpartShortname = MAXEM.counterpartShortname
         AND M._reportingEntity_ID = MAXEM._reportingEntity_ID
   )
   SELECT 
      COALESCE(I.contractEntity, E.contractEntity) AS contractEntity
    , C.ID AS _counterpart_ID
    , COALESCE(I.isIncluded, E.isIncluded) AS isIncluded
    , COALESCE(REI.reportingEntity, REE.reportingEntity) AS reportingEntity
    , COALESCE(REI.ID, REE.ID) AS _reportingEntity_ID
   FROM DWH.counterpart C
   INNER JOIN DWH.loadContext LC ON C._loadContext_ID = LC.ID
   LEFT JOIN EM AS I ON C.shortname = I.counterpartShortname
   LEFT JOIN EM AS E ON E.counterpartShortname = 'EXTERNAL' AND I.contractEntity IS NULL
   LEFT JOIN DWH.LKP_reportingEntity REI ON I._reportingEntity_ID = REI.ID
   LEFT JOIN DWH.LKP_reportingEntity REE ON E._reportingEntity_ID = REE.ID
   WHERE C.reportDate = @reportDate AND LC.extractContext = @extractContext
)
GO