--liquibase formatted sql

--changeSet func:Initial-DWH-fnLKP_territory-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnLKP_territory', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnLKP_territory](@reportDate date) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnLKP_territory-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnLKP_territory](@reportDate date)
RETURNS TABLE AS RETURN
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t           DWH.fnLKP_territory 
  -- ! R e t u r n s         Result set
  -- ! P a r a m e t e r s   Name, DataType, Description
  -- +                       =========================================================================================
  -- !                       @reportDate, date, usually ReportDate
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e
  -- !   Returns a list of all territories for a given date
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !   S A M P L E
  -- !      SELECT * FROM DWH.fnLKP_territory('2011-03-11') WHERE territoryCode='AD'
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y         Date       Who  What
  -- +                       ========== ==== =========================================================================
  -- !                       2015-02-17 Dajo Initial version ...
  -- !                       2015-05-07 PEHA replaced select *
  -- + ---------------------------------------------------------------------------------------------------------------
  --
SELECT  [ID]
       ,[_territoryType_ID]
       ,[_currency_ID]
       ,[territoryCode]
       ,[territoryName]
       ,[active]
       ,[modificationDate]
       ,[territorySEKname]
       ,[territoryCodeLong]
       ,[validFrom]
       ,[validTo]
       ,[orderIndex]
       ,[modifiedBy]
FROM DWH.LKP_territory
WHERE @reportDate BETWEEN validFrom AND validTo
GO