--liquibase formatted sql

--changeSet func:Initial-DWH-getMigratedLoansACBS-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getMigratedLoansACBS', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getMigratedLoansACBS](@reportDate date,@extractContext char(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getMigratedLoansACBS-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getMigratedLoansACBS](@reportDate date, @extractContext CHAR(3))
RETURNS TABLE 
--SELECT * FROM dwh.[getMigratedLoansACBS]('2012-09-13','eod')
AS 
RETURN
(
	WITH cteACBS
	AS
	(
		-- get the migrated loans
		SELECT 
			ccp._contract_ID, 
			ccp._legType_ID, 
			ccp.legNumber, 
			ccp.[_contractType_ID],
			c.[_package_ID],
			p.PackageID, 
			c.[contractType] 
		FROM dwh.[contract] AS C
		INNER JOIN DWH.[loadContext] AS LC 
			ON [C].[_loadContext_ID] = [LC].[ID]
		INNER JOIN dwh.[LKP_importSource] AS LIS
			ON [C].[_importSource_ID] = [LIS].[ID]
		INNER JOIN dwh.[contractCommonProperty] AS CCP
			ON c.id = ccp.[_contract_ID]
			AND c.[_contractType_ID] = ccp.[_contractType_ID]
		INNER JOIN [DWH].[package] AS P 
			ON c.[_package_ID] = p.id
		WHERE 
			[C].[reportDate] < '2012-12-31' 
			AND LIS.[shortName] ='ACBS'
			AND c.[reportDate] = @reportDate
			AND lc.[reportDate] = @reportDate
			AND lc.[extractContext] = 'EOD'
			AND c.[GWBlnk] IS NOT NULL
	),
	cteCLCM
	AS
	(
		-- get the tradeDate from the CLCM
		SELECT 
			c.*, 
			clcmTradeDate = cd.[eventDate] 
		FROM [cteACBS] c 
		INNER JOIN dwh.[contractDate] AS cd
			ON [c].[_contract_ID] = [cd].[_contract_ID]
			AND [c].[_contractType_ID] = [cd].[_contractType_ID]
			AND [c].[_legType_ID] = [cd].[_legType_ID]
			AND [c].[legNumber] = [cd].[legNumber]
		INNER JOIN dwh.[LKP_dateType] AS LDT 
			ON [cd].[_dateType_ID] = [LDT].[ID]
		WHERE 
			[LDT].[dateType] ='tradeDate'
			AND c.[contractType] = 'CLCM' 
	), 
	cteCLDD
	AS 
	(
		SELECT * 
		FROM cteACBS AS cldd
		WHERE cldd.[contractType] = 'CLDD'
	)
	-- get the loans and the tradeDate from the CLCM
	SELECT 
		cldd.[_contract_ID],
		cldd.[_legType_ID],
		cldd.[legNumber],
		cldd.[_contractType_ID],
		clcm.clcmTradeDate
	FROM [cteCLDD] cldd 
	LEFT JOIN [cteCLCM] clcm
		ON [cldd].[_package_ID] = clcm.[_package_ID]
	WHERE cldd.[contractType] = 'CLDD'
);
GO