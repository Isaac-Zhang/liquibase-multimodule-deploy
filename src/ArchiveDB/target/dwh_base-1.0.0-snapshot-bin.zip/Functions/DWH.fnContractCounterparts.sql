--liquibase formatted sql

--changeSet func:Initial-DWH-fnContractCounterparts-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnContractCounterparts', 'TF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnContractCounterparts](@reportDate date,@extractContext varchar(3),@contractIDs xml) RETURNS @tab TABLE ([_contract_ID] int,[_contractType_ID] int,[Obligor] int,[Issuer] int,[Guarantor] int,[ContractCounterpart] int,[RiskCounterpart] int,[CreditCoveredCounterpart] int,[Broker] int,[Agent] int,[Distributor] int,[BondLeadManager1] int,[BondLeadManager2] int,[BondLeadManager3] int,[BondLeadManager4] int,[Clearer] int,[Buyer] int,[Exchange] int,[Seller] int,[Exporter] int,[Borrower] int,[Lender] int,[SwapCounterpart] int,[FeeCounterpart] int,[ClearingBroker] int,[CentralCounterpart] int,[ExecutingBroker] int,[obligorShortname] varchar(50),[issuerShortname] varchar(50),[guarantorShortname] varchar(50),[contractCounterpartShortname] varchar(50),[creditCoveredCounterpartShortname] varchar(50),[clearingBrokerShortname] varchar(50),[centralCounterpartShortname] varchar(50),[executingBrokerShortname] varchar(50)) AS BEGIN RETURN END')
GO



--changeSet func:Initial-DWH-fnContractCounterparts-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnContractCounterparts]
(
   @reportDate date
 , @extractContext varchar(3)
 , @contractIDs xml = NULL
)
RETURNS @contractCounterparts TABLE (
        _contract_ID                int
      , _contractType_ID            int
      , Obligor                     int
      , Issuer                      int
      , Guarantor                   int
      , ContractCounterpart         int
      , RiskCounterpart             int
      , CreditCoveredCounterpart    int
      , [Broker]                    int
      , Agent                       int
      , Distributor                 int
      , BondLeadManager1            int
      , BondLeadManager2            int
      , BondLeadManager3            int
      , BondLeadManager4            int
      , Clearer                     int
      , Buyer                       int
      , Exchange                    int
      , Seller                      int
      , Exporter                    int
      , Borrower                    int
      , Lender                      int
      , SwapCounterpart             int
      , FeeCounterpart              int
      , ClearingBroker              int
      , CentralCounterpart          int
      , ExecutingBroker             int
      , obligorShortname            varchar(50)
      , issuerShortname             varchar(50)
      , guarantorShortname          varchar(50)
      , contractCounterpartShortname varchar(50)
      , creditCoveredCounterpartShortname varchar(50)
      , clearingBrokerShortname     varchar(50)
      , centralCounterpartShortname varchar(50)
      , executingBrokerShortname    varchar(50)
      , PRIMARY KEY CLUSTERED (_contract_ID, _contractType_ID)
)
AS
BEGIN
    DECLARE @loadContextID int = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)
    
    DECLARE @ID TABLE (ID int NOT NULL PRIMARY KEY CLUSTERED);
    INSERT INTO @ID (ID)
    SELECT ContractNode.value('@ID[1]', 'INT')
    FROM @contractIDs.nodes('/row') T1(ContractNode)
    WHERE @contractIDs IS NOT NULL
    UNION ALL
    SELECT ID
    FROM DWH.contract C
    WHERE 
      C.reportDate = @reportDate 
      AND C._loadContext_ID = @loadContextID
      AND @contractIDs IS NULL;
    
    
    DECLARE @cpc TABLE (_contract_ID int, _contractType_id int, _counterpart_ID int, shortname varchar(50), rolename varchar(100), 
      PRIMARY KEY CLUSTERED (_contract_ID, _contractType_ID, _counterpart_ID, roleName))

    INSERT INTO @cpc
     SELECT 
        CPC._contract_id,
        CPC._contractType_ID,
        CPC._counterPart_ID,
        CTP.shortname,
        CPR.roleName
     FROM DWH.counterPartContract CPC
     INNER JOIN @ID ID ON CPC._contract_ID = ID.ID
     INNER JOIN DWH.LKP_counterPartRole CPR on CPC._counterPartRole_ID = CPR.ID
     INNER JOIN DWH.contract C ON CPC._contract_ID = C.ID
     INNER JOIN DWH.counterpart CTP ON CPC._counterPart_ID = CTP.ID
     WHERE C.reportDate = @reportDate
         AND C._loadContext_ID = @loadContextID
         AND CTP.reportDate = @reportDate
         AND CTP._loadContext_ID = @loadContextID

    INSERT INTO @contractCounterparts
    SELECT  ID._contract_ID, ID._contractType_ID,
            ID.Obligor, 
            ID.Issuer, 
            ID.Guarantor, 
            ID.ContractCounterPart, 
            ID.RiskCounterPart, 
            ID.CreditCoveredCounterpart, 
            ID.Broker, 
            ID.Agent, 
            ID.Distributor, 
            ID.BondLeadManager1, 
            ID.BondLeadManager2, 
            ID.BondLeadManager3, 
            ID.BondLeadManager4, 
            ID.Clearer, 
            ID.Buyer, 
            ID.Exchange, 
            ID.Seller, 
            ID.Exporter, 
            ID.Borrower, 
            ID.Lender, 
            ID.SwapCounterpart,
            ID.FeeCounterpart,
            ID.ClearingBroker,
            ID.CentralCounterpart,
            ID.ExecutingBroker,
            SN.obligor AS obligorShortname,
            SN.issuer AS issuerShortname,
            SN.guarantor AS guarantorShortname,
            SN.contractCounterpart AS contractCounterpartShortname,
            SN.CreditCoveredCounterpart AS creditCoveredCounterpartShortname,
            SN.ClearingBroker,
            SN.CentralCounterpart,
            SN.ExecutingBroker
    FROM 
    (
        SELECT
       _contract_ID,
       _contractType_ID,
       Obligor, 
       Issuer, 
       Guarantor, 
       ContractCounterPart, 
       RiskCounterPart, 
       CreditCoveredCounterpart, 
       Broker, 
       Agent, 
       Distributor, 
       BondLeadManager1, 
       BondLeadManager2, 
       BondLeadManager3, 
       BondLeadManager4, 
       Clearer, 
       Buyer, 
       Exchange, 
       Seller, 
       Exporter, 
       Borrower, 
       Lender, 
       SwapCounterpart,
       FeeCounterpart,
       ClearingBroker,
       CentralCounterpart,
       ExecutingBroker
   
       FROM ( SELECT _contract_id, _contractType_ID, _counterPart_ID, roleName FROM @cpc ) AA
       PIVOT
       (
          MIN(_counterPart_ID)
          FOR roleName IN
          (Obligor, Issuer, Guarantor, ContractCounterPart, RiskCounterPart, CreditCoveredCounterpart, 
           Broker, Agent, Distributor, BondLeadManager1, BondLeadManager2, BondLeadManager3, BondLeadManager4, 
           Clearer, Buyer, Exchange, Seller, Exporter, Borrower, Lender, SwapCounterpart, FeeCounterpart,
           ClearingBroker, CentralCounterpart, ExecutingBroker)
       ) AS pvt
    ) ID

    LEFT JOIN (
       SELECT
          _contract_ID,
          _contractType_ID,
          Obligor, 
          Issuer, 
          Guarantor, 
          ContractCounterPart, 
          RiskCounterPart, 
          CreditCoveredCounterpart, 
          Broker, 
          Agent, 
          Distributor, 
          BondLeadManager1, 
          BondLeadManager2, 
          BondLeadManager3, 
          BondLeadManager4, 
          Clearer, 
          Buyer, 
          Exchange, 
          Seller, 
          Exporter, 
          Borrower, 
          Lender, 
          SwapCounterpart,
          FeeCounterpart,
          ClearingBroker,
          CentralCounterpart,
          ExecutingBroker
       FROM ( SELECT _contract_id, _contractType_ID, shortname, roleName FROM @cpc ) BB
       PIVOT
       (
          MIN(shortname)
          FOR roleName IN
          (Obligor, Issuer, Guarantor, ContractCounterPart, RiskCounterPart, CreditCoveredCounterpart, 
           Broker, Agent, Distributor, BondLeadManager1, BondLeadManager2, BondLeadManager3, BondLeadManager4, 
           Clearer, Buyer, Exchange, Seller, Exporter, Borrower, Lender, SwapCounterpart, FeeCounterpart,
           ClearingBroker, CentralCounterpart, ExecutingBroker)
       ) AS pvt
    ) SN ON ID._contract_ID = SN._contract_ID AND ID._contractType_ID = SN._contractType_ID

    RETURN
END
GO