--liquibase formatted sql

--changeSet func:Initial-PF-fnContractViewProFinance-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('PF.fnContractViewProFinance', 'TF') IS NULL EXEC('CREATE FUNCTION [PF].[fnContractViewProFinance](@reportDate date,@extractContext varchar(3)) RETURNS @tab TABLE ([id] int,[value_date] date,[expt_id] varchar(25),[contractno] varchar(15),[asset_or_liability] varchar(1),[book_currency] varchar(3),[coupon_currency] varchar(3),[currency] varchar(3),[nominal_currency_orig] varchar(3),[nominal_currency_out] varchar(3),[principal_currency_orig] varchar(3),[principal_currency_out] varchar(3),[product_type] varchar(10),[package_id] varchar(15),[date] datetime,[start_date] datetime,[maturity_date] datetime,[value] numeric(28,8),[portfolio] varchar(10),[book_value] numeric(28,8),[coupon_rate] numeric(28,8),[coupon_spread] numeric(28,8),[next_coupon_date] datetime,[next_fixing_date] datetime,[first_coupon_date] datetime,[coupon_type] varchar(10),[coupon_frequency] varchar(10),[coupon_base_curve] varchar(30),[principal_amount_orig] numeric(28,8),[principal_amount_out] numeric(28,8),[nominal_amount_orig] numeric(28,8),[nominal_amount_out] numeric(28,8),[extern_all_in] numeric(28,8),[total_margin] numeric(28,8),[load_date] datetime,[IMPORT_source] int,[IMPORT_id] int,[IMPORT_transaction_id] int,[trade_date] datetime,[allocation] varchar(45),[obligor_ref] int,[issuer_ref] int,[drawdown_end_date] datetime,[currCoupDate] datetime,[currCoupType] varchar(10),[nextCoupDate] datetime,[nextCoupType] varchar(10),[revolving_reducing] varchar(2),[package_type] varchar(15),[external_valuation] bit,[transactionType] varchar(4),[exposure_type] varchar(15),[statusCode] varchar(3),[extractContext] varchar(3),[contractStatus] varchar(15),[sekContractStatusLevel1] varchar(10),[sekContractStatusLevel2] varchar(30),[PaidSupplier] money,[FutureValue] money) AS BEGIN RETURN END')
GO



--changeSet func:Initial-PF-fnContractViewProFinance-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [PF].[fnContractViewProFinance]
(
   @reportDate      DATE,
   @extractContext VARCHAR(3)
)
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : PF.fnContractViewProFinance
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate             DATE
  -- !                       @extractContext         VARCHAR(3)
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with contracts from ProFinance the given date. 
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s      :
  -- !                select * from PF.fnContractViewProFinance('2010-09-20', 'EOD');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-09-29 JOJO  Initial version
  -- !                       2010-11-26 JOJO  Added Project4 filtering
  -- !                       2010-11-26 JOJO  Added [DWH].[LKP_ProFinanceContractPortfolio] to DWH_BASE
  -- !                       2010-11-30 DAHJ  Added StatusCode to output.
  -- !                       2010-11-30 DAHJ  Added contractStatus, sekContractStatusLevel1 and sekContractStatusLevel2
  -- !                       2010-12-14 DAHJ  Changed sekContractStatusLevel2 to varchar(30)
  -- !                       2011-01-26 CHTH  Removed data fetch
  -- !                       2012-01-13 JoJo  Added split from SC10784
  -- !                       2012-01-30 JoJo  Made loading backwards compatible. Old logic pre 2011-12-31, new otherwise.
  -- !                       2012-04-30 MaSo  Added extern_all_in and total_margin to output
  -- !                       2014-02-25 AnOh  INC0010915 
  -- !                       2014-11-24 ChTh  CHG0011609 - Fix av profinance kontrakt intradag 5-dagars
  -- +----------------------------------------------------------------------------------------------------------------
RETURNS @proFinanceContract TABLE
(
   [id] [int] IDENTITY(1, 1) NOT NULL,
   [value_date] [date] NOT NULL,
   [expt_id] [varchar](25) NOT NULL,
   [contractno] [varchar](15) NOT NULL,
   [asset_or_liability] [varchar](1) NOT NULL,
   [book_currency] [varchar](3) NULL,
   [coupon_currency] [varchar](3) NULL,
   [currency] [varchar](3) NULL,
   [nominal_currency_orig] [varchar](3) NULL,
   [nominal_currency_out] [varchar](3) NULL,
   [principal_currency_orig] [varchar](3) NULL,
   [principal_currency_out] [varchar](3) NULL,
   [product_type] [varchar](10) NULL,
   [package_id] [varchar](15) NULL,
   [date] [datetime] NOT NULL,
   [start_date] [datetime] NOT NULL,
   [maturity_date] [datetime] NULL,
   [value] [numeric](28, 8) NULL,
   [portfolio] [varchar](10) NULL,
   [book_value] [numeric](28, 8) NULL,
   [coupon_rate] [numeric](28, 8) NULL,
   [coupon_spread] [numeric](28, 8) NULL,
   [next_coupon_date] [datetime] NULL,
   [next_fixing_date] [datetime] NULL,
   [first_coupon_date] [datetime] NULL,
   [coupon_type] [varchar](10) NULL,
   [coupon_frequency] [varchar](10) NULL,
   [coupon_base_curve] [varchar](30) NULL,
   [principal_amount_orig] [numeric](28, 8) NULL,
   [principal_amount_out] [numeric](28, 8) NULL,
   [nominal_amount_orig] [numeric](28, 8) NULL,
   [nominal_amount_out] [numeric](28, 8) NULL,
   [extern_all_in] [numeric](28, 8) NULL,
   [total_margin] [numeric](28, 8) NULL,
   [load_date] [datetime] NOT NULL,
   [IMPORT_source] [int] NOT NULL,
   [IMPORT_id] [int] NOT NULL,
   [IMPORT_transaction_id] [int] NOT NULL,
   [trade_date] [datetime] NULL,
   [allocation] [varchar](45) NULL,
   [obligor_ref] [int] NULL,
   [issuer_ref] [int] NULL,
   [drawdown_end_date] [datetime] NULL,
   [currCoupDate] [datetime] NULL,
   [currCoupType] [varchar](10) NULL,
   [nextCoupDate] [datetime] NULL,
   [nextCoupType] [varchar](10) NULL,
   [revolving_reducing] [varchar](2) NULL,
   [package_type] [varchar](15) NULL,
   [external_valuation] [bit] NULL,
   [transactionType] [varchar](4) NULL,
   [exposure_type] [varchar](15) NULL,
   [statusCode]    [varchar] (3) NULL,
   [extractContext] [varchar](3) NOT NULL,
   [contractStatus] [varchar](15) NULL,
   [sekContractStatusLevel1] [varchar](10) NULL,
   [sekContractStatusLevel2] [varchar](30) NULL,
   [PaidSupplier] [money] NULL,
   [FutureValue] [money] NULL
)
AS
BEGIN

   IF DATEDIFF(d, @reportDate, '2011-12-31') >= 0
   BEGIN
      INSERT INTO @proFinanceContract(value_date, expt_id, contractno, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out,
               principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
               coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
               principal_amount_orig, principal_amount_out, nominal_amount_orig, nominal_amount_out, extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id,
               IMPORT_transaction_id, trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType,
               revolving_reducing,   package_type, external_valuation, transactionType, exposure_type, statusCode, extractContext, contractStatus, sekContractStatusLevel1,
               sekContractStatusLevel2, PaidSupplier, FutureValue)
      SELECT value_date, 'Disbursed' AS expt_id, contractno, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out,
               principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
               coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
               principal_amount_orig, principal_amount_out, nominal_amount_orig, nominal_amount_out, extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id,
               IMPORT_transaction_id, trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType,
               revolving_reducing, package_type, external_valuation, transactionType, exposure_type, statusCode, extractContext, contractStatus, sekContractStatusLevel1,
               sekContractStatusLevel2, NULL AS PaidSupplier, NULL AS FutureValue
        FROM [PF].[fnContractViewProFinancePre20111231](@reportDate, @extractContext);

      RETURN;
   END;

    DECLARE @reportDateEOD date = (SELECT CASE WHEN @extractContext = 'SOD' THEN DWH_TOOLKIT.DWH.getPreviousBusinessDay(@reportDate) ELSE @reportDate END)
   DECLARE @exportDateTime      DATETIME;

   SELECT @exportDateTime = MAX(ExportDate) 
     FROM DWH_HISTORY.DWH.PF_ExportedExposure 
    WHERE CAST(FLOOR(CAST(ExportDate AS FLOAT)) AS DATETIME) = @reportDateEOD;
   
   DECLARE @pf_exposure_load TABLE
   (
      [ExportDate] [datetime] NULL,
      [Contract] [varchar](15) NULL,
      [ContractNo] [varchar](15) NULL,
      [ContractLine] [varchar](4) NULL,
      [Portfolio] [varchar](10) NULL,
      [LeasingHirePurchase] [smallint] NULL,
      [BookValueCurrencyCode] [varchar](3) NULL,
      [ValueCurrencyCode] [varchar](3) NULL,
      [ContractType] [varchar](10) NULL,
      [PackageId] [varchar](15) NULL,
      [StartDate] [datetime] NULL,
      [EndDate] [datetime] NULL,
      [Value] [numeric](28, 8) NULL,
      [BookValue] [numeric](28, 8) NULL,
      [InterestRate] [numeric](28, 8) NULL,
      [InterestMargin] [numeric](28, 8) NULL,
      [NextDueDate] [datetime] NULL,
      [FirstDueDate] [datetime] NULL,
      [CouponType] [varchar](1) NULL,
      [InterestPeriodMonths] [varchar](10) NULL,
      [InterestTypeDescription] [varchar](30) NULL,
      [PrincipalAmountOrig] [numeric](28, 8) NULL,
      [PrincipalAmountOut] [numeric](28, 8) NULL,
      [NominalAmountOrig] [numeric](28, 8) NULL,
      [NominalAmountOut] [numeric](28, 8) NULL,
      [ExternAllIn] [numeric](28, 8) NULL,
      [TotalMargin] [numeric](28, 8) NULL,
      [Extract_Date] [datetime] NULL,
      [IMPORT_source] [int] NULL,
      [IMPORT_id] [int] NULL,
      [IMPORT_transaction_id] [int] NULL,
      [RegistrationDate] [datetime] NULL,
      [Supplier] [int] NULL,
      [Customer] [int] NULL,
      [FinalEndDate] [datetime] NULL,
      [Revolving] [varchar](2) NULL,
      [SkeletonAgreementIdentity] [varchar](15) NULL,
      [ExposureType] [varchar](20) NULL,
      [StatusCode] [varchar] (3) NULL,
      [ReportDate] [datetime] NULL,
      [LoadExtractDate] [datetime] NULL,
      [PaidSupplier] [money] NULL,
      [FutureValue] [money] NULL
   )
    
   -- Hämta kontrakten
   INSERT INTO @pf_exposure_load
   SELECT ee.ExportDate,
         ee.[Contract],
         ee.[Contract] ContractNo,
         ee.ContractLine,
         CAST('CUSTFIN' AS VARCHAR(10)) Portfolio,
         ee.LeasingHirePurchase,
         ee.BookValueCurrencyCode,
         ee.ValueCurrencyCode,
         ee.ContractType,
         ee.SkeletonAgreement PackageId,
         ee.StartDate,
         ee.EndDate,
         ee.Value,
         ee.BookValue,
         ee.InterestRate,
         ee.InterestMargin,
         ee.NextDueDate,
         ee.FirstDueDate,
         CASE ee.ChangeType WHEN 0 THEN 'F' WHEN 1 THEN 'V' ELSE NULL END CouponType, 
         ee.InterestPeriodMonths,
         ee.InterestTypeDescription,
         ee.OriginalValue PrincipalAmountOrig,
         ee.PresentValue PrincipalAmountOut,
         ee.OriginalValue NominalAmountOrig,
         ee.PresentValue NominalAmountOut,
         CONVERT(numeric(28,8),NULLIF(CASE WHEN ee.text2 LIKE '%[^-0123456789.,]%' THEN NULL ELSE REPLACE(ee.text2,',','.') END,'')) AS ExternAllIn,
         CONVERT(numeric(28,8),NULLIF(CASE WHEN ee.text3 LIKE '%[^-0123456789.,]%' THEN NULL ELSE REPLACE(ee.text3,',','.') END,'')) AS TotalMargin,
         ee.Extract_Date,
         3 IMPORT_source,
         0 IMPORT_id,
         0 IMPORT_transaction_id, 
         ee.RegistrationDate,
         ee.Supplier,
         ee.Customer,
         ee.FinalEndDate,
         ee.Revolving, 
         ee.SkeletonAgreementIdentity,
         ee.ExposureType,
         ee.StatusCode,
         ee.ReportDate ReportDate,
         CONVERT(date, GETDATE()) LoadExtractDate,
         ee.PaidSupplier,
         ee.FutureValue
     FROM DWH_HISTORY.DWH.PF_ExportedExposure ee
      INNER JOIN DWH.LKP_ProFinanceContractStatusCodeImport lkp ON COALESCE(ee.StatusCode, CASE
                                                                        WHEN ee.ExposureType = 'ContractLine' THEN '10' 
                                                                        WHEN ee.ExposureType = 'ProFront' THEN '60.'
                                                                      END) = lkp.StatusCode 
                                                 AND ee.ExposureType = lkp.ExposureType
                                                 AND lkp.Import = 1
    WHERE ee.ExportDate = @exportDateTime
      AND CAST(FLOOR(CAST(ee.ExportDate AS FLOAT)) AS DATETIME) BETWEEN lkp.ValidFrom AND lkp.ValidTo
      AND [Contract] NOT IN ('5000101-1')
   
   DECLARE @pf_amortization_load TABLE
   (
      [Portfolio] [varchar](12) NULL,
      [Contract] [varchar](12) NULL,
      [ContractLine] [varchar](4) NULL,
      [Period] [smallint] NULL,
      [StartDate] [datetime] NULL,
      [EndDate] [datetime] NULL,
      [DueDate] [datetime] NULL,
      [DebitDate] [datetime] NULL,
      [Amortization] [money] NULL,
      [Interest] [money] NULL,
      [OtherInterest] [money] NULL,
      [Charges] [money] NULL,
      [ExtraLines] [money] NULL,
      [AddedServices] [money] NULL,
      [InvoiceFee] [money] NULL,
      [TotalAmount] [money] NULL,
      [PresentValue] [money] NULL,
      [InterestAcc] [money] NULL,
      [AmortizationAcc] [money] NULL,
      [PresentValueFA] [money] NULL,
      [Depreciation] [money] NULL,
      [DepreciationAcc] [money] NULL,
      [ExtensionPeriod] [smallint] NULL,
      [ReadingDate] [datetime] NULL,
      [Split] [money] NULL,
      [Extract_Date] [datetime] NULL,
      [IMPORT_source] [int] NULL,
      [IMPORT_id] [int] NULL,
      [IMPORT_transaction_id] [int] NULL,
      [ExportDate] [datetime] NULL,
      [LoadExtractDate] [datetime] NULL
   )

   -- Hämta amorteringar
   INSERT INTO @pf_amortization_load
   SELECT Portfolio, 
         [Contract], 
         ContractLine, 
         Period, 
         StartDate, 
         EndDate, 
         DueDate, 
         DebitDate, 
         Amortization, 
         Interest, 
         OtherInterest, 
         Charges, 
         ExtraLines, 
         AddedServices, 
         InvoiceFee, 
         TotalAmount, 
         PresentValue, 
         InterestAcc, 
         AmortizationAcc, 
         PresentValueFA, 
         Depreciation, 
         DepreciationAcc, 
         ExtensionPeriod, 
         ReadingDate, 
         Split, 
         Extract_Date,             
         3 IMPORT_source,         
         0 IMPORT_id,                     
         0 IMPORT_transaction_id, 
         ExportDate,    
         CONVERT(date, GETDATE()) LoadExtractDate
     FROM DWH_HISTORY.DWH.PF_ExportedAmortization
    WHERE ExportDate = @exportDateTime
      AND [Contract] <> '5000101-1'
      AND [Contract] IN (SELECT [Contract] FROM @pf_exposure_load);
   
   UPDATE @pf_exposure_load
      SET ContractNo = LTRIM(RTRIM(ContractNo)),
         ContractLine = LTRIM(RTRIM(ContractLine)),
         Revolving = LTRIM(RTRIM(ISNULL(Revolving, '0'))),
         ExposureType = LTRIM(RTRIM(ExposureType)),
         StatusCode = LTRIM(RTRIM(StatusCode)), 
         PackageId = LTRIM(RTRIM(PackageId))
         
   UPDATE e
      SET e.PrincipalAmountOut = ISNULL(e.PrincipalAmountOut, 0),
         e.NominalAmountOut     = ISNULL(e.PrincipalAmountOut, 0)
     FROM @pf_exposure_load e
    WHERE e.ExposureType IN ('FrameAgreement') --SC10784, 'ProFront')
    
   UPDATE e
      SET e.PrincipalAmountOut = 
         CASE 
            -- Om det finns en amorteringspost med DueDate före dagens datum (laddningsdatum)
            --START SC10784
            WHEN EXISTS(SELECT 1
                       FROM @pf_amortization_load a 
                      WHERE LTRIM(RTRIM(a.[Contract])) = e.[Contract] 
                        AND LTRIM(RTRIM(a.ContractLine)) = e.contractline 
                        AND a.IMPORT_id = e.IMPORT_id
                        AND CAST(FLOOR(CAST(a.DueDate AS FLOAT)) AS DATETIME) > CAST(FLOOR(CAST(e.ExportDate AS FLOAT)) AS DATETIME)) 
                        /*AND e.exposure_type = 'ContractLine'*/ THEN
                  (SELECT MAX(a.PresentValue) + MAX(a.Amortization)
                     FROM @pf_amortization_load a
                    WHERE LTRIM(RTRIM(a.[Contract])) = e.[Contract]
                     AND LTRIM(RTRIM(a.ContractLine)) = e.contractline
                     AND a.IMPORT_id = e.IMPORT_id
                     AND CAST(FLOOR(CAST(a.DueDate AS FLOAT)) AS DATETIME)
                               = (SELECT MIN(CAST(FLOOR(CAST(aa.DueDate AS FLOAT)) AS DATETIME))
                                   FROM @pf_amortization_load aa
                                  WHERE LTRIM(RTRIM(aa.[Contract])) = e.[Contract]
                                    AND LTRIM(RTRIM(aa.ContractLine)) = e.contractline
                                    AND aa.IMPORT_id = e.IMPORT_id
                                    AND CAST(FLOOR(CAST(aa.DueDate AS FLOAT)) AS DATETIME) > CAST(FLOOR(CAST(e.ExportDate AS FLOAT)) AS DATETIME)))
/*
            WHEN EXISTS(SELECT 1
                       FROM @pf_amortization_load a 
                      WHERE LTRIM(RTRIM(a.[Contract])) = e.[Contract] 
                        AND LTRIM(RTRIM(a.ContractLine)) = e.contractline 
                        AND a.IMPORT_id = e.IMPORT_id
                        AND CAST(FLOOR(CAST(a.DueDate AS FLOAT)) AS DATETIME) <= CAST(FLOOR(CAST(e.ExportDate AS FLOAT)) AS DATETIME)) THEN
                  (SELECT MAX(a.PresentValue)
                     FROM @pf_amortization_load a
                    WHERE LTRIM(RTRIM(a.[Contract])) = e.[Contract]
                      AND LTRIM(RTRIM(a.ContractLine)) = e.contractline
                      AND a.IMPORT_id = e.IMPORT_id
                      AND CAST(FLOOR(CAST(a.DueDate AS FLOAT)) AS DATETIME)
                               = (SELECT MAX(CAST(FLOOR(CAST(aa.DueDate AS FLOAT)) AS DATETIME))
                                   FROM @pf_amortization_load aa
                                  WHERE LTRIM(RTRIM(aa.[Contract])) = e.[Contract]
                                    AND LTRIM(RTRIM(aa.ContractLine)) = e.contractline
                                    AND aa.IMPORT_id = e.IMPORT_id
                                    AND CAST(FLOOR(CAST(aa.DueDate AS FLOAT)) AS DATETIME) <= CAST(FLOOR(CAST(e.ExportDate AS FLOAT)) AS DATETIME)))
*/
            --SLUT SC10784
            ELSE
               e.PrincipalAmountOut -- Samma som EE.PresentValue
            END
     FROM @pf_exposure_load e
    WHERE e.ExposureType IN ('ContractLine', 'ProFront') --SC10784
   
    --
   UPDATE @pf_exposure_load
      SET contractno = 'FRAME' + PackageId,
         FinalEndDate = EndDate,
         ContractType = 'FRAME'
    WHERE ExposureType = 'FrameAgreement'
    
   UPDATE @pf_exposure_load
      SET contractno = contractno + REPLICATE('0', 4 - LEN(contractline)) + contractline,
         FinalEndDate = NULL
    WHERE ExposureType IN ('ContractLine', 'ProFront')
    
   UPDATE @pf_exposure_load
      SET PackageId = CASE ExposureType
                     WHEN 'FrameAgreement' THEN 'N/A'
                     WHEN 'ContractLine' THEN [contract]
                     WHEN 'ProFront' THEN [contract]
                  END,
         Revolving = CASE Revolving WHEN '1' THEN 'RV' ELSE 'RD' END,
         BookValue = CASE ExposureType
                     WHEN 'FrameAgreement' THEN 0
                     WHEN 'ContractLine' THEN BookValue
                     WHEN 'ProFront' THEN 0
                  END,
         Value = NULL
   --
   --
   UPDATE @pf_exposure_load
      SET Portfolio = p.Portfolio
    FROM @pf_exposure_load e
      INNER JOIN [DWH].[LKP_ProFinanceContractPortfolio] p ON p.[Contract] = 'DEFAULT'
   WHERE e.ExportDate BETWEEN p.ValidFrom AND p.ValidTo
      
   UPDATE @pf_exposure_load
      SET Portfolio = p.Portfolio
    FROM @pf_exposure_load e
      INNER JOIN [DWH].[LKP_ProFinanceContractPortfolio] p ON e.[contract] = p.[Contract]
   WHERE e.ExportDate BETWEEN p.ValidFrom AND p.ValidTo
   --
   --*******************
   -- Här börjar sektionen där kupongdatum räknas fram
   DECLARE @temp_exposure TABLE([Contract] VARCHAR(15) NULL, 
                         ContractLine VARCHAR(4) NULL,
                         coupon_type VARCHAR(10) NULL,
                         next_fixing_date DATETIME NULL,
                         currCoupDate DATETIME NULL,
                         next_coupon_date DATETIME NULL,
                         nextCoupDate DATETIME NULL,
                         coupon_rate NUMERIC(28, 8) NULL)
                         
   INSERT INTO @temp_exposure([Contract], ContractLine, coupon_type, next_fixing_date, currCoupDate, next_coupon_date, nextCoupDate, coupon_rate)
   SELECT [Contract], ContractLine, CouponType, NULL, NULL, NULL, NULL, InterestRate
     FROM @pf_exposure_load

   --   
   -- Skapa tabeller med nyckeldatum
   DECLARE @temp_exposure_dates TABLE([Contract] VARCHAR(15) NULL, 
                              ContractLine VARCHAR(4) NULL,
                              MinReadingDate DATETIME NULL,
                              MaxReadingDate DATETIME NULL,
                              load_date DATETIME NULL,
                              NearestReadingDateload_date DATETIME NULL,
                              NearestReadingDateStartDate DATETIME NULL,
                              NearestReadingDateDueDate DATETIME NULL,
                              NearestReadingDateDueDateEQ DATETIME NULL,
                              FixingStart DATETIME NULL,
                              FixingEnd DATETIME NULL,
                              FixingStartGT DATETIME NULL,
                              FixingReadGT DATETIME NULL,
                              StartDateReadingDateLTExtractDate DATETIME NULL,
                              MaxReadStart DATETIME NULL)
                              
   INSERT INTO @temp_exposure_dates([Contract], ContractLine, MinReadingDate, MaxReadingDate, 
                                    load_date, NearestReadingDateload_date, NearestReadingDateStartDate,
                                    NearestReadingDateDueDate, NearestReadingDateDueDateEQ,
                                    FixingStart, FixingEnd, FixingStartGT, FixingReadGT, StartDateReadingDateLTExtractDate,
                                    MaxReadStart)
   SELECT [contract], [contractline],
         (SELECT MIN(a.ReadingDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS MinReadingDate,
         (SELECT MAX(a.ReadingDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS MaxReadingDate,
         (SELECT MIN(a.Extract_Date)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS load_date,
         (SELECT MAX(a.Extract_Date)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
            AND a.ReadingDate = (SELECT MAX(a2.ReadingDate) 
                              FROM @pf_amortization_load a2
                             WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
                              AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
                              AND a2.ReadingDate < a2.Extract_Date)) AS NearestReadingDateload_date, 
         (SELECT MAX(a.ReadingDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
            AND a.ReadingDate = (SELECT MAX(a2.ReadingDate) 
                              FROM @pf_amortization_load a2
                             WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
                              AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
                              AND a2.ReadingDate < a2.Extract_Date)) AS NearestReadingDateStartDate, 
         (SELECT MAX(a.DueDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
            AND a.ReadingDate = (SELECT MAX(a2.ReadingDate) 
                              FROM @pf_amortization_load a2
                             WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
                              AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
                              AND a2.ReadingDate < a2.Extract_Date)) AS NearestReadingDateDueDate, 
         (SELECT MAX(a.DueDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
            AND a.ReadingDate = (SELECT MIN(a2.ReadingDate) 
                              FROM @pf_amortization_load a2
                             WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
                              AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
                              AND a2.ReadingDate >= a2.Extract_Date)) AS NearestReadingDateDueDateEQ,
         (SELECT MIN(ISNULL(a.ReadingDate, a.StartDate))
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS FixingStart,
         (SELECT MAX(ISNULL(a.ReadingDate, a.StartDate))
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS FixingEnd,
         (SELECT MIN(a2.StartDate)
            FROM @pf_amortization_load a2
           WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
            AND a2.StartDate > a2.Extract_Date) AS FixingStartGT,
         (SELECT MIN(a2.ReadingDate)
            FROM @pf_amortization_load a2
           WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
            AND a2.ReadingDate > a2.Extract_Date) AS FixingReadGT,
         (SELECT MIN(a.StartDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
            AND a.ReadingDate = (SELECT MAX(a2.ReadingDate)
                              FROM @pf_amortization_load a2
                             WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
                              AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
                              AND a2.ReadingDate < a2.Extract_Date)) AS StartDateReadingDateLTExtractDate,
         (SELECT MAX(ISNULL(a.ReadingDate, a.StartDate))
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS MaxReadStart
     FROM @temp_exposure te
   
   DECLARE @temp_exposure_start TABLE([Contract] VARCHAR(15) NULL, 
                              ContractLine VARCHAR(4) NULL,
                              StartDate DATETIME NULL,
                              EndDate DATETIME NULL,
                              DueDate DATETIME NULL,
                              MaxDueDate DATETIME NULL)

   INSERT INTO @temp_exposure_start([Contract], ContractLine, StartDate, EndDate, DueDate, MaxDueDate)
   SELECT [contract], [contractline],
         (SELECT MIN(a.StartDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS StartDate,
         (SELECT MIN(a.EndDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS EndDate,
         (SELECT MIN(a.DueDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS DueDate,
         (SELECT MAX(a.DueDate)
           FROM @pf_amortization_load a
          WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
            AND LTRIM(RTRIM(a.ContractLine)) = te.contractline) AS MaxDueDate
     FROM @temp_exposure te
   
   --ChangeType (coupon_type) = 0
   UPDATE @temp_exposure
      SET next_coupon_date = CASE 
                        WHEN ted.load_date < tes.DueDate THEN
                           tes.DueDate
                        ELSE ISNULL((SELECT MIN(a.DueDate)
                                    FROM @pf_amortization_load a
                                    WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
                                     AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
                                     AND a.DueDate > a.Extract_Date), 
                                 (SELECT MAX(a.EndDate)
                                    FROM @pf_amortization_load a
                                    WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
                                     AND LTRIM(RTRIM(a.ContractLine)) = te.contractline))
                       END
         
     FROM @temp_exposure te
      INNER JOIN @temp_exposure_start tes ON te.[Contract] = tes.[Contract] AND te.contractline = tes.contractline
      INNER JOIN @temp_exposure_dates ted ON te.[Contract] = ted.[Contract] AND te.contractline = ted.contractline
    WHERE te.coupon_type = 'F'
    
     UPDATE @temp_exposure
      SET next_fixing_date = NULL
     FROM @temp_exposure te
      INNER JOIN @temp_exposure_start tes ON te.[Contract] = tes.[Contract] AND te.contractline = tes.contractline
    WHERE te.coupon_type = 'F'
    
   --ChangeType (coupon_type) = 1
   UPDATE @temp_exposure
      SET next_coupon_date = 
            CASE 
               WHEN tes.DueDate = tes.EndDate THEN
                  CASE 
                     WHEN ISNULL(ted.MinReadingDate, tes.StartDate) >= ted.load_date THEN
                        tes.DueDate
                     WHEN ted.MaxReadStart > ted.load_date THEN
                        (SELECT MIN(a1.DueDate)
                           FROM @pf_amortization_load a1
                          WHERE LTRIM(RTRIM(a1.[Contract])) = te.[Contract] -- LIKE  + '%' 
                           AND LTRIM(RTRIM(a1.ContractLine)) = te.contractline
                           AND ISNULL(a1.ReadingDate, a1.StartDate)
                                          = (SELECT MAX(ISNULL(a2.ReadingDate, a2.StartDate))
                                             FROM @pf_amortization_load a2
                                             WHERE LTRIM(RTRIM(a2.[Contract])) = te.[Contract] -- LIKE  + '%' 
                                              AND LTRIM(RTRIM(a2.ContractLine)) = te.contractline
                                              AND ISNULL(a2.ReadingDate, a2.StartDate) < a2.Extract_Date))
                     ELSE
                        tes.MaxDueDate -- Nytt fall
                  END
               ELSE --WHEN tes.DueDate = tes.StartDate THEN
                  CASE 
                     WHEN ted.MinReadingDate >= ted.load_date THEN
                        tes.DueDate
                     WHEN ted.load_date < ted.StartDateReadingDateLTExtractDate THEN
                        ted.NearestReadingDateDueDate
                     ELSE
                        ted.NearestReadingDateDueDateEQ
                  END
            END,
        coupon_rate = 
            CASE 
               WHEN tes.DueDate = tes.EndDate THEN
                  te.coupon_rate
               WHEN tes.DueDate = tes.StartDate THEN
                  CASE 
                     WHEN ted.MinReadingDate >= ted.load_date THEN
                        te.coupon_rate
                     WHEN ted.load_date < ted.StartDateReadingDateLTExtractDate THEN
                        te.coupon_rate
                     ELSE
                        0
                  END
            END
     FROM @temp_exposure te
      INNER JOIN @temp_exposure_start tes ON te.[Contract] = tes.[Contract] AND te.contractline = tes.contractline
      INNER JOIN @temp_exposure_dates ted ON te.[Contract] = ted.[Contract] AND te.contractline = ted.contractline
    WHERE te.coupon_type = 'V'

   UPDATE @temp_exposure
      SET next_fixing_date = CASE
                        WHEN ted.FixingStart > ted.load_date THEN
                           ted.FixingStart
                        WHEN ted.FixingEnd <= ted.load_date THEN
                           ted.FixingEnd
                        ELSE
                           CASE
                              WHEN ted.MinReadingDate IS NULL THEN
                                 ted.FixingStartGT
                              ELSE
                                 ted.FixingReadGT
                           END
                        END
     FROM @temp_exposure te
      INNER JOIN @temp_exposure_dates ted ON te.[Contract] = ted.[Contract] AND te.contractline = ted.contractline
    WHERE te.coupon_type = 'V'

   UPDATE @temp_exposure
      SET currCoupDate = (SELECT MIN(a.DueDate) 
                             FROM @pf_amortization_load a
                            WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract]  -- LIKE  + '%' 
                              AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
                              AND a.DueDate > a.Extract_Date),
           nextCoupDate = (SELECT MIN(a.DueDate) 
                             FROM @pf_amortization_load a
                            WHERE LTRIM(RTRIM(a.[Contract])) = te.[Contract] -- LIKE  + '%' 
                              AND LTRIM(RTRIM(a.ContractLine)) = te.contractline
                              AND a.DueDate > te.next_coupon_date)
     FROM @temp_exposure te
      INNER JOIN @temp_exposure_dates ted ON te.[Contract] = ted.[Contract] AND te.contractline = ted.contractline

   DELETE @pf_exposure_load WHERE ExposureType = 'FrameAgreement'

   --*******************
   INSERT INTO @proFinanceContract(
         value_date,
         expt_id,
         contractno,
         asset_or_liability,
         book_currency,
         coupon_currency,
         currency,
         nominal_currency_orig,
         nominal_currency_out,
         principal_currency_orig,
         principal_currency_out,
         product_type,
         package_id,
         [date],
         [start_date],
         maturity_date,
         value,
         portfolio,
         book_value,
         coupon_rate,
         coupon_spread,
         next_coupon_date,
         next_fixing_date,
         first_coupon_date,
         coupon_type,
         coupon_frequency,
         coupon_base_curve,
         principal_amount_orig,
         principal_amount_out,
         nominal_amount_orig,
         nominal_amount_out,
         extern_all_in,
         total_margin,
         load_date,
         IMPORT_source,
         IMPORT_id,
         IMPORT_transaction_id,
         trade_date,
         allocation,
         obligor_ref,
         issuer_ref,
         drawdown_end_date,
         currCoupDate,
         currCoupType,
         nextCoupDate,
         nextCoupType,
         revolving_reducing,
         package_type,
         external_valuation,
         transactionType,
         exposure_type,
         statusCode,
         extractContext,
         contractStatus,
         sekContractStatusLevel1,
         sekContractStatusLevel2,
         PaidSupplier,
         FutureValue
   )
   SELECT   @reportDate                                 value_date, 
         e.ExposureType                              expt_id, 
         contractno                                  contractno, 
         'A'                                       asset_or_liability, 
         UPPER(BookValueCurrencyCode)                   book_currency, 
         UPPER(BookValueCurrencyCode)                   coupon_currency, 
         UPPER(ValueCurrencyCode)                      currency, 
         UPPER(ValueCurrencyCode)                      nominal_currency_orig, 
         UPPER(ValueCurrencyCode)                      nominal_currency_out, 
         UPPER(ValueCurrencyCode)                      principal_currency_orig, 
         UPPER(ValueCurrencyCode)                     principal_currency_out,
         UPPER(ContractType)                         product_type, 
         PackageId                                 package_id, 
         CAST(FLOOR(CAST(ExportDate AS FLOAT)) AS DATETIME)   [date], 
         StartDate                                 [start_date], 
         EndDate                                    maturity_date, 
         Value                                    value, 
         Portfolio                                 portfolio, 
         BookValue                                 book_value, 
         te.coupon_rate                              coupon_rate, 
         InterestMargin                              coupon_spread, 
         te.next_coupon_date                           next_coupon_date, 
         te.next_fixing_date                           next_fixing_date,
         FirstDueDate                              first_coupon_date, 
         e.CouponType                              coupon_type, 
         InterestPeriodMonths + 'm'                     coupon_frequency, 
         InterestTypeDescription                        coupon_base_curve, 
         PrincipalAmountOrig                           principal_amount_orig, 
         PrincipalAmountOut                           principal_amount_out, 
         NominalAmountOrig                           nominal_amount_orig, 
         NominalAmountOut                           nominal_amount_out,
         ExternAllIn                                         extern_all_in,
         TotalMargin                                         total_margin,
         Extract_Date                              load_date, 
         IMPORT_source                              IMPORT_source, 
         IMPORT_id                                 IMPORT_id, 
         IMPORT_transaction_id                        IMPORT_transaction_id, 
         RegistrationDate                           trade_date, 
         CASE e.ExposureType 
            WHEN 'FrameAgreement' THEN NULL 
            ELSE
               CASE LEN(LTRIM(RTRIM(ContractType))) WHEN 0 THEN NULL 
               ELSE 'FRAME' + LTRIM(RTRIM(ContractType))
            END
         END                                       allocation,  
         Supplier                                 obligor_ref, 
         Customer                                 issuer_ref, 
         FinalEndDate                              drawdown_end_date, 
         te.currCoupDate                              currCoupDate, 
         e.CouponType                              currCoupType, 
         te.nextCoupDate                              nextCoupDate, 
         e.CouponType                              nextCoupType, 
         Revolving                                 revolving_reducing, 
         NULL                                    package_type, 
         0                                       external_valuation,
         CASE e.ExposureType
            WHEN 'FrameAgreement' THEN NULL 
            ELSE 
               CASE leasinghirepurchase
                  WHEN 1 THEN 'PURC'
                  WHEN 0 THEN 'LEAS'
                  ELSE NULL
               END
         END                                       transactiontype,
         e.ExposureType                              exposure_type,
         e.StatusCode                              statusCode,
         @extractContext                              extractContext,
         'LIVE'                                    contractStatus,
         PF.fnGetSekContractStatusLevel1(e.ExposureType,e.StatusCode,e.ExposureType) AS sekContractStatusLevel1,
         PF.fnGetSekContractStatusLevel2(e.ExposureType,e.StatusCode,e.ExposureType) AS sekContractStatusLevel2,
         --START SC10784
         e.PaidSupplier                              PaidSupplier,
         e.FutureValue                              FutureValue
         --SLUT SC10784
     FROM @pf_exposure_load e
      LEFT OUTER JOIN @temp_exposure te ON e.[Contract] = te.[Contract] AND e.ContractLine = te.ContractLine
    WHERE ((e.ExposureType = 'ContractLine' AND CAST(FLOOR(CAST(e.EndDate AS FLOAT)) AS DATETIME) > CAST(FLOOR(CAST(ExportDate AS FLOAT)) AS DATETIME)) 
        OR (e.ExposureType <> 'ContractLine'))

   --START SC10784
   -- Splitta i CLCM och CLDD / Facility och Disbursed
   DECLARE @temp_proFinanceContract TABLE
   (
      [id] [int] NOT NULL,
      [value_date] [date] NOT NULL,
      [expt_id] [varchar](25) NOT NULL,
      [contractno] [varchar](15) NOT NULL,
      [asset_or_liability] [varchar](1) NOT NULL,
      [book_currency] [varchar](3) NULL,
      [coupon_currency] [varchar](3) NULL,
      [currency] [varchar](3) NULL,
      [nominal_currency_orig] [varchar](3) NULL,
      [nominal_currency_out] [varchar](3) NULL,
      [principal_currency_orig] [varchar](3) NULL,
      [principal_currency_out] [varchar](3) NULL,
      [product_type] [varchar](10) NULL,
      [package_id] [varchar](15) NULL,
      [date] [datetime] NOT NULL,
      [start_date] [datetime] NOT NULL,
      [maturity_date] [datetime] NULL,
      [value] [numeric](28, 8) NULL,
      [portfolio] [varchar](10) NULL,
      [book_value] [numeric](28, 8) NULL,
      [coupon_rate] [numeric](28, 8) NULL,
      [coupon_spread] [numeric](28, 8) NULL,
      [next_coupon_date] [datetime] NULL,
      [next_fixing_date] [datetime] NULL,
      [first_coupon_date] [datetime] NULL,
      [coupon_type] [varchar](10) NULL,
      [coupon_frequency] [varchar](10) NULL,
      [coupon_base_curve] [varchar](30) NULL,
      [principal_amount_orig] [numeric](28, 8) NULL,
      [principal_amount_out] [numeric](28, 8) NULL,
      [nominal_amount_orig] [numeric](28, 8) NULL,
      [nominal_amount_out] [numeric](28, 8) NULL,
      [extern_all_in] [numeric](28, 8) NULL,
      [total_margin] [numeric](28, 8) NULL,
      [load_date] [datetime] NOT NULL,
      [IMPORT_source] [int] NOT NULL,
      [IMPORT_id] [int] NOT NULL,
      [IMPORT_transaction_id] [int] NOT NULL,
      [trade_date] [datetime] NULL,
      [allocation] [varchar](45) NULL,
      [obligor_ref] [int] NULL,
      [issuer_ref] [int] NULL,
      [drawdown_end_date] [datetime] NULL,
      [currCoupDate] [datetime] NULL,
      [currCoupType] [varchar](10) NULL,
      [nextCoupDate] [datetime] NULL,
      [nextCoupType] [varchar](10) NULL,
      [revolving_reducing] [varchar](2) NULL,
      [package_type] [varchar](15) NULL,
      [external_valuation] [bit] NULL,
      [transactionType] [varchar](4) NULL,
      [exposure_type] [varchar](15) NULL,
      [statusCode]    [varchar] (3) NULL,
      [extractContext] [varchar](3) NOT NULL,
      [contractStatus] [varchar](15) NULL,
      [sekContractStatusLevel1] [varchar](10) NULL,
      [sekContractStatusLevel2] [varchar](30) NULL,
      [PaidSupplier] [money] NULL,
      [FutureValue] [money] NULL
   );

   INSERT INTO @temp_proFinanceContract(id, value_date, expt_id, contractno, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out,
            principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
            coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
            principal_amount_orig, principal_amount_out, nominal_amount_orig, nominal_amount_out, extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id,
            IMPORT_transaction_id, trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType,
            revolving_reducing, package_type, external_valuation, transactionType, exposure_type, statusCode, extractContext, contractStatus, sekContractStatusLevel1,
            sekContractStatusLevel2, PaidSupplier, FutureValue)
   SELECT id, value_date, expt_id, contractno, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out, 
            principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
            coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
            principal_amount_orig, principal_amount_out, nominal_amount_orig, nominal_amount_out, extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id,
            IMPORT_transaction_id, trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType,
            revolving_reducing,   package_type, external_valuation, transactionType, exposure_type, statusCode, extractContext, contractStatus, sekContractStatusLevel1, 
            sekContractStatusLevel2, PaidSupplier, FutureValue
     FROM @proFinanceContract;

   -- PAID
   WITH NOT_PAIED AS
   (
      SELECT  id,
            contractno,
            LEFT(contractno, 7) AS contract,
            CAST(RIGHT(contractno, 3) AS INT) AS line,
            LEFT(contractno, 7) + REPLICATE('0', 2 - LEN(CAST(CAST(RIGHT(contractno, 4) AS INT) AS VARCHAR(4)))) + CAST(CAST(RIGHT(contractno, 4) AS INT) AS VARCHAR(4)) + '00' AS newContractNo,
            'ContractLine' AS exposure_type,
            'Facility' AS expt_id,
            CASE
               WHEN StatusCode = '10' THEN 0
               ELSE ISNULL(principal_amount_out, 0) - ISNULL(PaidSupplier, 0)
            END AS nominalAmount
         FROM @proFinanceContract
   )
   UPDATE e
      SET e.contractno = NOT_PAIED.newContractNo,
         e.exposure_type = NOT_PAIED.exposure_type,
         e.expt_id = NOT_PAIED.expt_id,
         e.principal_amount_out = NOT_PAIED.nominalAmount,
         e.nominal_amount_out = NOT_PAIED.nominalAmount
      FROM @temp_proFinanceContract e
      INNER JOIN NOT_PAIED ON e.id = NOT_PAIED.id;

   ---- PAID
   WITH NOT_PAIED AS
   (
      SELECT  id,
            contractno,
            LEFT(contractno, 7) AS contract,
            CAST(RIGHT(contractno, 3) AS INT) AS line,
            StatusCode,
            ISNULL(PaidSupplier, 0) AS PaidSupplier, 
            ISNULL(principal_amount_out, 0) AS PresentValue,
            LEFT(contractno, 7) + REPLICATE('0', 2 - LEN(CAST(CAST(RIGHT(contractno, 4) AS INT) AS VARCHAR(4)))) + CAST(CAST(RIGHT(contractno, 4) AS INT) AS VARCHAR(4)) + '00' AS newContractNo,
            'ContractLine' AS exposure_type,
            'Facility' AS expt_id,
            ISNULL(principal_amount_out, 0) AS nominalAmount
         FROM @proFinanceContract
   ),
   PAIED AS
   (
      SELECT  e.id,
            e.contractno,
            LEFT(e.contractno, 7) AS contract,
            CAST(RIGHT(e.contractno, 3) AS INT) AS line,
            e.StatusCode,
            ISNULL(e.PaidSupplier, 0) AS PaidSupplier,
            ISNULL(e.principal_amount_out, 0) AS PresentValue,
            LEFT(e.contractno, 7) AS Part1,
            REPLICATE('0', 2 - LEN(CAST(CAST(RIGHT(e.contractno, 4) AS INT) AS VARCHAR(4)))) AS Part2,
            CAST(CAST(RIGHT(e.contractno, 4) AS INT) AS VARCHAR(4)) + '01' AS Part3,
            LEFT(e.contractno, 7) + REPLICATE('0', 2 - LEN(CAST(CAST(RIGHT(e.contractno, 4) AS INT) AS VARCHAR(4)))) + CAST(CAST(RIGHT(e.contractno, 4) AS INT) AS VARCHAR(4)) + '01' AS newContractNo,
            'ContractLine' AS exposure_type,
            'Disbursed' AS expt_id,
            CASE WHEN e.StatusCode = '10' THEN ISNULL(e.principal_amount_out, 0) ELSE ISNULL(e.PaidSupplier, 0) END AS nominalAmount,
            ISNULL(e.principal_amount_out, 0) AS principal_amount_out,
            CASE
            -- Fix for INC0010915 /AnOh
            WHEN e.StatusCode = '10' THEN 
               (SELECT  TOP 1 ISNULL(a.PresentValue, 0) - ISNULL(a.Amortization, 0) -- Added TOP 1
                  FROM @pf_amortization_load a
                  WHERE LEFT(e.contractno, 7) = a.Contract
                  AND ISNULL(a.DueDate, a.EndDate) = (SELECT MIN(ISNULL(a2.DueDate, a2.EndDate))
                                                FROM @pf_amortization_load a2
                                                WHERE a2.Contract = a.Contract
                                                AND a2.IMPORT_id = a.IMPORT_id)
                  ORDER BY ISNULL(a.PresentValue, 0) - ISNULL(a.Amortization, 0)   -- added order by to get the corrrect return results 
            -- End fix                                 
                                                )
            ELSE
               ISNULL(e.PaidSupplier, 0)
            END AS originalAmount
         FROM @proFinanceContract e
         WHERE (StatusCode = '10' OR PaidSupplier > 0)
   )
   INSERT INTO @temp_proFinanceContract(id, value_date, expt_id, contractno, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out,
            principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
            coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
            principal_amount_orig, 
            principal_amount_out, 
            nominal_amount_orig, 
            nominal_amount_out, 
            extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id, IMPORT_transaction_id,
            trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType, revolving_reducing,
            package_type, external_valuation, transactionType, 
            exposure_type, 
            statusCode, extractContext, contractStatus, sekContractStatusLevel1,
            sekContractStatusLevel2, PaidSupplier, FutureValue)
   SELECT e.id, value_date, PAIED.expt_id, PAIED.newContractNo, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out,
            principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
            coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
            PAIED.originalAmount, 
            PAIED.nominalAmount, 
            PAIED.originalAmount, 
            PAIED.nominalAmount, 
            extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id, IMPORT_transaction_id,
            trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType, revolving_reducing,
            package_type, external_valuation, transactionType, 
            PAIED.exposure_type,
            e.statusCode, extractContext, contractStatus, sekContractStatusLevel1,
            sekContractStatusLevel2, e.PaidSupplier, FutureValue
      FROM @temp_proFinanceContract e
      INNER JOIN NOT_PAIED ON e.id = NOT_PAIED.id
      INNER JOIN PAIED ON NOT_PAIED.id = PAIED.id;

   DELETE @proFinanceContract;
   INSERT INTO @proFinanceContract(value_date, expt_id, contractno, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out,
            principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
            coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
            principal_amount_orig, principal_amount_out, nominal_amount_orig, nominal_amount_out, extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id,
            IMPORT_transaction_id, trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType,
            revolving_reducing,   package_type, external_valuation, transactionType, exposure_type, statusCode, extractContext, contractStatus, sekContractStatusLevel1,
            sekContractStatusLevel2, PaidSupplier, FutureValue)
   SELECT value_date, expt_id, contractno, asset_or_liability, book_currency, coupon_currency, currency, nominal_currency_orig, nominal_currency_out,
            principal_currency_orig, principal_currency_out, product_type, package_id, date, start_date, maturity_date, value, portfolio, book_value,
            coupon_rate, coupon_spread, next_coupon_date, next_fixing_date, first_coupon_date, coupon_type, coupon_frequency, coupon_base_curve,
            principal_amount_orig, principal_amount_out, nominal_amount_orig, nominal_amount_out, extern_all_in, total_margin, load_date, IMPORT_source, IMPORT_id,
            IMPORT_transaction_id, trade_date, allocation, obligor_ref, issuer_ref, drawdown_end_date, currCoupDate, currCoupType, nextCoupDate, nextCoupType,
            revolving_reducing,   package_type, external_valuation, transactionType, exposure_type, statusCode, extractContext, contractStatus, PF.fnGetSekContractStatusLevel1(exposure_type,statusCode,expt_id) AS sekContractStatusLevel1,
            PF.fnGetSekContractStatusLevel2(exposure_type,statusCode,expt_id) AS sekContractStatusLevel2, PaidSupplier, FutureValue
      FROM @temp_proFinanceContract;
   --SLUT SC10784

   RETURN;
END
GO