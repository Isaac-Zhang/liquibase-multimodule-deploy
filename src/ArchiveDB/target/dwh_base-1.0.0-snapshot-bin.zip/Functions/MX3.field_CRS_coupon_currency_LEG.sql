--liquibase formatted sql

--changeSet func:Initial-MX3-field_CRS_coupon_currency_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_CRS_coupon_currency_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_CRS_coupon_currency_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTITCC0 varchar(3),@PL_M_TP_RTITCC1 varchar(3)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_CRS_coupon_currency_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_CRS_coupon_currency_LEG]
(
	@mxContractType varchar(10),
    @COM_leg_LEG int,
	@PL_M_TP_RTITCC0 varchar(3),
    @PL_M_TP_RTITCC1 varchar(3)
)
RETURNS varchar(3)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
            ---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP') THEN
				CASE 
                    WHEN @COM_leg_LEG = 1 THEN @PL_M_TP_RTITCC0
			        WHEN @COM_leg_LEG = 2 THEN @PL_M_TP_RTITCC1
			    ELSE NULL
			END
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType IN ('CDS', 'CF') THEN @PL_M_TP_RTITCC0
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'FRA', 'FUT', 'FXD', 'LN_BR', 'REPO', 'XSW','SWLEG') THEN NULL
		ELSE NULL
		END
END
GO