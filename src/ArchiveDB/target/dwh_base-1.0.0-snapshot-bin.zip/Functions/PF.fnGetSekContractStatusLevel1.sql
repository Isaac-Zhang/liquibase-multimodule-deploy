--liquibase formatted sql

--changeSet func:Initial-PF-fnGetSekContractStatusLevel1-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('PF.fnGetSekContractStatusLevel1', 'FN') IS NULL EXEC('CREATE FUNCTION [PF].[fnGetSekContractStatusLevel1](@exposureType varchar(15),@statusCode varchar(3),@contractType varchar(15)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-PF-fnGetSekContractStatusLevel1-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [PF].[fnGetSekContractStatusLevel1]
(
  @exposureType		VARCHAR(15)		= NULL
  ,@statusCode		VARCHAR(3)		= NULL
  ,@contractType	VARCHAR(15)		= NULL
)
RETURNS VARCHAR(10)
AS
BEGIN
  DECLARE @sekContractStatusLevel1 VARCHAR(10);

  SET @sekContractStatusLevel1 = 
	CASE	WHEN @contractType = 'Facility'																			THEN 'LIVE' -- Changed from PREL to LIVE as stated by DAHJ
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('01','06','07','10','50','51')				THEN 'LIVE'
			WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('40','90','91')								THEN 'DEAD'
			-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
			WHEN @exposureType = 'ContractLine'		AND @statusCode IS NULL 										THEN 'LIVE'
			WHEN @exposureType = 'FrameAgreement'																	THEN 'LIVE'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('10.','20.','30.','35.','36.','40.','60.')	THEN 'OFFER'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('50.','99.')								THEN 'DEAD'
			WHEN @exposureType = 'ProFront'			AND @statusCode IN ('70.')										THEN 'N/A'
			-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
			WHEN @exposureType = 'ProFront'			AND @statusCode IS NULL											THEN 'OFFER'
	END;

 -- SET @sekContractStatusLevel1 = 
	--CASE	WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('01','06','07','10','50','51')				THEN 'LIVE'
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IN ('40','90','91')								THEN 'DEAD'
	--		-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
	--		WHEN @exposureType = 'ContractLine'		AND @statusCode IS NULL 										THEN 'LIVE'
	--		WHEN @exposureType = 'FrameAgreement'																	THEN 'LIVE'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('10.','20.','30.','35.','36.','40.','60.')	THEN 'OFFER'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('50.','99.')								THEN 'DEAD'
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IN ('70.')										THEN 'N/A'
	--		-- Pre project 4, there were no status code, hence we have to use hard coded values when no status code is supplied
	--		WHEN @exposureType = 'ProFront'			AND @statusCode IS NULL											THEN 'OFFER'
	--END;

	RETURN @sekContractStatusLevel1;
	
END
GO