--liquibase formatted sql

--changeSet func:Initial-PF-fnAmortizationViewProFinancePre20111231-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('PF.fnAmortizationViewProFinancePre20111231', 'TF') IS NULL EXEC('CREATE FUNCTION [PF].[fnAmortizationViewProFinancePre20111231](@reportDate date,@EODSOD varchar(3)) RETURNS @tab TABLE ([contractno] varchar(30),[CCY_id] varchar(3),[pmnt_date] date,[pmnt_type] varchar(10),[pmnt_amount] numeric(28,8),[pmnt_outstanding] numeric(28,8)) AS BEGIN RETURN END')
GO



--changeSet func:Initial-PF-fnAmortizationViewProFinancePre20111231-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [PF].[fnAmortizationViewProFinancePre20111231]
(
	@reportDate		DATE,
	@EODSOD			VARCHAR(3) = 'EOD'
)
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : PF.fnAmortizationViewProFinance
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate             DATE
  -- !                       @EODSOD                 VARCHAR(3)
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with contracts from ProFinance the given date. 
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s      :
  -- !                select * from PF.fnAmortizationViewProFinance('2010-09-20', 'EOD');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2011-02-17 JoJo  Initial version
  -- !                       2011-03-07 JoJo  Changed to join with table variable instead och HISTORY-table
  -- !                       2011-09-16 ChTh  Reworked with recursive CTE
  -- !                       2012-01-30 JoJo  Pasted previous Iteration3 code in this function.
  -- +----------------------------------------------------------------------------------------------------------------
RETURNS @proFinanceAmortization TABLE
(
    contractno varchar(30) NOT NULL,
	[CCY_id] [varchar] (3) NOT NULL,
    [pmnt_date] date NOT NULL,
    [pmnt_type] varchar(10) NULL,
    [pmnt_amount] numeric(28,8),
    [pmnt_outstanding] numeric(28,8)
)
AS
BEGIN
    DECLARE @reportDateEnd date = DATEADD(dd, 1, @reportDate)
	DECLARE @exportDateTime		DATETIME;

    SELECT @exportDateTime = MAX(ExportDate) 
    FROM DWH_HISTORY.DWH.PF_ExportedAmortization 
    WHERE ReportDate >= @reportDate AND ReportDate <= @reportDateEnd

    --------------------------------------------------------------
    --< Skapa temporära tabeller för kontrakt och amorteringar >--
    --------------------------------------------------------------
    DECLARE @pf_exposure_load TABLE (
        contractno varchar(30),
        contract varchar(30),
        contractLine varchar(5),
        maturity_date date,
        principal_amount_out numeric(28,8),
        currency varchar(3)
        PRIMARY KEY CLUSTERED (contract, contractLine)
    )
      
    DECLARE @pf_amortization_load TABLE (
        contract varchar(30),
        contractLine varchar(5),
        period smallint,
        amortizationDate date,
        amortization numeric(28,8),
        PRIMARY KEY CLUSTERED (contract, contractLine, period)
    )
    
    --------------------------------------------------------------
    --< Hämta grunddata                                        >--
    --------------------------------------------------------------
    INSERT INTO @pf_exposure_load
    SELECT
        contractno
    , LTRIM(RTRIM(LEFT(RIGHT(contractno, 11), 7))) [Contract]
    , REPLACE(RIGHT(RIGHT(contractno, 11), 4), '0', '') [ContractLine]
    , maturity_date
    , principal_amount_out
    , currency
    FROM PF.fnContractViewProFinance(@reportDate, @EODSOD);
           
    INSERT INTO @pf_amortization_load           
    SELECT 
        LTRIM(RTRIM(ea.[Contract])) AS Contract
        , LTRIM(RTRIM(ea.ContractLine)) AS ContractLine
        , ea.Period
        , COALESCE(ea.DueDate, ea.EndDate) AS amortizationDate
        , ea.Amortization
    FROM DWH_HISTORY.DWH.PF_ExportedAmortization ea
    WHERE ea.ExportDate = @exportDateTime
    AND ea.[Contract] <> '5000101-1'

   ;WITH FIRSTAMO AS (
      --------------------------------------------------------------
      --< Bestäm vilken av amorteringarna som är den första      >--
      --< giltiga amorteringen                                   >--
      --------------------------------------------------------------
      SELECT A.Contract, A.ContractLine, MIN(Period) AS minPeriod
      FROM @pf_amortization_load AS A
      WHERE @reportDate < A.amortizationDate
      GROUP BY A.Contract, A.ContractLine
      
   ), CTE AS (
      --------------------------------------------------------------
      --< Rekursivt anrop för att minska ner utestående belopp   >--
      --< per amortering. Observera att detta även kan öka på    >--
      --< beloppet om amorteringen är negativ                    >--
      --------------------------------------------------------------
      SELECT 
           A.Contract
         , A.ContractLine
         , A.Period
         , A.amortizationDate
         , E.principal_amount_out
         , A.Amortization
         , CONVERT(numeric(28,8), E.principal_amount_out - A.amortization) AS nominal_amount_out
      FROM @pf_exposure_load AS E
      INNER JOIN @pf_amortization_load A 
         ON E.Contract = A.Contract 
         AND E.ContractLine = A.ContractLine
      INNER JOIN FIRSTAMO AS F 
         ON A.Contract = F.Contract 
         AND A.ContractLine = F.ContractLine 
         AND A.Period = F.minPeriod
      UNION ALL
      SELECT 
           THIS.Contract
         , THIS.ContractLine
         , THIS.Period
         , THIS.amortizationDate
         , PREV.nominal_amount_out
         , THIS.Amortization
         , CONVERT(numeric(28,8), PREV.nominal_amount_out - THIS.Amortization)
      FROM @pf_amortization_load AS THIS
      INNER JOIN CTE AS PREV 
         ON THIS.Contract = PREV.Contract 
         AND THIS.ContractLine = PREV.ContractLine 
         AND THIS.Period = PREV.Period + 1
      WHERE THIS.Period > 1 AND @reportDate < THIS.amortizationDate

   ), LASTAMO AS (
      --------------------------------------------------------------
      --< Ta reda på den sista posten i rekursionen ovan.        >--
      --< Detta för att kunna bestämma återstående belopp för    >--
      --< att minska ner hela utestående beloppet till noll vid  >--
      --< maturity för kontraktet                                >--
      --------------------------------------------------------------
      SELECT Contract, ContractLine, MAX(Period) AS maxPeriod
      FROM CTE AS A
      GROUP BY Contract, ContractLine
   )
   INSERT INTO @proFinanceAmortization (
      contractno            , CCY_id                        , pmnt_date
    , pmnt_type             , pmnt_amount                   , pmnt_outstanding
   )
   --------------------------------------------------------------
   --< Hämta alla amorteringar och nedskrivet belopp från     >--
   --< rekursionen.                                           >--
   --------------------------------------------------------------  
   SELECT 
        E.contractno        , E.currency                    , CTE.amortizationDate
      , NULL                , -1 * CTE.Amortization         , CTE.nominal_amount_out
   FROM CTE
   INNER JOIN @pf_exposure_load E 
      ON CTE.Contract = E.Contract 
      AND CTE.ContractLine = E.ContractLine  
   
   UNION ALL
   --------------------------------------------------------------
   --< Skapa upp en sista post med typen 'RESIDUAL' om        >--
   --< utestående belopp inte har dragits ner till noll vid   >--
   --< sista amorteringen                                     >--
   --------------------------------------------------------------  
   SELECT 
        E.contractno        , E.currency                    , E.maturity_date
      , 'RESIDUAL'          , -1 * A.nominal_amount_out     , 0
   FROM LASTAMO
   INNER JOIN CTE AS A 
      ON LASTAMO.Contract = A.Contract 
      AND LASTAMO.ContractLine = A.ContractLine 
      AND LASTAMO.maxPeriod = A.Period
   INNER JOIN @pf_exposure_load E 
      ON A.Contract = E.Contract 
      AND A.ContractLine = E.ContractLine
   WHERE A.nominal_amount_out > 0

	RETURN;
END;
GO