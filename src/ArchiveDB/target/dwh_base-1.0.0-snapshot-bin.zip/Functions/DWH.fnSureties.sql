--liquibase formatted sql

--changeSet func:Initial-DWH-fnSureties-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnSureties', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnSureties](@reportDate date,@extractContext char(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnSureties-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnSureties]
(
 @reportDate DATE
,@extractContext CHAR(3)
)
RETURNS TABLE
AS RETURN

(
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t					[DWH].[fnSureties}
  -- ! R e t u r n s				INT
  -- ! P a r a m e t e r s   			Name, DataType, Description
  -- +						=========================================================================================
  -- !						@reportDate	DATE
  -- !						@extractContext CHAR(3)
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e     
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !   S A M P L E
  -- !						SELECT * FROM [DWH].[fnSureties]('2012-11-21', 'EOD') where sourceSystem ='ACBS'
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y		Date			Who	What
  -- +						==========	===== =========================================================================
  -- !						2012-01-27			Initial version ...
  -- !						2013-01-27	HAWI	Added partial allocation
  -- !                  2015-01-20  PEHA  Mx3 adaption
  -- !                  2015-01-20  PEHA  Mx3 adaption
  -- !                  2015-05-18  CHTH  Fixed coalesce on tradeNumber
  -- + ---------------------------------------------------------------------------------------------------------------
	SELECT
		 reportDate				= lc.reportDate
		,extractContext			= lc.extractContext
		,sourceSystem			= ims.shortName
		,suretyNumber			= COALESCE(surety.contractNumber, s.externalReference)
		,suretyTradeNumber      = COALESCE(surety.tradeNumber, surety.contractNumber, s.externalReference)
		,guarantorIdentity		= guarantor.counterpartIdentity
		,suretyType				= st.suretyType
		,suretyTypeDescription	= st.suretyTypeDescription
		,share					= cs.share
		,amount					= cs.amount
		,coveredContractNumber	= COALESCE(c.contractNumber, c.tradeNumber)
		,coveredTradeNumber	    = c.tradeNumber
		,isPartialAllocation	= CAST(CASE WHEN COALESCE(lpa.isPartialAllocated, 'N/A') = 'Yes' THEN 1 ELSE 0 END AS BIT)
		,grossAmount            = cs.grossAmount
		,grossShare             = cs.grossShare
		,eligible               = cs.eligible
	FROM DWH.surety s
	INNER JOIN DWH.loadContext lc
		ON s.[_loadContext_ID] = lc.ID
	INNER JOIN DWH.counterpart guarantor
		ON s.[_guarantor_ID] = guarantor.ID
	INNER JOIN DWH.LKP_suretyType st
		ON s.[_suretyType_ID] = st.ID
	LEFT JOIN DWH.contract surety
		ON s.[_contract_ID] = surety.ID
		AND [surety].[reportDate] = @reportDate
	INNER JOIN DWH.contractSurety cs
		ON s.id = cs.[_surety_ID]
	INNER JOIN DWH.contract c
		ON cs.[_contract_ID] = c.ID
	INNER JOIN DWH.LKP_importSource ims
		ON s.[_importSource_ID] = ims.ID
	LEFT JOIN DWH.[LKP_PartialAllocation] AS LPA 
		ON s.[_PartialAllocation_ID] = lpa.[ID]
	WHERE 
		lc.reportDate = @reportDate
		AND lc.extractContext = @extractContext
		AND s.[reportDate] = @reportDate
		AND c.[reportDate] = @reportDate
		AND [guarantor].[reportDate] = @reportDate		

------------------------------------------------------------------------------------------- 
-- 2013-01-27, H.Winther, villkor har lagts till för ReportDate för att minska antalet IO operationer, nackdelen är att estimated number of records ger för låga resultat
------------------------------------------------------------------------------------------- 
--Table 'contract'. Scan count 632, logical reads 3798, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--Table 'contractSurety'. Scan count 316, logical reads 950, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--Table 'counterpart'. Scan count 4749, logical reads 14247, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--Table 'LKP_suretyType'. Scan count 0, logical reads 9498, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--Table 'LKP_importSource'. Scan count 0, logical reads 9498, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--Table 'surety'. Scan count 1, logical reads 22, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.
--Table 'loadContext'. Scan count 0, logical reads 2, physical reads 0, read-ahead reads 0, lob logical reads 0, lob physical reads 0, lob read-ahead reads 0.

)
GO
GO