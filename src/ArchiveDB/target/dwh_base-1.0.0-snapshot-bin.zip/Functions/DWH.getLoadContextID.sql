--liquibase formatted sql

--changeSet func:Initial-DWH-getLoadContextID-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getLoadContextID', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[getLoadContextID](@reportDate date,@extractContext char(3)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-getLoadContextID-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.getLoadContextID 
(
	@reportDate DATE,
	@extractContext CHAR(3)
)
--SELECT DWH_BASE.DWH.getLoadContextID('2012-05-02', 'EOD')
RETURNS INT
AS
--
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! R e t u r n s :                   @loadContextID				INT			
-- !
-- ! P a r a m e t e r s :				Name                        DataType          Description
-- !									-----------------------     -------------     -----------------------------------------------
-- !									@reportDate                 DATETIME          The date on which the function will act.
-- !									@extractContext				CHAR(3)			
-- !
-- ! O b j e c t i v e :				 Returns the loadContextID.
-- !
-- ! R e v i s i o n   H i s t o r y : Date            Who     What
-- !                                   ----------      ----    ---------------------------------------------------------------------
-- !                                   2012-05-21      HAWI     Initial version...
-- +--------------------------------------------------------------------------------------------------------------------------------+
--
BEGIN
	DECLARE @loadContextID INT;

	SELECT 
		@loadContextID = ID 
	FROM DWH.[loadContext] AS LC 
	WHERE 
		[LC].[reportDate]=@reportDate 
		AND lc.[extractContext]=@extractContext;

	RETURN @loadContextID;
END
GO