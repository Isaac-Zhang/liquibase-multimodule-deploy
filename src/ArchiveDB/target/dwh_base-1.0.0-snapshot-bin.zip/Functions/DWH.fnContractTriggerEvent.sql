--liquibase formatted sql

--changeSet func:Initial-DWH-fnContractTriggerEvent-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnContractTriggerEvent', 'TF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnContractTriggerEvent](@reportDate date,@extractContext varchar(3)) RETURNS @tab TABLE ([_contract_ID] int,[_contractType_ID] int,[triggerEventType] varchar(30),[triggerStartDate] date,[triggerEndDate] date,[triggerStartCallDate] date,[triggerEndCallDate] date,[triggerRepaymentPercent] numeric(28,8),[triggerNoticePeriod] numeric(28,8),[triggerLevel] numeric(28,8)) AS BEGIN RETURN END')
GO



--changeSet func:Initial-DWH-fnContractTriggerEvent-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnContractTriggerEvent](@reportDate date, @extractContext varchar(3))
RETURNS @contractTriggerEvent TABLE (
   _contract_ID int NOT NULL
 , _contractType_ID int NOT NULL
 , triggerEventType varchar(30)
 , triggerStartDate date
 , triggerEndDate date
 , triggerStartCallDate date
 , triggerEndCallDate date
 , triggerRepaymentPercent numeric(28,8)
 , triggerNoticePeriod numeric(28,8)
 , triggerLevel numeric(28,8)
)
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnContractTriggerEvent
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate					DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with all contractEvents 
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s			:
  -- !								select * from DWH.fnContractTriggerEvent('2010-05-03', 'EOD');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2012-02-02 AnOh  Initial version
  -- !						 2013-03-22 JOID  Changed to left join for triggerLevel. Needed for ACBS.
  -- !						 2013-04-15 JOID  Back to inner join and added som distincts to handle multiple triggers per date. (put and call)
  -- +----------------------------------------------------------------------------------------------------------------

AS
BEGIN
    DECLARE @loadContextID int = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)

    DECLARE @contractEvent TABLE (_contract_ID int, _contractType_ID int, idx1 int, eventType varchar(30), PRIMARY KEY CLUSTERED (_contract_ID, _contractType_ID, idx1, eventType ))
    INSERT INTO @contractEvent ([_contract_ID], [_contractType_ID], idx1, eventType)
    SELECT ce.[_contract_ID], CE.[_contractType_ID], ce.idx1, et.eventType
    FROM DWH.contractEvent CE
    INNER JOIN DWH.loadContext AS LC ON CE.[_loadContext_ID] = LC.ID
    INNER JOIN DWH.LKP_eventType et
      ON CE.[_eventType_ID] = et.ID
    WHERE ce.reportDate = @reportDate AND CE._loadContext_ID = @loadContextID
      AND et.eventType IN ('putCall', 'instrumentTriggerPut', 'instrumentTriggerCall')

    DECLARE @contractEventValues TABLE 
		(
			_contract_ID int, 
			_contractType_ID int, 
			_eventType_ID INT,
			idx1 int, 
			eventValue numeric(28,8), 
			valueType varchar(30), 
			PRIMARY KEY CLUSTERED (_contract_ID, _contractType_ID, _eventType_ID, idx1, valueType )
		)
    INSERT INTO @contractEventValues ([_contract_ID], [_contractType_ID], [_eventType_ID], idx1, eventValue, valueType)
    SELECT DISTINCT cev.[_contract_ID], cev.[_contractType_ID], cev.[_eventType_ID], cev.idx1, cev.eventValue, vt.valueType
    FROM DWH.contractEventValue cev
    INNER JOIN DWH.contractEvent ce 
       ON cev.[_contract_ID] = ce.[_contract_ID] 
       AND cev.[_contractType_ID] = ce.[_contractType_ID]
       AND ce.idx1 = cev.idx1
    INNER JOIN DWH.LKP_valueType vt
       ON cev.[_valueType_ID] = vt.ID
    WHERE ce.reportDate = @reportDate AND CE._loadContext_ID = @loadContextID
    AND vt.valueType IN ('triggerRepaymentPercent','triggerLevel', 'triggerNoticePeriod')

    DECLARE @contractEventDates TABLE 
    (
		_contract_ID int, 
		_contractType_ID int, 
		_eventType_ID INT,
		idx1 int, 
		eventDate date, 
		dateType varchar(30), 
		PRIMARY KEY CLUSTERED (_contract_ID, _contractType_ID, _eventType_ID, idx1, dateType )
	)
    INSERT INTO @contractEventDates ([_contract_ID], [_contractType_ID],_eventType_ID, idx1, eventDate, dateType)
    SELECT DISTINCT ced.[_contract_ID], ced.[_contractType_ID], ced.[_eventType_ID], ced.idx1, ced.eventDate, dt.dateType
    FROM  DWH.contractEventDate ced
    INNER JOIN DWH.contractEvent ce 
       ON ced.[_contract_ID] = ce.[_contract_ID] 
       AND ced.[_contractType_ID] = ce.[_contractType_ID]
       AND ce.idx1 = ced.idx1
    INNER JOIN DWH.LKP_dateType dt 
       ON ced.[_dateType_ID] = dt.ID
    WHERE ce.reportDate = @reportDate AND CE._loadContext_ID = @loadContextID
       AND DT.dateType IN ('triggerStartDate', 'triggerEndDate', 'triggerStartCallDate', 'triggerEndCallDate')

    INSERT INTO @contractTriggerEvent
    SELECT DISTINCT
     ce.[_contract_ID]
    ,ce._contractType_ID
    --,ce.idx1
    ,ce.eventType AS triggerEventType
    ,tsd.eventDate AS triggerStartDate
    ,ted.eventDate AS triggerEndDate
    ,tscd.eventDate AS triggerStartCallDate
    ,tecd.eventDate AS triggerEndCallDate
    ,trp.eventValue AS triggerRepaymentPercent
    ,tnp.eventValue AS triggerNoticePeriod
    ,tlv.eventValue AS triggerLevel
    FROM @contractEvent ce
    INNER JOIN @contractEventDates tsd
      ON ce.[_contract_ID] = tsd.[_contract_ID]
      AND ce.idx1 = tsd.idx1
      AND tsd.dateType = 'triggerStartDate'
    INNER JOIN @contractEventDates ted
      ON ce.[_contract_ID] = ted.[_contract_ID]
      AND ce.idx1 = ted.idx1
      AND ted.dateType = 'triggerEndDate'
    INNER JOIN @contractEventDates tscd
      ON ce.[_contract_ID] = tscd.[_contract_ID]
      AND ce.idx1 = tscd.idx1
      AND tscd.dateType = 'triggerStartCallDate'
    INNER JOIN @contractEventDates tecd
      ON  ce.[_contract_ID] = tecd.[_contract_ID]
      AND ce.idx1 = tecd.idx1
      AND tecd.dateType = 'triggerEndCallDate'
    INNER JOIN @contractEventValues trp
      ON  ce.[_contract_ID] = trp.[_contract_ID]
      AND ce.idx1 = trp.idx1
      AND trp.valueType = 'triggerRepaymentPercent'
    INNER JOIN @contractEventValues tnp
      ON  ce.[_contract_ID] = tnp.[_contract_ID]
      AND ce.idx1 = tnp.idx1
      AND tnp.valueType = 'triggerNoticePeriod'
    INNER JOIN @contractEventValues tlv
    ON ce.[_contract_ID] = tlv.[_contract_ID]
      AND ce.idx1 = tlv.idx1
      AND tlv.valueType = 'triggerLevel'

    RETURN
END
GO