--liquibase formatted sql

--changeSet func:Initial-DWH-get_H_LegalCounterpartByShortName-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_H_LegalCounterpartByShortName', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[get_H_LegalCounterpartByShortName](@shortName varchar(15),@reportDate datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-get_H_LegalCounterpartByShortName-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[get_H_LegalCounterpartByShortName] (  @shortName  VARCHAR (15)
														    , @reportDate DATETIME )
  RETURNS VARCHAR(15)
  AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @name                       VARCHAR (15)      Shortname of legal parent to counterpart 
  -- !																				   supplied as @shortName
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !                                   @shortName					 VARCHAR (20)      The shortname of the counterpart to get legal 
  -- !																				   counterpart for.
  -- !                                   @reportDate                 DATETIME          The date on which the procedure will act.
  -- !
  -- ! O b j e c t i v e :				 Returns the ID the ancestor acting as legal counterpart for the counterpart supplied.
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-03-12      JoJo    Initial version by JoJo
  -- !
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
  BEGIN
  --
	DECLARE @name VARCHAR(15);
	--
	WITH c AS (
		SELECT CP.ID, CP.shortname, CP.counterpartIdentity, ch.counterpartIDPath, ch.parentCounterpartIDPath, CP.reportDate
		FROM DWH.counterpartHierarchy ch
		INNER JOIN DWH.counterpart CP ON CH._counterpart_ID = CP.ID
		WHERE CP.shortName = @shortname AND CP.reportDate = @reportDate

		UNION ALL

		SELECT CP.ID, CP.shortname, CP.counterpartIdentity, ch.counterpartIDPath, ch.parentCounterpartIDPath, CP.reportDate
		FROM DWH.counterpartHierarchy ch
		INNER JOIN DWH.counterpart CP ON CH._counterpart_ID = CP.ID
		INNER JOIN c ON ch.counterpartIDPath = c.parentCounterpartIDPath AND CP.reportDate = c.reportDate
	)
	SELECT TOP 1 @name = c.Shortname
	  FROM c 
		INNER JOIN DWH.counterpart cp ON cp.ID = c.ID
	 WHERE c.reportDate = @reportDate
	   AND cp.isBranch = 0 
	   AND (cp.isSubsidiary = 0 OR cp.isSubsidiary = 1) -- I know, silly. It's here just to show that the field is part of determining the type of the counterpart
	 ORDER BY c.counterpartIDPath.GetLevel() DESC;
	--
	RETURN @name;
  --
  END
GO