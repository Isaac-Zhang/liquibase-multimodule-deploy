--liquibase formatted sql

--changeSet func:Initial-MX-field_originalContractNumber-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_originalContractNumber', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_originalContractNumber](@PL_M_MRPL_ONB int) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_originalContractNumber-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_originalContractNumber]
(
  @PL_M_MRPL_ONB INT
)
RETURNS VARCHAR(20)
AS
BEGIN
RETURN
   CASE WHEN @PL_m_mrpl_onb <= 0
        THEN NULL
        ELSE CAST(@PL_M_MRPL_ONB AS VARCHAR(20))
   END
END
GO