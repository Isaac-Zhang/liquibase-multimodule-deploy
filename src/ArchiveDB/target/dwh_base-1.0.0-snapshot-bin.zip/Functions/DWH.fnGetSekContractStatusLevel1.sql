--liquibase formatted sql

--changeSet func:Initial-DWH-fnGetSekContractStatusLevel1-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnGetSekContractStatusLevel1', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[fnGetSekContractStatusLevel1](@contractType varchar(10),@contractStatus varchar(32),@contractNumber varchar(20),@importSource tinyint) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-fnGetSekContractStatusLevel1-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnGetSekContractStatusLevel1]
(
  @contractType     VARCHAR(10)
  ,@contractStatus  VARCHAR(32)
  --,@contractNumber  NUMERIC(12,0)
  ,@contractNumber  VARCHAR(20)
  ,@importSource    tinyint
)

RETURNS VARCHAR(10)
AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @sekContractStatusLevel1 VARCHAR (10)      level1 in contractStatusHierarchy
  -- !                                                               
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !                                   @contractType               INT               contractType in sourcesystem
  -- !                                   @contractStatus             VARCHAR (32)      contractStatus in sourcesystem
  -- !                                   @contractNumber             DATETIME          contractNumber in sourcesystem
  -- !
  -- ! O b j e c t i v e :                   Return level1 in contractStatusHierarchy
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-11-16      DaHj    Initial version...
  -- !                                   2012-04-19      ChTh    Preliminary drawdowns on offers should have OFFER as level 1 and PREL as level2
  -- !									 2012-08-15		 HAWI	 Changed the contractnumber to be able to handle ACBS
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
BEGIN

  DECLARE @sekContractStatusLevel1 VARCHAR(10);

  SET @sekContractStatusLevel1 = 
         --< GWB/ACBS-contracts >--
         ---------------------
        CASE  WHEN @importSource = 0 
                AND SUBSTRING (LTRIM(RTRIM(@contractNumber)),1,1) = '1' 
                AND SUBSTRING(LTRIM(RTRIM(@contractNumber)),9,1) = '1'                          
                AND @contractStatus = 'OFF'                                                     THEN 'OFFERPREL'

        
              WHEN @importSource = 0 AND @contractStatus = 'OFF' THEN 'OFFER'

              WHEN @importSource = 0 
                AND @contractType = 'CLCM'
                AND SUBSTRING (LTRIM(RTRIM(@contractNumber)),1,1) = '1' 
                AND SUBSTRING(LTRIM(RTRIM(@contractNumber)),9,1) = '1'                          THEN 'PREL'

              WHEN @importSource = 0 AND @contractType = 'CLCM'  AND @contractStatus = 'ACC'    THEN 'LIVE' 
              WHEN @importSource = 0 AND @contractType = 'CLFE'                                 THEN 'LIVE'


              --< CLDD-contract is NOT preliminary >--
              ----------------------------------------
              WHEN @importSource = 0 AND @contractType = 'CLDD'  AND NOT (SUBSTRING (LTRIM(RTRIM(@contractNumber)),1,1) = '1' 
                                                                AND  SUBSTRING (LTRIM(RTRIM(@contractNumber)),9,1) = '1')
                                    AND @contractStatus = 'ACC' THEN 'LIVE' 
              --< CLDD-contract is preliminary >--
              ------------------------------------
              WHEN  @importSource = 0 AND @contractType = 'CLDD'    AND (SUBSTRING (LTRIM(RTRIM(@contractNumber)),1,1) = '1' 
                                                                    AND  SUBSTRING (LTRIM(RTRIM(@contractNumber)),9,1) = '1')
                                                          THEN 'PREL'
              --< MxG-contracts >--
              ---------------------
              WHEN @importSource = 1 AND @contractStatus = 'LIVE'   THEN 'LIVE'
              WHEN @importSource = 1 AND @contractStatus = 'MKT_OP' THEN 'LIVE'
              WHEN @importSource = 1 AND @contractStatus = 'DEAD'   THEN 'DEAD'

              --< ACBS-contracts >--
              ---------------------
              WHEN @importSource = 5 AND @contractType = 'CLCM'  AND @contractStatus = 'OFF'    THEN 'OFFER'
              WHEN @importSource = 5 AND @contractType = 'CLCM'  AND @contractStatus = 'ACC'    THEN 'LIVE' 
              WHEN @importSource = 5 AND @contractType = 'CLFE'                                 THEN 'LIVE' 
              WHEN @importSource = 5 AND @contractType = 'CLDD'                                 THEN 'LIVE'

			  --< PREL ACBS-contracts >--
              WHEN @importSource = 6 AND @contractType = 'CLCM'  AND @contractStatus = 'OFF'    THEN 'OFFER'
              WHEN @importSource = 6 AND @contractType = 'CLDD' 								THEN 'PREL'

            --< All other contract is ALIVE! >--
           ------------------------------------
        ELSE 'LIVE' END;
              
                                                            
  RETURN @sekContractStatusLevel1;
  
END
GO