--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_gwb_lnk_TRN-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_gwb_lnk_TRN', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_gwb_lnk_TRN](@mxContractType varchar(10),@CRD_M_GWB_LNK varchar(12),@IRD_M_GWB_LNK varchar(12)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_gwb_lnk_TRN-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_gwb_lnk_TRN]
(
	@mxContractType varchar(10),
	@CRD_M_GWB_LNK varchar(12),
    @IRD_M_GWB_LNK varchar(12)
)
RETURNS varchar(12)
AS
BEGIN
	RETURN
		CASE
		    ---------------------------------------------------- CRS_CDS ----------------------------------------------------
		    WHEN @mxContractType = 'CDS'
		    THEN @CRD_M_GWB_LNK
		    ELSE @IRD_M_GWB_LNK
		END

END
GO