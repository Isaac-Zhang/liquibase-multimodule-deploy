--liquibase formatted sql

--changeSet func:Initial-DWH-fnBasicContractView-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnBasicContractView', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnBasicContractView](@reportDate date,@loadContextID int,@contractIDs xml) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnBasicContractView-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [DWH].[fnBasicContractView](
   @reportDate date
 , @loadContextID int
 , @contractIDs xml = NULL
)
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnBasicContractView
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate          DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with all basic contract information joined with all different contract
  -- !                       types
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s      :
  -- !                select * from DWH.fnBasicContractView('2010-05-03');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-06-02 CHTH  Initial version
  -- !                       2010-09-17 ALFR  Add SecurityCode to return list, join to Instrument
  -- !                       2010-10-05 CHTH  Removed a lot and code and returned this function to a BASIC view
  -- !                       2010-10-27 JOJO  Added field _sekContractType_ID to output
  -- !                       2012-03-22 MaSo  Added field isEarlyTermination to output
  -- !                       2012-04-18 MaSo  Added fields commentMXGBuy and commentMXGSell to output
  -- !                       2012-05-11 MaSo  Added logic for optionPutCall and optionCashDelivery
  -- !						 2012-11-19 AnOh  Added docUser and docComment for OTC report purpose
  -- !						 2012-12-04 PEHA  Added isnull -> 0 check on isCentralCleared flag
  -- !						 2013-01-17 AnOh  Added accountingLevel #CHG0010328
  -- !						 2013-02-11 AnOh  Added sidaRefNo, sidaRefRate CHG0010341
  -- !                       2013-04-15 PEHA  Added strategy
  -- !                       2013-05-03 JOID  Added uniqueTradeID
  -- !                       2013-06-14 PEHA  Added accrualDayCountConvention + tradeExecutionTimestamp
  -- !                       2013-09-18 PEHA  Added mxmlFileCreationDatetime
  -- !                       2013-10-09 PEHA  Added quoteBasis
  -- !                       2013-10-10 PEHA  Corrected typo with contractIRS join which earlier joined contractCS instead
  -- !                       2013-10-22 PEHA  Added confirmationStatus for FRA, XSW, LNBR & CDS
  -- !                       2014-03-26 GoLu  Added isSyndicated
  -- !					     2014-04-23 AnOh  Added whtTax
  -- !						 2014-06-19	PaSh  CHG0011309 - added swapContractNumber 
  -- !						 2014-10-29 ANWI  CHG0011684, UDF-f�lt �ver buyback niv� till DWH_PRES
  -- !						 2014-10-30 AnWi  CHG0010011, Nytt f�lt i DWH, nytt f�lt i ACBS, AC Centre
  -- !                       2014-11-20 GoLu  CHG001154 - UDF-f�lt �ver average life till DWH_PRES     (�terk�p)
  -- !						 2015-01-22	joid Added AvailableForClearing (chg0011763)
  -- !						 2014-11-*  PEHA  Mx3 adaption. updated 7apr-15
  -- +----------------------------------------------------------------------------------------------------------------

AS RETURN
(
   WITH ID AS (
      SELECT ID = ContractNode.value('@ID[1]', 'INT')
      FROM @contractIDs.nodes('/row') T1(ContractNode)
      WHERE @contractIDs IS NOT NULL
      UNION ALL
      SELECT ID
      FROM DWH.contract C
      WHERE reportDate = @reportDate AND _loadContext_ID = @loadContextID
      AND @contractIDs IS NULL      
   )
     SELECT
        -----------------------------------------------------------------------------------------------
        --- Properties originating from contract
        -----------------------------------------------------------------------------------------------
        [CCP].[_contract_ID]          
      , CCP._contractType_ID          
      , CCP._legType_ID
      , CCP.legNumber                 
      , CCP.leg
      , C._sekContractType_ID         
      , C.[_package_ID]               
      , CCP.[_portfolio_ID]             
      , C.[_importSource_ID]       
      , C.[contractNumber]            
      , LEG.assetOrLiability          
      , LEG.buyOrSell                 
      , LEG.payOrReceive
      , LEG.[legTypeDescription]      
      , CT.[contractType]             
      , C.[contractType]          AS contractTypeOrig
      , LKP_MO.marketOperationID  AS [lastMarketOperationID]
      , LKP_MO.descr              AS [lastMarketOperation]
      , C.earlyTerminationHasFutureCashFlow     
      , C.[futurePaymentDateExists]   
      , C.[dataReferenceNumber]       
      , C.[internalDeal]              
      , LC.[extractContext]           
      , C.[contractFamily]            
      , C.[contractGroup]             
      , C.[entity]                    
      , C.[accountingSection]         
      , C.[GWBlnk]                    
      , C.[contractTypology]          
      , C.[index]                     
      , C.[strategicOpportunistic]    
      , C.[classification]            
      , C.externalReference           
      , C.replacesTradeNumber      
      , C.replacedByTradeNumber    
      , C.originalContractNumber
      , C.isEmmaContributed           
      , C.isCustomerFinanceContributed
      , C.isStructuredFinanceContributed
      , C.isIpfContributed            
      , C.isCorporateContributed      
      , C.isTradeFinanceContributed
      , CCP.couponFrequency           
      , CCP.couponType                
      , CCP.couponBaseCurve
      , C.isEarlyTermination          
      , C.commentMXGBuy               
      , C.commentMXGSell
      , C.productClass
      , CCP.docComment
      , CCP.docUser
      , C.accountingLevel
      , C.sidaRefNo
	  , C.sidaRefRate

        -----------------------------------------------------------------------------------------------
        --- Properties that are common among several contract types
        -----------------------------------------------------------------------------------------------
      , CASE CT.ContractType
          WHEN 'CD'      THEN CD.CDSbuySell 
          WHEN 'LN_BR'    THEN LNBR.CDSbuySell 
          WHEN 'CDS'     THEN CDS.CDSbuySell 
          WHEN 'REPO'    THEN REPO.CDSbuySell 
          ELSE NULL
        END AS CDSbuySell
      , confirmationStatus = CASE CT.ContractType
										   WHEN 'BOND'    THEN BOND.confirmationStatus
										   WHEN 'ASWP'    THEN ASWP.confirmationStatus 
										   WHEN 'CS'      THEN CS.confirmationStatus 
										   WHEN 'IRS'     THEN IRS.confirmationStatus 
										   WHEN 'CDS'     THEN CDS.confirmationStatus
										   WHEN 'FRA'     THEN FRA.confirmationStatus
										   WHEN 'XSW'     THEN XSW.confirmationStatus
										   WHEN 'SWLEG'     THEN XSW.confirmationStatus  --SWLEG is XSW in MX3 lingo
										   WHEN 'LN_BR'     THEN LNBR.confirmationStatus
										   ELSE NULL END 

      , CASE CT.ContractType
          WHEN 'ASWP'    THEN ASWP.GWBCreditCovered 
          WHEN 'CS'      THEN CS.GWBCreditCovered 
          WHEN 'IRS'     THEN IRS.GWBCreditCovered 
          ELSE NULL
        END AS GWBCreditCovered

        -----------------------------------------------------------------------------------------------
        --- Common properties for all contract types
        -----------------------------------------------------------------------------------------------
      , CCP.[fixedOrVariable]        
      , CCP.[market]                  
      , CCP.[termOriginal]            
      , CC.currencyCode AS  contractCurrency 
      , CE.shortname AS contractOwner           
      , CCP._instrument_ID             

        -----------------------------------------------------------------------------------------------
        --- Properties specific for each contract type
        -----------------------------------------------------------------------------------------------
        -- contractBOND
      , BOND.[isCredit]                     

      , ASWP.[BOND]                   

      , CDS_COV.contractNumber AS [CDScoveredAsset]
	  , CDS_COV.tradeNumber AS [CDScoveredAssetTrn]
      , CDS.[allocation]              

      , REPO.[BONDcleanPrice]         
      , REPO.[BONDdirtyPrice]         
      , REPO.[BONDunderlyingNotional] 
      , REPO.[BONDunderlyingValue]    

      , COM.[revolvingReducing]

      , CASE OPT.callPut
            WHEN 'C' THEN 'Call'
            WHEN 'P' THEN 'Put'
            WHEN 'G' THEN 'Generic'
            WHEN 'F' THEN 'FX'
            ELSE ''
        END AS optionPutCall
      ,  CASE OPT.cashDelivery
             WHEN 'C' THEN 'Cash'
             WHEN 'D' THEN 'Delivery'
             ELSE ''
         END AS optionCashDelivery
      , OPT.[standard] AS optionStandard
      , OPT.[standardDescription] AS optionStandardDescription
      , OPT.[style] AS optionStyle
      , OPT.[styleDescription] AS optionStyleDescription

      , isCentralCleared = ISNULL(C.isCentralCleared,0)
	  , CCP.hedgeIndicator
	  , CDS.isPartialAllocation
	  , C.strategy
	  , C.uniqueTradeId
	  , accrualDayCountConvention = LACDC.NAME
	  , C.tradeExecutionDatetime
      , C.isUpfrontPayment
	  , C.mxmlFileCreationDatetime
	  , quoteBasis = ISNULL(ASWP.quoteBasis,XSW.quoteBasis) --reason: either its an ASWP or XSW
	  , C.isSyndicated
	  , C.whtTax
	  , C.swapContractNumber
	  , BOND.buyBackLevel
	  , C.acCenter
	  , BOND.averageLife
	  , C.availableForClearing
	  , C.tradeNumber

        FROM DWH.contract C
        INNER JOIN ID ON C.ID = ID.ID

        INNER JOIN DWH.contractCommonProperty CCP     ON CCP._contract_ID         = C.ID
                                            AND      CCP._contractType_ID     = C._contractType_ID

        INNER JOIN DWH.LKP_ContractType        CT    ON C._contractType_ID = CT.ID

        INNER JOIN DWH.LKP_legType             LEG   ON CCP._legType_ID      = LEG.ID

        INNER JOIN DWH.loadContext             LC    ON C._loadContext_ID    = LC.ID

        LEFT JOIN (
         SELECT _contract_ID, [_contractType_ID], [_legType_ID], legNumber
           , isCredit, SS.statusName AS confirmationStatus, buyBackLevel, averageLife
         FROM DWH.contractBOND A
         LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) BOND  ON CCP._contract_ID        = BOND._contract_ID 
                                            AND      CCP._contractType_ID    = BOND._contractType_ID 
                                            AND      CCP._legType_ID         = BOND._legType_ID
                                            AND    CCP.legNumber      = BOND.legNumber

        LEFT JOIN DWH.contractCD               CD    ON CCP._contract_ID        = CD._contract_ID 
                                            AND      CCP._contractType_ID    = CD._contractType_ID 
                                            AND      CCP._legType_ID         = CD._legType_ID
                                            AND    CCP.legNumber      = CD.legNumber

        LEFT JOIN DWH.contractCF               CF    ON CCP._contract_ID        = CF._contract_ID 
                                            AND      CCP._contractType_ID    = CF._contractType_ID 
                                            AND      CCP._legType_ID         = CF._legType_ID
                                            AND    CCP.legNumber      = CD.legNumber

        LEFT JOIN DWH.contractEQUIT            EQUIT ON CCP._contract_ID        = EQUIT._contract_ID 
                                            AND      CCP._contractType_ID    = EQUIT._contractType_ID 
                                            AND      CCP._legType_ID         = EQUIT._legType_ID
                                            AND    CCP.legNumber      = EQUIT.legNumber

        LEFT JOIN DWH.contractFUT              FUT   ON CCP._contract_ID        = FUT._contract_ID 
                                            AND      CCP._contractType_ID    = FUT._contractType_ID 
                                            AND      CCP._legType_ID         = FUT._legType_ID
                                            AND    CCP.legNumber      = FUT.legNumber

        LEFT JOIN DWH.contractFXD              FXD   ON CCP._contract_ID        = FXD._contract_ID 
                                            AND      CCP._contractType_ID    = FXD._contractType_ID 
                                            AND      CCP._legType_ID         = FXD._legType_ID
                                            AND    CCP.legNumber      = FXD.legNumber

         LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber,
               CDSbuySell, SS.statusName AS confirmationStatus
            FROM DWH.contractLNBR A
            LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) LNBR    ON CCP._contract_ID        = LNBR._contract_ID 
                                            AND      CCP._contractType_ID    = LNBR._contractType_ID 
                                            AND      CCP._legType_ID         = LNBR._legType_ID
                                            AND    CCP.legNumber      = LNBR.legNumber

        LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber
               , callPut, cashDelivery, OPT_STA.standard, OPT_STA.standardDescription, OPT_STY.style, OPT_STY.styleDescription
            FROM DWH.contractOPT A
            LEFT JOIN DWH.LKP_optionStandard OPT_STA ON A.[_optionStandard_ID] = OPT_STA.ID
            LEFT JOIN DWH.LKP_optionStyle OPT_STY ON A.[_optionStyle_ID] = OPT_STY.ID
        ) OPT   ON CCP._contract_ID        = OPT._contract_ID 
                                            AND      CCP._contractType_ID    = OPT._contractType_ID 
                                            AND      CCP._legType_ID         = OPT._legType_ID
                                            AND    CCP.legNumber      = OPT.legNumber

        LEFT JOIN DWH.contractSCF              SCF   ON CCP._contract_ID        = SCF._contract_ID 
                                            AND      CCP._contractType_ID    = SCF._contractType_ID 
                                            AND      CCP._legType_ID         = SCF._legType_ID
                                            AND    CCP.legNumber      = SCF.legNumber


        LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber
               , GWBcreditCovered, BOND, SS.statusName AS confirmationStatus, A.quoteBasis
            FROM DWH.contractASWP A
            LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) ASWP  ON CCP._contract_ID        = ASWP._contract_ID 
                                            AND      CCP._contractType_ID    = ASWP._contractType_ID 
                                            AND      CCP._legType_ID         = ASWP._legType_ID
                                            AND    CCP.legNumber      = ASWP.legNumber

        LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber,
               CDSbuySell,BONDleg,allocation,isPartialAllocation,_contractCDS_contract_ID ,SS.statusName AS confirmationStatus
            FROM DWH.contractCDS A
            LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) CDS    ON CCP._contract_ID        = CDS._contract_ID 
                                            AND      CCP._contractType_ID    = CDS._contractType_ID 
                                            AND      CCP._legType_ID         = CDS._legType_ID
                                            AND    CCP.legNumber      = CDS.legNumber

        LEFT JOIN DWH.contract                 CDS_COV  ON CDS._contractCDS_contract_ID = CDS_COV.ID
                                                        AND CDS_COV.reportDate = @reportDate
                                                        AND CDS_COV._loadContext_ID = @loadContextID

        LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber
               , GWBcreditCovered, SS.statusName AS confirmationStatus
            FROM DWH.contractCS A
            LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) CS    ON CCP._contract_ID        = CS._contract_ID 
                                            AND      CCP._contractType_ID    = CS._contractType_ID 
                                            AND      CCP._legType_ID         = CS._legType_ID
                                            AND    CCP.legNumber      = CS.legNumber

        LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber
               , GWBcreditCovered, SS.statusName AS confirmationStatus
            FROM DWH.contractIRS A
            LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) IRS   ON CCP._contract_ID        = IRS._contract_ID 
                                            AND      CCP._contractType_ID    = IRS._contractType_ID 
                                            AND      CCP._legType_ID         = IRS._legType_ID
                                            AND    CCP.legNumber      = IRS.legNumber

         LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber
               , quoteBasis, SS.statusName AS confirmationStatus
            FROM DWH.contractXSW A
            LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) XSW   ON CCP._contract_ID        = XSW._contract_ID 
                                            AND      CCP._contractType_ID    = XSW._contractType_ID 
                                            AND      CCP._legType_ID         = XSW._legType_ID
                                            AND    CCP.legNumber      = XSW.legNumber

         LEFT JOIN (
            SELECT _contract_ID, [_contractType_ID], _legType_ID, legNumber
               , SS.statusName AS confirmationStatus
            FROM DWH.contractFRA A
            LEFT JOIN DWH.LKP_swapStatus SS ON A.[_swapConfirmStatus_ID] = SS.ID
        ) FRA   ON CCP._contract_ID        = FRA._contract_ID 
                                            AND      CCP._contractType_ID    = FRA._contractType_ID 
                                            AND      CCP._legType_ID         = FRA._legType_ID
                                            AND      CCP.legNumber      = FRA.legNumber

        LEFT JOIN DWH.contractREPO             REPO  ON CCP._contract_ID        = REPO._contract_ID 
                                            AND      CCP._contractType_ID    = REPO._contractType_ID 
                                            AND      CCP._legType_ID         = REPO._legType_ID
                                            AND    CCP.legNumber      = REPO.legNumber

        LEFT JOIN DWH.contractOSWP             OSWP  ON CCP._contract_ID        = OSWP._contract_ID 
                                            AND      CCP._contractType_ID    = OSWP._contractType_ID 
                                            AND      CCP._legType_ID         = OSWP._legType_ID
                                            AND    CCP.legNumber      = OSWP.legNumber

        LEFT JOIN DWH.contractCOM              COM   ON CCP._contract_ID        = COM._contract_ID 
                                            AND      CCP._contractType_ID    = COM._contractType_ID 
                                            AND      CCP._legType_ID         = COM._legType_ID
                                            AND    CCP.legNumber      = COM.legNumber

        LEFT JOIN DWH.LKP_marketOperation LKP_MO ON C._lastMarketOperation_ID = LKP_MO.ID

        LEFT JOIN DWH.LKP_currency CC ON CCP._currency_ID = CC.ID
        LEFT JOIN DWH.LKP_employee CE ON CCP._contractOwnerEmployee_ID = CE.ID
        LEFT JOIN DWH.LKP_dayCountConvention LACDC ON LACDC.ID = CCP._accrualDayCountConvention_ID AND LACDC.active=1


    WHERE C.reportDate = @reportDate AND C._loadContext_ID = @loadContextID
)
GO