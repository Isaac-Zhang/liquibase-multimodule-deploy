--liquibase formatted sql

--changeSet func:Initial-DWH-get_NoOfAForGroup-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_NoOfAForGroup', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[get_NoOfAForGroup](@NumberOfAGroupName varchar(30),@Rating varchar(5)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-get_NoOfAForGroup-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.get_NoOfAForGroup ( @NumberOfAGroupName VARCHAR(30), @Rating VARCHAR(5) )
RETURNS   INT
AS
BEGIN
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.get_NoOfAForGroup
  -- ! R e t u r n s       : INT
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       NumberOfAGroupName		 VARCHAR (30)
  -- !                       Rating					 VARCHAR (5)
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returnerar AntalA för den kombination av gruppnamn och rating som skickas till funktionen.
  -- !						 Om ingen post påträffas returneras 0 (noll) eftersom icke existerande post tolkas som noll A.
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-05-10 JoJo  Initial version by JoJo
  -- !
  -- +----------------------------------------------------------------------------------------------------------------
  --
	DECLARE @noOfA	INT
	
	SELECT @noOfA = NumberOfA
	  FROM DWH.LKP_numberOfA 
	 WHERE NumberOfAGroupName = @NumberOfAGroupName
	   AND Rating = @Rating
   
   RETURN ISNULL(@noOfA, 0)
END
GO