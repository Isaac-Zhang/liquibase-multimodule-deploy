--liquibase formatted sql

--changeSet func:Initial-DWH-has_H_SameRiskCounterpartByCounterpartId-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.has_H_SameRiskCounterpartByCounterpartId', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[has_H_SameRiskCounterpartByCounterpartId](@counterpartId1 numeric(10,0),@counterpartId2 numeric(10,0),@reportDate datetime) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-has_H_SameRiskCounterpartByCounterpartId-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[has_H_SameRiskCounterpartByCounterpartId] (  @counterpartId1	NUMERIC(10, 0)
																  , @counterpartId2	NUMERIC(10, 0)
																  , @reportDate DATETIME )
  RETURNS BIT
  AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @same                       BIT			   1 if the two counterparties have the same risk
  -- !																				   counterpart, 0 otherwise
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !                                   @counterpartId1			 NUMERIC(10, 0)	   The counterpartId of the first counterpart to compare.
  -- !                                   @counterpartId2			 NUMERIC(10, 0)	   The counterpartId of the second counterpart to compare.
  -- !                                   @reportDate                 DATETIME          The date on which the procedure will act.
  -- !
  -- ! O b j e c t i v e :				 Return 1 if the two counterparties have the same risk counterpart, 0 otherwise.
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-03-12      JoJo    Initial version by JoJo
  -- !
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
  BEGIN
  --
	DECLARE @same BIT;
	--
	IF DWH.get_H_RiskCounterpartByCounterpartId(@counterpartId1, @reportDate) =
	   DWH.get_H_RiskCounterpartByCounterpartId(@counterpartId2, @reportDate)
		SET @same = 1
	ELSE
		SET @same = 0
	--
	RETURN @same;
  --
  END
GO