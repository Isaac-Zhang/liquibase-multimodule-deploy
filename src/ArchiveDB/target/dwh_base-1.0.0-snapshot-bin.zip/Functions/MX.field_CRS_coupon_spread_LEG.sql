--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_coupon_spread_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_coupon_spread_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_coupon_spread_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_RTMMRG0 numeric(9,4),@PL_M_TP_RTMMRG1 numeric(9,4),@DTFUT_M_DT_MARGIN0 numeric(28,8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_coupon_spread_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [MX].[field_CRS_coupon_spread_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
	@PL_M_TP_RTMMRG0 numeric(9,4),
    @PL_M_TP_RTMMRG1 numeric(9,4),
    @DTFUT_M_DT_MARGIN0 numeric(28,8)
)
RETURNS numeric(28,8)
AS
BEGIN
	RETURN
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP') THEN --@DTFUT_M_DT_MARGIN0
				CASE 
                WHEN @COM_leg_LEG = 1 THEN @DTFUT_M_DT_MARGIN0
			    WHEN @COM_leg_LEG = 2 THEN @DTFUT_M_DT_MARGIN0
			    ELSE NULL
			    END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
			---------------------------------------------------- CRS_CD ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
			---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'LN_BR', 'REPO', 'CF')
			--THEN @DTFUT_M_DT_MARGIN0
			THEN @PL_M_TP_RTMMRG0
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			---------------------------------------------------- CRS_FRA ----------------------------------------------------
            ---------------------------------------------------- CRS_FUT ----------------------------------------------------
            ---------------------------------------------------- CRS_FXD ----------------------------------------------------
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType IN ('CDS', 'FRA', 'FUT', 'FXD', 'XSW')
			THEN NULL
		ELSE NULL
		END
END
GO