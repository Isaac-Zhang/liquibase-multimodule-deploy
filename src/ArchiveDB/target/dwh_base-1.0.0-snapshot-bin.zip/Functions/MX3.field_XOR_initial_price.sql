--liquibase formatted sql

--changeSet func:Initial-MX3-field_XOR_initial_price-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_XOR_initial_price', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_XOR_initial_price](@mxContractType varchar(10),@PL_M_TP_PRICE numeric(23,6),@PL_M_TP_PRICED numeric(23,6),@PL_M_TP_PRICED2 numeric(23,6),@PL_M_TP_STRIKE numeric(23,6),@PL_M_TP_RTVLC01 numeric(23,6)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_XOR_initial_price-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_XOR_initial_price]
(
	@mxContractType VARCHAR(10), 
    @PL_M_TP_PRICE numeric(23,6),
    @PL_M_TP_PRICED numeric(23,6),
    @PL_M_TP_PRICED2 numeric(23,6),
    @PL_M_TP_STRIKE numeric(23,6),
    @PL_M_TP_RTVLC01 numeric(23,6)
)
RETURNS numeric(23,6)
AS
BEGIN
	RETURN 
        CASE
            WHEN @mxContractType IN ('LN_BR')
            THEN 0
            WHEN @mxContractType IN ('FDB','NDB','BOND','CDS','CS','FRA','FUT','IRS','OSWP','SCF')
            THEN @PL_M_TP_PRICE
            WHEN @mxContractType IN ('FXD')
            THEN @PL_M_TP_PRICED
            WHEN @mxContractType IN ('XSW','SWLEG')
            THEN @PL_M_TP_PRICED
            WHEN @mxContractType IN ('REPO')
            THEN @PL_M_TP_RTVLC01
            WHEN @mxContractType IN ('OPT','CF','EQUIT')
            THEN @PL_M_TP_STRIKE
            WHEN @mxContractType IN ('ASWP','CD')
            THEN NULL
            ELSE NULL          
        END 
END
GO