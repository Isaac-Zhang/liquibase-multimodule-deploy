--liquibase formatted sql

--changeSet func:Initial-INTRA-fnReplacesTradeNumber-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('INTRA.fnReplacesTradeNumber', 'FN') IS NULL EXEC('CREATE FUNCTION [INTRA].[fnReplacesTradeNumber](@contractGroup varchar(5),@gwbLnk varchar(12),@mprlFlag varchar(1),@creator numeric(10,0),@valStat varchar(4)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-INTRA-fnReplacesTradeNumber-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
ALTER FUNCTION  [INTRA].[fnReplacesTradeNumber]
(
    @contractGroup varchar(5),
    @gwbLnk varchar(12),
    @mprlFlag varchar(1),
    @creator numeric(10,0),
    @valStat varchar(4)
)
RETURNS VARCHAR(20)
AS
BEGIN

SET @creator = RTRIM(LTRIM(@creator));

	RETURN CASE WHEN @contractGroup = 'CDS' 
							AND @creator NOT IN ('', '-1', '0')
							AND @mprlFlag = 'Y' 
							AND @valStat <> 'MIGM' THEN @creator
						WHEN @contractGroup <> 'CDS' 
							AND @creator NOT IN ('', '-1', '0')
							AND @mprlFlag = 'Y' THEN @creator
						ELSE NULLIF(RTRIM(LTRIM(@gwbLnk)), '')
           END
END
GO