--liquibase formatted sql

--changeSet func:Initial-DWH-getCounterpartParentRisk-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getCounterpartParentRisk', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[getCounterpartParentRisk](@reportDate date,@extractContext varchar(3),@counterpartID xml) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-getCounterpartParentRisk-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getCounterpartParentRisk] (
   @reportDate  date
 , @extractContext varchar(3)
 , @counterpartID XML = NULL
)
RETURNS TABLE 
AS RETURN
(
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! R e t u r n s :                   TABLE			   table of counterpartParentsRisk to childCounterpart
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! P a r a m e t e r s :             Name                        DataType          Description
-- !                                   -----------------------     -------------     -----------------------------------------------
-- !                                   @reportDate                 DATETIME          The date on which the function will act.
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! O b j e c t i v e :				       Returns a table with nearest RISKparent to all active counterparts.
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! R e v i s i o n   H i s t o r y : Date            Who     What
-- !                                   ----------      ----    ---------------------------------------------------------------------
-- !                                   2010-09-27      DaHj     Initial version...
-- !                                   2012-01-19      CHTH     Modified somewhat to improve performance
-- !												2012-11-01		 HAWI		 Slaughthered the old function, the data is populated 
-- !																				 by DWH_BASE.DWH.loadCounterpartInformation in DWH.counterpartParent
-- !                                   2013-07-04      CHTH    Added version where we use selective ID's needed for IRT flow
-- +--------------------------------------------------------------------------------------------------------------------------------+

SELECT 
	_counterpartChild_ID, 
	_counterpartParent_ID, 
	cpyIdChild				= child.[counterpartIdentity], 
	cpyIdParentRisk		= [parent].[counterpartIdentity],	
	shortnameParentRisk	= [parent].[shortname] ,
	longnameParentRisk	= parent.[longname]
FROM DWH.counterpartParent  cpp
INNER JOIN dwh.[counterpart] AS parent ON parent.id=cpp._counterpartParent_ID
INNER JOIN dwh.[counterpart] AS child ON child.id=cpp._counterpartChild_ID
INNER JOIN (
   SELECT _counterpart_ID = CounterpartNode.value('@ID[1]', 'INT')
   FROM @counterpartID.nodes('/row') T1(CounterpartNode)  
   WHERE @counterpartID IS NOT NULL
   UNION ALL
   SELECT _counterpart_ID = C.ID
   FROM  DWH.counterpart AS c
   INNER JOIN DWH.loadContext LC ON c._loadContext_ID = LC.ID
   WHERE       C.reportDate  = @reportDate
      AND C.[_loadContext_ID] = (SELECT lc.id FROM dwh.LoadContext lc WHERE lc.reportDate = @reportDate AND lc.extractContext=@extractContext)
      AND @counterpartID IS NULL
) FF ON FF._counterpart_ID = cpp._counterpartChild_ID
WHERE 
	cpp.ParentType='Risk' 
	AND cpp.reportDate = @reportDate 
	AND cpp._loadContext_ID IN (SELECT lc.id FROM dwh.LoadContext lc WHERE lc.reportDate = @reportDate AND lc.extractContext=@extractContext)
/*
RETURNS @counterpartChildParent TABLE 
(
  _counterpartChild_ID     int PRIMARY KEY CLUSTERED
  ,_counterpartParent_ID   int NULL
  ,cpyIdChild            NUMERIC(10,0) NULL
  ,cpyIdParentRisk      NUMERIC(10,0) NULL
  ,shortnameParentRisk  VARCHAR(15)   NULL
  ,longnameParentRisk   VARCHAR(255)  NULL
)

AS
--
-- +--------------------------------------------------------------------------------------------------------------------------------+
-- ! R e t u r n s :                   @counterpartChildParent					 TABLE			   table of counterpartParentsRisk to childCounterpart
-- !
-- ! P a r a m e t e r s :             Name                        DataType          Description
-- !                                   -----------------------     -------------     -----------------------------------------------
-- !                                   @reportDate                 DATETIME          The date on which the function will act.
-- !
-- ! O b j e c t i v e :				       Returns a table with nearest RISKparent to all active counterparts.
-- !
-- ! R e v i s i o n   H i s t o r y : Date            Who     What
-- !                                   ----------      ----    ---------------------------------------------------------------------
-- !                                   2010-09-27      DaHj     Initial version...
-- !                                   2012-01-19      CHTH     Modified somewhat to improve performance
-- +--------------------------------------------------------------------------------------------------------------------------------+
--
BEGIN
--
  DECLARE @loadContextID int = (SELECT ID FROM DWH.loadContext WHERE reportDate = @reportDate AND extractContext = @extractContext)

  ------------------------------------------------
  --< 2. Alla motparter som är RISK-motparter. >--
  ------------------------------------------------
  DECLARE @counterpartRisk TABLE
  (
    ID                   INT             PRIMARY KEY CLUSTERED
    ,counterpartIDPath   HIERARCHYID
    ,counterpartIdentity INT
    ,shortname           varchar(30)
    ,longname            varchar(255)
  );

  INSERT INTO @counterpartRisk
  SELECT      c.ID
              ,ch.counterpartIDPath
              ,c.counterpartIdentity
              ,c.shortname
              ,c.longname
  FROM        DWH.counterpartHierarchy  AS ch
  INNER JOIN  DWH.counterpart           AS c    ON        c.ID = ch._counterpart_ID
  WHERE       c.reportDate = @reportDate AND C.[_loadContext_ID] = @loadContextID
    AND (        (c.isBranch     = 0        AND       c.isSubsidiary = 0)
        -- De som inte har någon förälder i hierarkin .
        OR        (ch.parentCounterpartIDPath = 0x)
    );
  --------------------------------------------------------------
  --< 3. Motparter, vilka inte är Risk, och deras föräldrar. >--
  --------------------------------------------------------------

  WITH CTE_counterpart AS (

    --------------------------------
    --< Barnen som inte är Risk. >--
    --------------------------------
    SELECT      c.ID                                    AS childID
                ,c.counterpartIdentity                  AS cpyIdChild
                ,ch.counterpartIDPath
                -- Detta är inte parentID men man verkar måste sätta samma värde är som i den rekursiva delen nedan.
                ,c.ID                                   AS parentID
                ,c.counterpartIdentity                  AS cpyIdParent
                ,ch.parentCounterpartIDPath
                ,c.shortname                            AS parentShortname
                ,c.longname                             AS parentLongname
                ,c.isSubsidiary                         AS parentIsSubsidiary
                ,c.isBranch                             AS parentIsBranch
    FROM        DWH.counterpartHierarchy  AS ch
    INNER JOIN  DWH.counterpart           AS c      ON        c.ID  = ch._counterpart_ID
    LEFT JOIN   @counterpartRisk          AS cr     ON        cr.ID = c.ID
    WHERE       c.reportDate = @reportDate
                AND cr.ID IS NULL -- Counterpart is not RiskCounterpart
                AND C.[_loadContext_ID] = @loadContextID
    UNION ALL
    
    ----------------------------------------------------------
    --< Föräldern till barnet, som inte är en Riskmotpart. >--
    ----------------------------------------------------------
    SELECT       cte_c.childID                          AS childID
                ,cte_c.cpyIdChild                       AS cpyIdChild
                ,ch.counterpartIDPath
                ,c.ID                                   AS parentID
                ,c.counterpartIdentity                  AS cpyIdChildRisk
                ,ch.parentCounterpartIDPath
                ,c.shortname                            AS parentShortname
                ,c.longname                             AS parentLongname                
                ,c.isSubsidiary                         AS parentIsSubsidiary
                ,c.isBranch                             AS parentIsBranch                
    FROM        DWH.counterpartHierarchy  AS ch
    INNER JOIN  CTE_counterpart           AS cte_c
      ON        cte_c.parentCounterpartIDPath = ch.counterpartIDPath
      --        För att stanna sökningen om man har hittat en förälder som är RISK-motpart.       --
      --        Och det är fult och långsamt med NOT IN, men man får ju inte använda sig av       --
      --        LEFT JOIN i den rekursiva delen... vilket är vansinnigt och uppenbarligen fel!... --
      AND       cte_c.counterpartIDPath NOT IN( SELECT  counterpartIDPath
                                                FROM    @counterpartRisk)
    INNER JOIN  DWH.counterpart           AS c ON        c.ID  = ch._counterpart_ID
    WHERE c.reportDate = @reportDate
  )

  INSERT INTO @counterpartChildParent 
  (
    _counterpartChild_ID
    ,_counterpartParent_ID
    ,cpyIdChild
    ,cpyIdParentRisk
    ,shortnameParentRisk
    ,longnameParentRisk
  )
  SELECT      cte_c.childID
              ,cte_c.parentID
              ,cte_c.cpyIdChild
              ,cte_c.cpyIdParent
              ,cte_c.parentShortname    AS shortnameParentRisk
              ,cte_c.parentLongname     AS longnameParentRisk
  FROM        CTE_counterpart AS cte_c
  WHERE       cte_c.parentIsSubsidiary = 0
    AND       cte_c.parentIsBranch     = 0 

  UNION ALL

  SELECT      cr.ID                    AS _counterpartChild_ID
             ,cr.ID                    AS _counterpartParent_ID
             ,cr.counterpartIdentity   AS cpyIdChild
             ,cr.counterpartIdentity   AS cpyIdParentRisk
             ,cr.shortname            AS shortnameParentRisk
             ,cr.longname             AS longnameParentRisk
  FROM        @counterpartRisk  AS cr

  RETURN;

--
END
--  
*/
)
GO