--liquibase formatted sql

--changeSet func:Initial-MX-field_CRS_nominal_amount_out_LEG-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX.field_CRS_nominal_amount_out_LEG', 'FN') IS NULL EXEC('CREATE FUNCTION [MX].[field_CRS_nominal_amount_out_LEG](@mxContractType varchar(10),@COM_leg_LEG int,@PL_M_TP_NOMINAL numeric(19,2),@PL_M_TP_RTCCP01 numeric(19,2),@PL_M_TP_RTCCP11 numeric(19,2),@PL_M_TP_LQTY1 numeric(24,8),@PL_M_TP_LQTYS1 numeric(24,8),@PL_M_TP_SECLOT numeric(17,6),@PL_M_TP_QTYEQ numeric(24,8),@PL_M_QTY_INDEX numeric(3,0)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX-field_CRS_nominal_amount_out_LEG-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
-- User Defined Function
ALTER FUNCTION  [MX].[field_CRS_nominal_amount_out_LEG]
(
	@mxContractType varchar(10), 
    @COM_leg_LEG int,
    @PL_M_TP_NOMINAL numeric(19,2),
    @PL_M_TP_RTCCP01 numeric(19,2),
    @PL_M_TP_RTCCP11 numeric(19,2),
    @PL_M_TP_LQTY1 numeric(24,8),
    @PL_M_TP_LQTYS1 numeric(24,8),
    @PL_M_TP_SECLOT numeric(17,6),
    @PL_M_TP_QTYEQ numeric(24,8),
    @PL_M_QTY_INDEX numeric(3,0)
)
RETURNS numeric(28,8)
AS
BEGIN
	RETURN 
		CASE
			---------------------------------------------------- CRS_ASWP ----------------------------------------------------
			---------------------------------------------------- CRS_CS ----------------------------------------------------
			---------------------------------------------------- CRS_IRS ----------------------------------------------------
			WHEN @mxContractType IN ('ASWP', 'CS', 'IRS', 'OSWP', 'FRA') THEN
				CASE
                    WHEN @COM_leg_LEG = 1 THEN ABS(@PL_M_TP_RTCCP01)
                    WHEN @COM_leg_LEG = 2 THEN ABS(@PL_M_TP_RTCCP11)
			    ELSE NULL
			    END
			---------------------------------------------------- CRS_BOND ----------------------------------------------------
            ---------------------------------------------------- CRS_CD ----------------------------------------------------
            ---------------------------------------------------- CRS_FRA ----------------------------------------------------
			---------------------------------------------------- CRS_LN_BR ----------------------------------------------------
            ---------------------------------------------------- CRS_REPO ----------------------------------------------------
			WHEN @mxContractType IN ('BOND', 'CD', 'CF', 'LN_BR', 'REPO') THEN ABS(@PL_M_TP_RTCCP01)
			---------------------------------------------------- CRS_CDS ----------------------------------------------------
			WHEN @mxContractType IN ('CDS', 'FDB', 'NDB') THEN ABS(@PL_M_TP_LQTYS1)
			---------------------------------------------------- CRS_FUT ----------------------------------------------------
			WHEN @mxContractType = 'FUT' THEN ABS(@PL_M_TP_LQTY1 * @PL_M_TP_SECLOT)
			---------------------------------------------------- CRS_FXD ----------------------------------------------------
			WHEN @mxContractType = 'FXD' THEN
				CASE
			        WHEN @COM_leg_LEG = 1 THEN ABS(@PL_M_TP_NOMINAL)
			        WHEN @COM_leg_LEG = 2 THEN ABS(@PL_M_TP_QTYEQ)
			    ELSE NULL
			    END
			---------------------------------------------------- CRS_XSW ----------------------------------------------------
			WHEN @mxContractType = 'XSW' THEN
                CASE
                    WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 0) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 1) THEN ABS(@PL_M_TP_NOMINAL) 
                    WHEN (@COM_leg_LEG = 1 AND @PL_M_QTY_INDEX = 1) OR (@COM_leg_LEG = 2 AND @PL_M_QTY_INDEX = 0) THEN ABS(@PL_M_TP_QTYEQ)
			        ELSE NULL
                END
			---------------------------------------------------- CRS_OPT ----------------------------------------------------
            WHEN @mxContractType IN ('OPT','SCF') THEN @PL_M_TP_NOMINAL
	    ELSE NULL
	    END

END
GO