--liquibase formatted sql

--changeSet func:Initial-DWH-get_H_DescendantsByCounterpartId-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.get_H_DescendantsByCounterpartId', 'TF') IS NULL EXEC('CREATE FUNCTION [DWH].[get_H_DescendantsByCounterpartId](@counterpartId numeric(10,0),@reportDate datetime) RETURNS @tab TABLE ([ID] int,[Shortname] varchar(20),[counterpartIdentity] numeric(10,0),[counterpartPath] varchar(MAX),[relationship] varchar(MAX)) AS BEGIN RETURN END')
GO



--changeSet func:Initial-DWH-get_H_DescendantsByCounterpartId-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[get_H_DescendantsByCounterpartId] (  @counterpartId	NUMERIC(10, 0)
														  , @reportDate		DATETIME )
RETURNS @descendants
  TABLE (
			ID					INT				NULL, 
			Shortname			VARCHAR(20)		NULL, 
			counterpartIdentity NUMERIC(10, 0)	NULL,
			counterpartPath		VARCHAR(MAX)	NULL,
			relationship		VARCHAR(MAX)	NULL
		)
AS
  --
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  -- ! R e t u r n s :                   @descendants                TABLE			   Table of descendants to counterpart with 
  -- !																				   counterpartId equal to supplied @counterpartId
  -- !
  -- ! P a r a m e t e r s :             Name                        DataType          Description
  -- !                                   -----------------------     -------------     -----------------------------------------------
  -- !                                   @counterpartId				 NUMERIC(10, 0)    The counterpartId of the counterpart to get 
  -- !																				   descendants for.
  -- !                                   @reportDate                 DATETIME          The date on which the procedure will act.
  -- !
  -- ! O b j e c t i v e :				 Returns a table with all descendants to a counterpart.
  -- !
  -- ! R e v i s i o n   H i s t o r y : Date            Who     What
  -- !                                   ----------      ----    ---------------------------------------------------------------------
  -- !                                   2010-02-24      JoJo    Initial version by JoJo
  -- !
  -- +--------------------------------------------------------------------------------------------------------------------------------+
  --
BEGIN
--
	WITH c(ID, Shortname, counterpartIdentity, counterpartPath, counterpartIDPath, parentCounterpartIDPath, reportDate) 
	  AS (
		SELECT CP.ID, CP.Shortname, CP.counterpartIdentity, ch.counterpartIDPath.ToString() AS counterpartPath, ch.counterpartIDPath, ch.parentCounterpartIDPath, CP.reportDate
		FROM DWH.counterpartHierarchy ch
		INNER JOIN DWH.counterpart cp ON ch._counterpart_ID = cp.ID
		WHERE CP.counterpartIdentity = @counterpartId AND CP.reportDate = @reportDate

		UNION ALL

		SELECT CP.ID, CP.Shortname, CP.counterpartIdentity, ch.counterpartIDPath.ToString() AS counterpartPath, ch.counterpartIDPath, ch.parentCounterpartIDPath, CP.reportDate
		FROM DWH.counterpartHierarchy ch
		INNER JOIN DWH.counterpart cp ON ch._counterpart_ID = cp.ID
		INNER JOIN c ON c.reportDate = CP.reportDate AND c.counterpartIDPath = ch.parentCounterpartIDPath
	)
	INSERT INTO @descendants(ID, Shortname, counterpartIdentity, counterpartPath, relationship)
	SELECT ID, Shortname, counterpartIdentity, counterpartPath, cr.RelationName
	  FROM c
		INNER JOIN [DWH].[LKP_CounterpartRelation] cr ON cr.SameLegalCpy = DWH.has_H_SameLegalCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate)
													 AND cr.SameRiskCpy = DWH.has_H_SameRiskCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate)
	 ORDER BY counterpartIDPath.GetLevel() ASC, counterpartPath ASC;
	  
	RETURN;
--
END

/*
CASE WHEN DWH.has_H_SameLegalCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate) = 1 AND
																		  DWH.has_H_SameRiskCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate) = 1
																	 THEN 'Samma legala entitet'
																	 WHEN DWH.has_H_SameLegalCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate) = 0 AND
																		  DWH.has_H_SameRiskCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate) = 1
																	 THEN 'Samma riskmotpart'
																	 WHEN DWH.has_H_SameLegalCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate) = 0 AND
																		  DWH.has_H_SameRiskCounterpartByCounterpartId(@counterpartId, counterpartIdentity, @reportDate) = 0
																	 THEN 'Ej samma riskmotpart'
																	 ELSE ''
																END AS relationship
*/
GO