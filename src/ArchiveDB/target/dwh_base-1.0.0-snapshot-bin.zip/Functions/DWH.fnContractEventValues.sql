--liquibase formatted sql

--changeSet func:Initial-DWH-fnContractEventValues-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnContractEventValues', 'IF') IS NULL EXEC('CREATE FUNCTION [DWH].[fnContractEventValues](@reportDate date,@extractContext varchar(3)) RETURNS TABLE AS RETURN (SELECT ret = 1)')
GO



--changeSet func:Initial-DWH-fnContractEventValues-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  DWH.fnContractEventValues(@reportDate DATE, @extractContext varchar(3))
RETURNS TABLE
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t         : DWH.fnContractEventValues
  -- ! R e t u r n s       : TABLE
  -- ! P a r a m e t e r s : Name                    DataType       Description
  -- +                       ======================= ============== ==================================================
  -- !                       @reportDate					DATE
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e   : Returns a table with all contractEventValues pivoted to columns
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! S a m p l e s			:
  -- !								select * from DWH.fnContractEventValues('2010-05-03');
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y       :
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !                       Date       Who   What
  -- +                       ========== ===== ========================================================================
  -- !                       2010-10-05 JoJo  Initial version...
  -- +----------------------------------------------------------------------------------------------------------------
AS RETURN
(
	WITH CON AS (
		SELECT C.ID 
		FROM DWH.contract C
        INNER JOIN DWH.loadContext LC ON C._loadContext_ID = LC.ID
		WHERE C.reportDate=@reportDate AND LC.extractContext = @extractContext
)
	SELECT  
		_contract_id		_contract_id,
		_contractType_ID	_contractType_ID,
		evenCurrentBalance	totEventCurrentBalance, 
		eventCapital		totEventCapital,
		eventNewBalance		totEventNewBalance
	FROM 
		(
			SELECT 
				_contract_id,
				_contractType_ID,
				eventValue, 
				valueType
			FROM DWH.contractEventValue cv
				INNER JOIN DWH.LKP_valueType vt on cv._valueType_ID = vt.ID
				INNER JOIN CON ON cv._contract_ID = CON.ID

	) AS p
	PIVOT
	(
		SUM([eventValue])
		FOR valueType IN (evenCurrentBalance, eventCapital, eventNewBalance)
	) AS pvt
)
GO