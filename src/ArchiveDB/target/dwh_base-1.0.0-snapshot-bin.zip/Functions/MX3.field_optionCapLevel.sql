--liquibase formatted sql

--changeSet func:Initial-MX3-field_optionCapLevel-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('MX3.field_optionCapLevel', 'FN') IS NULL EXEC('CREATE FUNCTION [MX3].[field_optionCapLevel](@mxContractType varchar(10),@OP_M_EQ_CAP numeric(28,8)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-MX3-field_optionCapLevel-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER FUNCTION  [MX3].[field_optionCapLevel]
(
	@mxContractType varchar(10), 
	@OP_M_EQ_CAP numeric(28,8)
)
RETURNS numeric(28,8)
AS
BEGIN
	RETURN 
        CASE WHEN @mxContractType IN ('OPT', 'FDB', 'NDB') THEN @OP_M_EQ_CAP
        ELSE NULL
        END
END
GO