--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_SCB2_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_SCB2] ON
INSERT INTO [DWH].[LKP_SCB2] ([ID], [_SCB_ID], [nace2], [nace2Description]) VALUES (1, 10, N'K65', N'')
SET IDENTITY_INSERT [DWH].[LKP_SCB2] OFF
