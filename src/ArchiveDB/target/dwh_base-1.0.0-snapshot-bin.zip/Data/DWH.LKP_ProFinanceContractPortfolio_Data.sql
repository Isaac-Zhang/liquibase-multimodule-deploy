--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_ProFinanceContractPortfolio_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_ProFinanceContractPortfolio] ON
INSERT INTO [DWH].[LKP_ProFinanceContractPortfolio] ([ID], [Contract], [Portfolio], [ValidFrom], [ValidTo]) VALUES (1, N'DEFAULT', N'CUSTFIN', '1900-01-01 00:00:00.000', '2999-12-31 00:00:00.000')
SET IDENTITY_INSERT [DWH].[LKP_ProFinanceContractPortfolio] OFF
