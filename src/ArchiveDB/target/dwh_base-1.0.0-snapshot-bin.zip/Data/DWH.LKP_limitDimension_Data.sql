--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_limitDimension_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_limitDimension] ON
INSERT INTO [DWH].[LKP_limitDimension] ([ID], [limitDimensionName], [description], [modificationDate], [active]) VALUES (1, N'Country', NULL, NULL, NULL)
INSERT INTO [DWH].[LKP_limitDimension] ([ID], [limitDimensionName], [description], [modificationDate], [active]) VALUES (2, N'Counterpart', NULL, NULL, NULL)
INSERT INTO [DWH].[LKP_limitDimension] ([ID], [limitDimensionName], [description], [modificationDate], [active]) VALUES (3, N'Facility', NULL, NULL, NULL)
INSERT INTO [DWH].[LKP_limitDimension] ([ID], [limitDimensionName], [description], [modificationDate], [active]) VALUES (4, N'Warehouse', NULL, NULL, NULL)
INSERT INTO [DWH].[LKP_limitDimension] ([ID], [limitDimensionName], [description], [modificationDate], [active]) VALUES (5, N'Industry', NULL, NULL, NULL)
SET IDENTITY_INSERT [DWH].[LKP_limitDimension] OFF
