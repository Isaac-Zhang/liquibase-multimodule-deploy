--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_amortizationStatus_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_amortizationStatus] ON
INSERT INTO [DWH].[LKP_amortizationStatus] ([ID], [amortizationStatus], [descr], [active]) VALUES (1, N'ACC', N'accepted', 1)
INSERT INTO [DWH].[LKP_amortizationStatus] ([ID], [amortizationStatus], [descr], [active]) VALUES (2, N'OFF', N'offer', 1)
INSERT INTO [DWH].[LKP_amortizationStatus] ([ID], [amortizationStatus], [descr], [active]) VALUES (3, N'OTHER', N'other', 1)
INSERT INTO [DWH].[LKP_amortizationStatus] ([ID], [amortizationStatus], [descr], [active]) VALUES (4, N'PREL', N'preliminary', 1)
SET IDENTITY_INSERT [DWH].[LKP_amortizationStatus] OFF
