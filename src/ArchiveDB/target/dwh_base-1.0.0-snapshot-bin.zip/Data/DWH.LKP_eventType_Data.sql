--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_eventType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_eventType] ON
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (1, N'CD_INITIAL', N'CD_INITIAL', 1, '2012-01-13 15:03:57.637')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (2, N'CD_PAY', N'CD_PAY', 1, '2012-01-13 15:03:57.637')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (3, N'CD_PERIOD', N'CD_PERIOD', 1, '2012-01-13 15:03:57.640')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (4, N'CD_TOTWITH', N'CD_TOTWITH', 1, '2012-01-13 15:03:57.640')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (5, N'instrumentTriggerPut', N'instrumentTriggerPut', 1, '2012-01-13 15:03:57.643')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (6, N'instrumentTriggerCall', N'instrumentTriggerCall', 1, '2012-01-13 15:03:57.643')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (7, N'putCall', N'putcall', 1, '2012-01-13 15:03:57.643')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (8, N'Rates generic event', N'Rates generic event', 1, '2015-04-23 09:53:30.00')
INSERT INTO [DWH].[LKP_eventType] ([ID], [eventType], [description], [active], [modificationDate]) VALUES (9, N'Margin Movement', N'Margin Movement', 1, '2015-04-23 09:53:30.00')
SET IDENTITY_INSERT [DWH].[LKP_eventType] OFF
