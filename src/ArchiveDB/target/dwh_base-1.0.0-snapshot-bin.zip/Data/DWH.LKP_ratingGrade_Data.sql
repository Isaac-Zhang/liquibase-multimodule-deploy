--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_ratingGrade_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_ratingGrade] ON
INSERT INTO [DWH].[LKP_ratingGrade] ([ID], [grade], [notes], [active]) VALUES (10, N'Investment grade', N'Obligations rated ''Aaa'' are judged to be of the highest quality, with minimal credit risk. Obligations rated ''Aa'' are judged to be of high quality and are subject to very low credit risk. Obligations rated ''A'' are considered upper-medium grade and are subject to low credit risk.', 1)
INSERT INTO [DWH].[LKP_ratingGrade] ([ID], [grade], [notes], [active]) VALUES (11, N'Speculative grade', N'Obligations rated ''Baa'' are subject to moderate credit risk. They are considered medium-grade and as such may possess certain speculative characteristics. Obligations rated ''Ba'' are judged to have speculative elements and are subject to substantial credit risk. Obligations rated ''B'' are considered speculative and are subject to high credit risk.', 1)
INSERT INTO [DWH].[LKP_ratingGrade] ([ID], [grade], [notes], [active]) VALUES (12, N'Special', N'Obligations rated ''Caa'' are judged to be of poor standing and are subject to very high credit risk. Obligations rated ''Ca'' are highly speculative and are likely in, or very near, default, with some prospect of recovery of principal and interest. Obligations rated ''C'' are the lowest rated class of bonds and are typically in default, with little prospect for recovery of principal or interest.', 1)
INSERT INTO [DWH].[LKP_ratingGrade] ([ID], [grade], [notes], [active]) VALUES (13, N'N/A', N'Withdrawn Rating / Not Rated / Provisional', 1)
INSERT INTO [DWH].[LKP_ratingGrade] ([ID], [grade], [notes], [active]) VALUES (14, N'Non-investment grade', N'', 1)
SET IDENTITY_INSERT [DWH].[LKP_ratingGrade] OFF
