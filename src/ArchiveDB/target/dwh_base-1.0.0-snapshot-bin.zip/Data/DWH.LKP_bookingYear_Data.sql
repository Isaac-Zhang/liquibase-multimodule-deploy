--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_bookingYear_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (1, N'2001', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (2, N'2002', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (3, N'2003', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (4, N'2004', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (5, N'2005', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (6, N'2006', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (7, N'2007', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (8, N'2008', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (9, N'2009', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (10, N'2010', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (11, N'2011', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (12, N'2012', 1)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (13, N'2013', 0)
INSERT INTO [DWH].[LKP_bookingYear] ([ID], [name], [isLocked]) VALUES (14, N'2014', 0)
