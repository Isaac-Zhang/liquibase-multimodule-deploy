--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_packageStatus_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_packageStatus] ON
INSERT INTO [DWH].[LKP_packageStatus] ([ID], [packageStatus], [description], [active], [modificationDate]) VALUES (1, N'BCHK', NULL, 1, NULL)
INSERT INTO [DWH].[LKP_packageStatus] ([ID], [packageStatus], [description], [active], [modificationDate]) VALUES (2, N'BVER', NULL, 1, NULL)
INSERT INTO [DWH].[LKP_packageStatus] ([ID], [packageStatus], [description], [active], [modificationDate]) VALUES (3, N'MTC', NULL, 1, NULL)
INSERT INTO [DWH].[LKP_packageStatus] ([ID], [packageStatus], [description], [active], [modificationDate]) VALUES (4, N'PEND', NULL, 1, NULL)
INSERT INTO [DWH].[LKP_packageStatus] ([ID], [packageStatus], [description], [active], [modificationDate]) VALUES (5, N'TATV', NULL, 1, NULL)
INSERT INTO [DWH].[LKP_packageStatus] ([ID], [packageStatus], [description], [active], [modificationDate]) VALUES (6, N'TVER', NULL, 1, NULL)
INSERT INTO [DWH].[LKP_packageStatus] ([ID], [packageStatus], [description], [active], [modificationDate]) VALUES (7, N'N/A', NULL, 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_packageStatus] OFF
