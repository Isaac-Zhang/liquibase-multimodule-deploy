--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_packageType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_packageType] ON
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (2, N'ASWP-Credit Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (3, N'ASWP-Equity Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (4, N'ASWP-FX Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (5, N'ASWP-IR Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (6, N'ASWP-Plain Vanilla', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (7, N'CDS-Split', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (8, N'Free Package', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (9, N'FUND- Fx Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (10, N'FUND-Com. Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (11, N'FUND-Credit Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (12, N'FUND-Equity Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (13, N'FUND-Fund Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (14, N'FUND-IR Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (15, N'FUND-Plain Vanilla', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (16, N'FUND-PRDC', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (17, N'FUND-Subordinated', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (18, N'Internal Loan', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (19, N'SWAP-MTM', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (20, N'ASWP-ABS', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (21, N'ASWP-Com. Linked', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (22, N'Collateral', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (23, N'Nostro Transfers', 1, NULL)
INSERT INTO [DWH].[LKP_packageType] ([ID], [packageType], [active], [modificationDate]) VALUES (24, N'N/A', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_packageType] OFF
