--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_PartialAllocation_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_PartialAllocation] ON
INSERT INTO [DWH].[LKP_PartialAllocation] ([ID], [PartialAllocationCode], [Descr], [isPartialAllocated]) VALUES (2, N'ND', N'Not defined', N'N/A')
INSERT INTO [DWH].[LKP_PartialAllocation] ([ID], [PartialAllocationCode], [Descr], [isPartialAllocated]) VALUES (3, N'01', N'Not Allocated', N'No ')
INSERT INTO [DWH].[LKP_PartialAllocation] ([ID], [PartialAllocationCode], [Descr], [isPartialAllocated]) VALUES (4, N'02', N'Allocated', N'Yes')
SET IDENTITY_INSERT [DWH].[LKP_PartialAllocation] OFF
