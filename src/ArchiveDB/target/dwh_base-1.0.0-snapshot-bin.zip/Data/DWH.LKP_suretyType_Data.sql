--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_suretyType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_suretyType] ON
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10027, N'PRI', N'PRI', 1, '2014-09-23 08:53:34.077')
SET IDENTITY_INSERT [DWH].[LKP_suretyType] OFF
SET IDENTITY_INSERT [DWH].[LKP_suretyType] ON
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10000, N'\VRS', N'\VRS', 1, '2011-01-27 13:01:24.890')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10001, N'AVAL', N'AVAL', 1, '2011-01-27 13:01:24.890')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10002, N'AVTL', N'AVTL', 1, '2011-01-27 13:01:24.893')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10003, N'DEPP', N'DEPP', 1, '2011-01-27 13:01:24.893')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10004, N'EFTR', N'EFTR', 1, '2011-01-27 13:01:24.893')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10005, N'EKNG', N'EKNG', 1, '2011-01-27 13:01:24.897')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10006, N'OBLP', N'OBLP', 1, '2011-01-27 13:01:24.897')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10007, N'PROP', N'PROP', 1, '2011-01-27 13:01:24.897')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10008, N'REVE', N'REVE', 1, '2011-01-27 13:01:24.900')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10009, N'RGKG', N'RGKG', 1, '2011-01-27 13:01:24.900')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10010, N'UTLG', N'UTLG', 1, '2011-01-27 13:01:24.900')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10011, N'VXLR', N'VXLR', 1, '2011-01-27 13:01:24.903')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10013, N'GU', N'Guarantee', 1, '2011-01-31 17:15:14.470')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10014, N'RS', N'Risk Share', 1, '2011-01-31 17:15:14.470')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10015, N'CDS', N'CDS', 1, '2011-02-04 13:47:31.847')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10016, N'TRADE1', N'TRADE1', 1, '2011-02-04 13:47:31.847')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10017, N'TRADE2', N'TRADE2', 1, '2011-03-29 10:49:41.900')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10018, N'BOND', N'BOND', 1, '2011-03-29 10:49:54.113')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10019, N'FL', N'FLEL1', 1, '2011-01-31 17:15:14.470')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10020, N'DEMA', N'DEMA', 1, '2012-07-16 15:48:14.793')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10021, N'PANT', N'PANT', 1, '2012-07-16 15:48:14.793')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10022, N'CDS_Standalone', N'CDS_Standalone', 1, '2012-09-11 13:47:31.847')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10023, N'ECAG', N'ECAG', 1, '2012-12-13 04:33:41.857')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10024, N'ONDEMG', N'ONDEMG', 1, '2013-02-21 15:16:34.780')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10025, N'OTHERGUA', N'OTHERGUA', 1, '2013-03-25 07:58:50.077')
INSERT INTO [DWH].[LKP_suretyType] ([ID], [suretyType], [suretyTypeDescription], [active], [modificationDate]) VALUES (10026, N'FORP', N'FORP', 1, '2013-07-04 12:04:28.693')
SET IDENTITY_INSERT [DWH].[LKP_suretyType] OFF
