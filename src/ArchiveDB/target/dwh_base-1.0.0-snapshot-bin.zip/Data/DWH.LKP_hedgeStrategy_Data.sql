--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_hedgeStrategy_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_hedgeStrategy] ON
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (-1, N'N/A')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (1, N'CFH_BDC-IRS')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (2, N'CFH_BD-IRS')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (3, N'FVH-A_BD-ASW')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (4, N'FVH-A_BD-ASW_S')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (5, N'FVH-A_BD-IRS')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (6, N'FVH-F_BD-ASW')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (7, N'FVH-F_BD-ASW_S')
INSERT INTO [DWH].[LKP_hedgeStrategy] ([ID], [strategy]) VALUES (8, N'FVH-F_BD-ASW_S_')
SET IDENTITY_INSERT [DWH].[LKP_hedgeStrategy] OFF
