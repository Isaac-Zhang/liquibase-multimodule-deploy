--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_basel2Method_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_basel2Method] ON
INSERT INTO [DWH].[LKP_basel2Method] ([ID], [shortname], [longname], [descr]) VALUES (1000, N'SCH', N'Schablonmetoden', N'Schablonmetoden')
INSERT INTO [DWH].[LKP_basel2Method] ([ID], [shortname], [longname], [descr]) VALUES (1001, N'IRK', N'Metod för intern riskklassificering (IRK-metoden)', N'Metod för intern riskklassificering (IRK-metoden)')
SET IDENTITY_INSERT [DWH].[LKP_basel2Method] OFF
