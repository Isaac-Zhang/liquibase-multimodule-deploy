--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_optionStandard_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_optionStandard] ON
INSERT INTO [DWH].[LKP_optionStandard] ([ID], [standard], [standardDescription], [active], [modificationDate]) VALUES (1, N'S', N'Standard', 1, NULL)
INSERT INTO [DWH].[LKP_optionStandard] ([ID], [standard], [standardDescription], [active], [modificationDate]) VALUES (2, N'D', N'Digital', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_optionStandard] OFF
