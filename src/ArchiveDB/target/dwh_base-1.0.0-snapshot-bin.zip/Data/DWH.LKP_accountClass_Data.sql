--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_accountClass_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (1, 1, N'Assets')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (2, 2, N'Own capital, allowance and debts')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (3, 3, N'Operating income')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (4, 4, N'Fees/expenses for goods, tangible and certain purchased services')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (5, 4, N'Misc. external operating expenses/fees')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (6, 4, N'Misc. external operating expenses/fees')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (7, 4, N'Fees/expenses for personnel, depreciation etc.')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (8, 4, N'Financial or other income and expenses')
INSERT INTO [DWH].[LKP_accountClass] ([ID], [_accountType_ID], [accountClass]) VALUES (9, 4, N'Internal accounting')
