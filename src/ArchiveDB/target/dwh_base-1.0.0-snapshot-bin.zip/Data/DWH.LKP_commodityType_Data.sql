--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_commodityType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_commodityType] ON
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1000, N'Commodity', N'Råvaror utom ädelmetaller')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1001, N'Equity', N'Aktier')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1002, N'FX', N'Valuta')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1003, N'IR', N'Räntor')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1004, N'Other', N'Annat')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1005, N'Gold', N'Guld')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1006, N'Precious Metals', N'Ädelmetaller förutom guld')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1007, N'Unknown', N'Unknown')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1008, N'N/A', N'Not available')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1009, N'IR0', N'Räntor där PCE inte beräknas')
INSERT INTO [DWH].[LKP_commodityType] ([ID], [commodity], [descr]) VALUES (1010, N'MAP', N'Mappning skall ske från structureType alt. packageType')
SET IDENTITY_INSERT [DWH].[LKP_commodityType] OFF
