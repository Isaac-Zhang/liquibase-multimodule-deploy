--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_swapAgreement_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_swapAgreement] ON
INSERT INTO [DWH].[LKP_swapAgreement] ([ID], [swapAgreementID], [swapAgreementDescription], [active]) VALUES (0, N'0', N'No agreement', 1)
INSERT INTO [DWH].[LKP_swapAgreement] ([ID], [swapAgreementID], [swapAgreementDescription], [active]) VALUES (1, N'1', N'Rating-dependent, SEK matrix', 1)
INSERT INTO [DWH].[LKP_swapAgreement] ([ID], [swapAgreementID], [swapAgreementDescription], [active]) VALUES (2, N'2', N'Rating-dependent, unique matrix', 1)
INSERT INTO [DWH].[LKP_swapAgreement] ([ID], [swapAgreementID], [swapAgreementDescription], [active]) VALUES (3, N'3', N'Fixed threshold amount', 1)
SET IDENTITY_INSERT [DWH].[LKP_swapAgreement] OFF
