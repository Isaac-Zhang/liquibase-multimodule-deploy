--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_payflowStatus_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_payflowStatus] ON
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (1, N'PAID', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (2, N'ACK', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (3, N'CNCL', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (4, N'HOLD', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (5, N'KEEP', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (6, N'LEND', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (7, N'SCNC', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (8, N'SCNL', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (9, N'SENT', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (10, N'WAIT', 1, NULL)
INSERT INTO [DWH].[LKP_payflowStatus] ([ID], [payflowStatus], [active], [modificationDate]) VALUES (11, N'NET', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_payflowStatus] OFF
