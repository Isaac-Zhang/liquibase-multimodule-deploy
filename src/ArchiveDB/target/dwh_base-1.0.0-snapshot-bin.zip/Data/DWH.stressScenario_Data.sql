--liquibase formatted sql

--changeSet chth:Initial-DWH-stressScenario_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[stressScenario] ON
INSERT INTO [DWH].[stressScenario] ([ID], [scenarioName], [createdBy], [description], [doubleDefaultEnabled], [runDaily], [runEndOfMonth], [runEndOfQuarter], [runEndOfYear], [runStartOfMonth], [runStartOfQuarter], [runStartOfYear]) VALUES (-1, N'Default', N'dbo', NULL, 1, 0, 0, 0, 0, 0, 0, 0)
SET IDENTITY_INSERT [DWH].[stressScenario] OFF
