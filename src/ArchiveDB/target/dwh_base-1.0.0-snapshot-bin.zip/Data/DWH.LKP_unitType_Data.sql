--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_unitType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_unitType] ON
INSERT INTO [DWH].[LKP_unitType] ([ID], [unitType], [descr], [active]) VALUES (1, N'Main Function', N'', 0)
INSERT INTO [DWH].[LKP_unitType] ([ID], [unitType], [descr], [active]) VALUES (2, N'Parent Company', N'', 0)
INSERT INTO [DWH].[LKP_unitType] ([ID], [unitType], [descr], [active]) VALUES (3, N'Responsibility Center', N'', 1)
INSERT INTO [DWH].[LKP_unitType] ([ID], [unitType], [descr], [active]) VALUES (4, N'Subsidiary / Sector', N'', 0)
SET IDENTITY_INSERT [DWH].[LKP_unitType] OFF
