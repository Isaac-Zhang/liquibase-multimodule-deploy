--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_numberOfAGroupName_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_numberOfAGroupName] ON
INSERT INTO [DWH].[LKP_numberOfAGroupName] ([ID], [Name], [descr]) VALUES (1, N'MOODY', NULL)
INSERT INTO [DWH].[LKP_numberOfAGroupName] ([ID], [Name], [descr]) VALUES (2, N'SP', NULL)
INSERT INTO [DWH].[LKP_numberOfAGroupName] ([ID], [Name], [descr]) VALUES (3, N'UNIQUE_MATRIX1', NULL)
SET IDENTITY_INSERT [DWH].[LKP_numberOfAGroupName] OFF
