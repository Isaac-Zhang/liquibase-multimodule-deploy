--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_capitalAdequacy_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_capitalAdequacy] ON
INSERT INTO [DWH].[LKP_capitalAdequacy] ([ID], [capitalAdequacyRank], [descr]) VALUES (10, N'A', N'0')
INSERT INTO [DWH].[LKP_capitalAdequacy] ([ID], [capitalAdequacyRank], [descr]) VALUES (11, N'B', N'20')
INSERT INTO [DWH].[LKP_capitalAdequacy] ([ID], [capitalAdequacyRank], [descr]) VALUES (12, N'C', N'50')
INSERT INTO [DWH].[LKP_capitalAdequacy] ([ID], [capitalAdequacyRank], [descr]) VALUES (13, N'D', N'100')
INSERT INTO [DWH].[LKP_capitalAdequacy] ([ID], [capitalAdequacyRank], [descr]) VALUES (14, N'E', N'0')
SET IDENTITY_INSERT [DWH].[LKP_capitalAdequacy] OFF
