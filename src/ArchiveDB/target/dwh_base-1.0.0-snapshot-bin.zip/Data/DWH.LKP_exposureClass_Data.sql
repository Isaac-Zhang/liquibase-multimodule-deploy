--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_exposureClass_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_exposureClass] ON
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1000, N'iABS', N'Positioner i värdepapperisering: Syntetisk värdepapperisering.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1001, N'iABS', N'Positioner i värdepapperisering: Traditionell värdepapperisering.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1002, N'iFTG', N'Företagsexponeringar.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1003, N'iINS', N'Institutsexponeringar.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1004, N'iSTA', N'Statsexponeringar.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1005, N'sABS', N'Positioner i värdepapperisering: Syntetisk värdepapperisering.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1006, N'sABS', N'Positioner i värdepapperisering: Traditionell värdepapperisering.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1007, N'sADM', N'Exponeringar mot administrativa organ, icke kommersiella företag samt trossamfund.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1008, N'sFTG', N'Företagsexponeringar.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1009, N'sINS', N'Institutsexponeringar.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1010, N'sIOR', N'Exponeringar mot internationella organisationer.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1011, N'sKOM', N'Exponeringar mot kommuner och därmed jämförliga samfälligheter samt myndigheter.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1012, N'sMUL', N'Exponeringar mot multilaterala utvecklingsbanker.')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1013, N'sSEC', N'Specialfall: seniority = Secured')
INSERT INTO [DWH].[LKP_exposureClass] ([ID], [shortname], [longname]) VALUES (1014, N'sSTA', N'Exponeringar mot stater och centralbanker')
SET IDENTITY_INSERT [DWH].[LKP_exposureClass] OFF
