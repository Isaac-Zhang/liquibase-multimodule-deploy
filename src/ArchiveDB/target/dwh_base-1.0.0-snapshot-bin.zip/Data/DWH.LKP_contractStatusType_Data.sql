--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_contractStatusType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_contractStatusType] ON
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10000, N'contractStatus', NULL, 1, '2010-10-20 17:15:30.403')
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10001, N'revaluationContractStatus0', NULL, 1, '2010-10-20 17:15:30.407')
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10002, N'revaluationContractStatus1', NULL, 1, '2010-10-20 17:15:30.407')
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10003, N'revaluationContractStatus2', NULL, 1, '2010-10-20 17:15:30.410')
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10004, N'contractStatusStartOfDay', NULL, 1, '2010-10-21 11:31:04.683')
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10005, N'sekContractStatusLevel1', NULL, 1, '2010-11-15 15:49:07.337')
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10006, N'sekContractStatusLevel2', NULL, 1, '2010-11-15 15:49:07.350')
INSERT INTO [DWH].[LKP_contractStatusType] ([ID], [statusType], [description], [active], [modificationDate]) VALUES (10007, N'flowState', NULL, 1, '2010-11-15 15:49:07.350')
SET IDENTITY_INSERT [DWH].[LKP_contractStatusType] OFF
