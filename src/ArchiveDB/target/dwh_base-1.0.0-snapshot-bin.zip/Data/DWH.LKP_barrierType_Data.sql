--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_barrierType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_barrierType] ON
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10012, N'DI', NULL, 1, '2010-11-17 16:20:56.687')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10013, N'DO', NULL, 1, '2010-11-17 16:20:56.687')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10014, N'Down In', NULL, 1, '2010-11-17 16:20:56.687')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10015, N'Down Out', NULL, 1, '2010-11-17 16:20:56.687')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10016, N'Up In', NULL, 1, '2010-11-17 16:20:56.687')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10017, N'Up Out', NULL, 1, '2010-11-17 16:20:56.687')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10018, N'Out', NULL, 1, '2012-07-16 15:48:07.080')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10019, N'KI', NULL, 1, '2012-07-18 12:52:09.217')
INSERT INTO [DWH].[LKP_barrierType] ([ID], [barrierType], [descr], [active], [modificationDate]) VALUES (10020, N'UI', NULL, 1, '2014-06-09 12:19:49.290')
SET IDENTITY_INSERT [DWH].[LKP_barrierType] OFF
