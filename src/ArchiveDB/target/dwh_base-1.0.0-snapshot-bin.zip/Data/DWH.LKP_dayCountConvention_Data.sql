--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_dayCountConvention_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_dayCountConvention] ON
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (1, N'LIN 30/360', N'30/360', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (2, N'LIN 30E/360', N'30E/360', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (3, N'LIN ACT/360', N'Act/360', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (4, N'LIN ACT/360 CDS', N'Act/360', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (5, N'LIN ACT/360-INC', N'Act/360', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (6, N'LIN ACT/365', N'Act/365', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (7, N'LIN ACT/365F', N'Act/365F', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (8, N'LIN ACT/ACT', N'Act/Act', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (9, N'LIN ACT/ACT IC', N'Act/Act', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (10, N'LIN ACT/ACT ICM', N'Act/Act', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (11, N'LIN ACT/ACT ISD', N'Act/ActISDA', 1, '2012-07-16')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (13, N'LIN NL/365 XTR', N'Act/365', 1, '2012-08-21')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (14, N'LIN ACT/365L', N'Act/365', 1, '2012-08-21')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (15, N'LIN 30/360-ISMA', N'30/360', 1, '2012-10-13')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (16, N'365/ACTUAL', N'Act/365', 1, '2013-06-12')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (17, N'365/66/ACT', N'Act/ActNew', 1, '2013-06-12')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (18, N'365/30', N'30/365', 1, '2013-06-12')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (19, N'365/366/30', N'30/ActNew', 1, '2013-06-12')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (20, N'360/ACTUAL', N'Act/360', 1, '2013-06-12')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (21, N'360/30', N'Act/360', 1, '2013-06-12')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (22, N'MANUAL', N'MANUAL', 1, '2013-06-12')
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (23, N'365/366/ACT', N'Act/ActNew', 1, '2013-06-12')
SET IDENTITY_INSERT [DWH].[LKP_dayCountConvention] OFF
SET IDENTITY_INSERT [DWH].[LKP_dayCountConvention] ON
INSERT INTO [DWH].[LKP_dayCountConvention] ([ID], [Name], [ODVName], [active], [modificationDate]) VALUES (12, N'LIN ACT/ACT ISM', N'Act/Act', 1, '2012-07-16')
SET IDENTITY_INSERT [DWH].[LKP_dayCountConvention] OFF
