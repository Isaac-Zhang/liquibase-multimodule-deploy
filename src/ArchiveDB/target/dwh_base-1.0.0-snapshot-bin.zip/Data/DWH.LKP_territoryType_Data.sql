--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_territoryType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_territoryType] ON
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (9, N'IR', N'Internal region', 1)
SET IDENTITY_INSERT [DWH].[LKP_territoryType] OFF
SET IDENTITY_INSERT [DWH].[LKP_territoryType] ON
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (1, N'COU', N'Country', 1)
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (2, N'CNT', N'Continent', 1)
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (3, N'RSK', N'Risk Zone', 1)
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (4, N'DR', N'Domestic region', 1)
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (5, N'GR', N'Geographic region', 1)
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (6, N'ER', N'Economic region', 1)
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (7, N'WR', N'World', 1)
INSERT INTO [DWH].[LKP_territoryType] ([ID], [territoryType], [descr], [active]) VALUES (8, N'RK3', N'Risk zone according to pillar 3', 1)
SET IDENTITY_INSERT [DWH].[LKP_territoryType] OFF
