--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_reportingEntity_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_reportingEntity] ON
INSERT INTO [DWH].[LKP_reportingEntity] ([ID], [reportingEntity], [reportingEntityDescription], [orgNumber], [FIInstituteNumber]) VALUES (1000, N'SEK GROUP', N'AB Svensk exportkredit–gruppen', N'999999-9999', N'33502')
INSERT INTO [DWH].[LKP_reportingEntity] ([ID], [reportingEntity], [reportingEntityDescription], [orgNumber], [FIInstituteNumber]) VALUES (1001, N'SEK AB', N'AB Svensk exportkredit', N'556084-0315', N'33006')
INSERT INTO [DWH].[LKP_reportingEntity] ([ID], [reportingEntity], [reportingEntityDescription], [orgNumber], [FIInstituteNumber]) VALUES (1002, N'SEK SEC', N'AB SEK Securities', N'556608-8885', NULL)
SET IDENTITY_INSERT [DWH].[LKP_reportingEntity] OFF
