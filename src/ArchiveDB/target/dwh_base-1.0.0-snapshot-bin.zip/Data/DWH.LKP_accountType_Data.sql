--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_accountType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
INSERT INTO [DWH].[LKP_accountType] ([ID], [accountType]) VALUES (1, N'Assets')
INSERT INTO [DWH].[LKP_accountType] ([ID], [accountType]) VALUES (2, N'Liabilities')
INSERT INTO [DWH].[LKP_accountType] ([ID], [accountType]) VALUES (3, N'Revenues')
INSERT INTO [DWH].[LKP_accountType] ([ID], [accountType]) VALUES (4, N'Expenses')
