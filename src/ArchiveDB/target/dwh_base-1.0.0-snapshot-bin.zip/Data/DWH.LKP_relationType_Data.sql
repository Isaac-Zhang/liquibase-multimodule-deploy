--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_relationType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_relationType] ON
INSERT INTO [DWH].[LKP_relationType] ([ID], [relationType], [descr], [active]) VALUES (2, N'CentralCounterpart', N'', 1)
SET IDENTITY_INSERT [DWH].[LKP_relationType] OFF
SET IDENTITY_INSERT [DWH].[LKP_relationType] ON
INSERT INTO [DWH].[LKP_relationType] ([ID], [relationType], [descr], [active]) VALUES (1, N'CollateralAgreementGarantor', N'', 1)
SET IDENTITY_INSERT [DWH].[LKP_relationType] OFF
