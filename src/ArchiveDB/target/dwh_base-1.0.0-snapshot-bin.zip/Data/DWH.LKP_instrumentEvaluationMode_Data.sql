--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_instrumentEvaluationMode_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_instrumentEvaluationMode] ON
INSERT INTO [DWH].[LKP_instrumentEvaluationMode] ([ID], [evaluationModeID], [evaluationMode], [active], [modificationDate]) VALUES (2, 0, N'Mark To Market', 1, NULL)
INSERT INTO [DWH].[LKP_instrumentEvaluationMode] ([ID], [evaluationModeID], [evaluationMode], [active], [modificationDate]) VALUES (5, 2, N'Zero Coupon Curve', 1, NULL)
INSERT INTO [DWH].[LKP_instrumentEvaluationMode] ([ID], [evaluationModeID], [evaluationMode], [active], [modificationDate]) VALUES (7, 4, N'Credit Curve Based', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_instrumentEvaluationMode] OFF
