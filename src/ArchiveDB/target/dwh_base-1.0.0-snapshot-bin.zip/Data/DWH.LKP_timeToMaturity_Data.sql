--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_timeToMaturity_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_timeToMaturity] ON
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (1, 0.50, N'6M')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (2, 1.00, N'1Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (3, 2.00, N'2Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (4, 3.00, N'3Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (5, 5.00, N'5Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (6, 7.00, N'7Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (7, 10.00, N'10Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (8, 15.00, N'15Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (9, 20.00, N'20Y')
INSERT INTO [DWH].[LKP_timeToMaturity] ([ID], [timeToMaturity], [label]) VALUES (10, 30.00, N'30Y')
SET IDENTITY_INSERT [DWH].[LKP_timeToMaturity] OFF
