--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_barrierWindowStyle_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_barrierWindowStyle] ON
INSERT INTO [DWH].[LKP_barrierWindowStyle] ([ID], [style], [descr], [active], [modificationDate]) VALUES (10004, N'A', NULL, 1, '2010-11-17 16:20:56.853')
INSERT INTO [DWH].[LKP_barrierWindowStyle] ([ID], [style], [descr], [active], [modificationDate]) VALUES (10005, N'E', NULL, 1, '2010-11-17 16:20:56.853')
SET IDENTITY_INSERT [DWH].[LKP_barrierWindowStyle] OFF
