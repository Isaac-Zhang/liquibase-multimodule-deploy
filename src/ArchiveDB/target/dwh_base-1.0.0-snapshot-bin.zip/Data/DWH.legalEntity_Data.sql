--liquibase formatted sql

--changeSet chth:Initial-DWH-legalEntity_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[legalEntity] ON
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (1, N'KONC', N'Elimination', N'556084-0315')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (2, N'SEK', N'SEK', N'556084-0315')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (3, N'SEKS', N'S-System', N'556084-0315')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (4, N'SUB1', N'Sektionen', N'556121-0252')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (5, N'SUB2', N'SEK securities', N'556608-8885')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (6, N'SUB3', N'SEK Financial Advisors AB', N'556660-2420')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (7, N'SUB4', N'SEK Financial Services AB', N'556683-3462')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (8, N'SUB5', N'SEK Customer Finance', N'556726-7587')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (9, N'SUB6', N'Venantius AB', N'556449-5116')
INSERT INTO [DWH].[legalEntity] ([ID], [entityCode], [entityName], [orgNumber]) VALUES (10, N'SUB7', N'SEK Exportlånet AB', N'003191-9061')
SET IDENTITY_INSERT [DWH].[legalEntity] OFF
