--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_productGroup_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_productGroup] ON
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (1, N'00000000', N'Credit Derivatives')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (2, N'00000001', N'Derivatives')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (3, N'00000002', N'Fees')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (4, N'00000003', N'Fx spot')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (5, N'00000004', N'Loan')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (6, N'00000005', N'Securities')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (7, N'00000006', N'Internal')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (8, N'00000007', N'Collateral')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (9, N'00000008', N'Guarantee')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (10, N'00000009', N'General Lending')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (11, N'00000010', N'Export Leasing')
INSERT INTO [DWH].[LKP_productGroup] ([ID], [productGroupCode], [productGroupName]) VALUES (12, N'00000011', N'Depo Borrower SEK')
SET IDENTITY_INSERT [DWH].[LKP_productGroup] OFF
