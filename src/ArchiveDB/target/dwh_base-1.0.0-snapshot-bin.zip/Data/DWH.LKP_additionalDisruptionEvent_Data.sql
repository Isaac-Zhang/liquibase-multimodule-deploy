--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_additionalDisruptionEvent_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_additionalDisruptionEvent] ON
INSERT INTO [DWH].[LKP_additionalDisruptionEvent] ([ID], [additionalDisruptionEvent]) VALUES (1, N'Failure to Deliver')
INSERT INTO [DWH].[LKP_additionalDisruptionEvent] ([ID], [additionalDisruptionEvent]) VALUES (2, N'Price Adjustment')
INSERT INTO [DWH].[LKP_additionalDisruptionEvent] ([ID], [additionalDisruptionEvent]) VALUES (3, N'Hedging Disruption')
INSERT INTO [DWH].[LKP_additionalDisruptionEvent] ([ID], [additionalDisruptionEvent]) VALUES (4, N'Loss of Stock Borrow')
INSERT INTO [DWH].[LKP_additionalDisruptionEvent] ([ID], [additionalDisruptionEvent]) VALUES (5, N'Increased Cost of Stock Borrow')
INSERT INTO [DWH].[LKP_additionalDisruptionEvent] ([ID], [additionalDisruptionEvent]) VALUES (6, N'Increased Cost of Hedging')
INSERT INTO [DWH].[LKP_additionalDisruptionEvent] ([ID], [additionalDisruptionEvent]) VALUES (7, N'Other')
SET IDENTITY_INSERT [DWH].[LKP_additionalDisruptionEvent] OFF
