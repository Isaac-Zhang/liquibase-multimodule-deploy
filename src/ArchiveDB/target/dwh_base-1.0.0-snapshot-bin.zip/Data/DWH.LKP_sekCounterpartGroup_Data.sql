--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_sekCounterpartGroup_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_sekCounterpartGroup] ON
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (1, N'CRED_INS', N'121000-125300,128100-128300,129300,129400,131400,212100,999999', N'reportRow')
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (2, N'PUBLIC', N'111000-114000,125400-127000,129100,129200,131110-131323,141000-211200,212200,220000', N'reportRow')
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (3, N'Central Banks', N'121000,212100', N'FINREP')
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (4, N'General Governements', N'131110,131130-131400,211100-211200,212200-220000', N'FINREP')
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (5, N'Credit institutions', N'122100-122200,131120,999999', N'FINREP')
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (6, N'Other financial corporations', N'122300-129400', N'FINREP')
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (7, N'Non-financial corporations', N'111000-114000', N'FINREP')
INSERT INTO [DWH].[LKP_sekCounterpartGroup] ([ID], [sekCounterpartGroup], [sekSectorRange], [counterpartGroupType]) VALUES (8, N'Households', N'141000-152200', N'FINREP')
SET IDENTITY_INSERT [DWH].[LKP_sekCounterpartGroup] OFF


