--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_creditQuality_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_creditQuality] ON
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1001, 1)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1002, 2)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1003, 3)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1004, 4)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1005, 5)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1006, 6)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1007, 7)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1008, 8)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1009, 9)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1010, 10)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1011, 11)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1012, 12)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1013, 13)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1014, 14)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1015, 15)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1016, 16)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1017, 17)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1018, 18)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1019, 19)
INSERT INTO [DWH].[LKP_creditQuality] ([ID], [creditQualityStep]) VALUES (1099, 99)
SET IDENTITY_INSERT [DWH].[LKP_creditQuality] OFF
