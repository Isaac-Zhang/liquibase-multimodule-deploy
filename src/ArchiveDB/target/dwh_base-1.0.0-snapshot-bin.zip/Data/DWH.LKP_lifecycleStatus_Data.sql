--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_lifecycleStatus_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_lifecycleStatus] ON
INSERT INTO [DWH].[LKP_lifecycleStatus] ([ID], [lifecycleStatusID], [lifecycleStatus], [description], [active], [modificationDate]) VALUES (10000, 0, N'live', N'The lifecyclestatus of the counterpart is live', 1, '2010-10-07 14:39:07.387')
INSERT INTO [DWH].[LKP_lifecycleStatus] ([ID], [lifecycleStatusID], [lifecycleStatus], [description], [active], [modificationDate]) VALUES (10001, 1, N'suspended', N'The lifecyclestatus of the counterpart is suspended', 1, '2010-10-07 14:39:07.403')
INSERT INTO [DWH].[LKP_lifecycleStatus] ([ID], [lifecycleStatusID], [lifecycleStatus], [description], [active], [modificationDate]) VALUES (10002, 2, N'dead', N'The lifecyclestatus of the counterpart is dead', 1, '2010-10-07 14:39:07.403')
SET IDENTITY_INSERT [DWH].[LKP_lifecycleStatus] OFF
