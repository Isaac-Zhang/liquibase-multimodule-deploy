--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_granularity_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_granularity] ON
INSERT INTO [DWH].[LKP_granularity] ([ID], [granularity], [active], [modificationDate]) VALUES (1, N'Granular', 1, NULL)
INSERT INTO [DWH].[LKP_granularity] ([ID], [granularity], [active], [modificationDate]) VALUES (2, N'Not Granular', 1, NULL)
INSERT INTO [DWH].[LKP_granularity] ([ID], [granularity], [active], [modificationDate]) VALUES (3, N'N/A', 1, NULL)
INSERT INTO [DWH].[LKP_granularity] ([ID], [granularity], [active], [modificationDate]) VALUES (4, N'ReSec RW E', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_granularity] OFF
