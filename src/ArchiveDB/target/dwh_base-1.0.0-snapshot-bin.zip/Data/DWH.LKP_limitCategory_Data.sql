--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_limitCategory_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_limitCategory] ON
INSERT INTO [DWH].[LKP_limitCategory] ([ID], [name]) VALUES (3, N'large exposure')
SET IDENTITY_INSERT [DWH].[LKP_limitCategory] OFF
SET IDENTITY_INSERT [DWH].[LKP_limitCategory] ON
INSERT INTO [DWH].[LKP_limitCategory] ([ID], [name]) VALUES (1, N'allocated')
INSERT INTO [DWH].[LKP_limitCategory] ([ID], [name]) VALUES (2, N'reallocated')
SET IDENTITY_INSERT [DWH].[LKP_limitCategory] OFF
