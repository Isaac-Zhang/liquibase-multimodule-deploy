--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_limitList_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_limitList] ON
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (13, N'5_Partial', N'Partial', '2013-02-20 07:29:56.393', 1)
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (14, N'6_PartialCDS', N'Partial', '2013-02-20 07:29:56.710', 1)
SET IDENTITY_INSERT [DWH].[LKP_limitList] OFF
SET IDENTITY_INSERT [DWH].[LKP_limitList] ON
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (7, N'0_Total', N'TODO -some description', '2010-11-17 10:46:20.427', 1)
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (8, N'1_Unilateral', N'TODO -some description', '2010-11-17 10:46:20.427', 1)
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (9, N'2_Multilateral', N'TODO -some description', '2010-11-17 10:46:20.427', 1)
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (10, N'3_MultilateralCDS', N'TODO -some description', '2010-11-17 10:46:20.427', 1)
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (11, N'N/A', N'Country limit', '2010-11-17 10:46:20.427', 1)
INSERT INTO [DWH].[LKP_limitList] ([ID], [limitListName], [description], [modificationDate], [active]) VALUES (12, N'4_Derivatives', NULL, '2012-01-16 13:15:23.410', 1)
SET IDENTITY_INSERT [DWH].[LKP_limitList] OFF
