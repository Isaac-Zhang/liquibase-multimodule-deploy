--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_knowYourCustomerClass_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_knowYourCustomerClass] ON
INSERT INTO [DWH].[LKP_knowYourCustomerClass] ([ID], [knowYourCustomerClass], [active], [modificationDate]) VALUES (0, N'No KYC', 1, '2010-10-13 12:39:45.620')
INSERT INTO [DWH].[LKP_knowYourCustomerClass] ([ID], [knowYourCustomerClass], [active], [modificationDate]) VALUES (1, N'Simplified KYC', 1, '2010-10-13 12:39:45.620')
INSERT INTO [DWH].[LKP_knowYourCustomerClass] ([ID], [knowYourCustomerClass], [active], [modificationDate]) VALUES (2, N'Standard KYC', 1, '2010-10-13 12:39:45.620')
INSERT INTO [DWH].[LKP_knowYourCustomerClass] ([ID], [knowYourCustomerClass], [active], [modificationDate]) VALUES (3, N'Enhanced KYC', 1, '2010-10-13 12:39:45.620')
SET IDENTITY_INSERT [DWH].[LKP_knowYourCustomerClass] OFF
