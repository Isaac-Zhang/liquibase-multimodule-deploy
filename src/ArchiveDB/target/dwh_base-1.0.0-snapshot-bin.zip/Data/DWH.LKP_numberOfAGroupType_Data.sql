--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_numberOfAGroupType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_numberOfAGroupType] ON
INSERT INTO [DWH].[LKP_numberOfAGroupType] ([ID], [name], [descr]) VALUES (1, N'NumberOfA', NULL)
INSERT INTO [DWH].[LKP_numberOfAGroupType] ([ID], [name], [descr]) VALUES (2, N'NumberOfASpread', NULL)
SET IDENTITY_INSERT [DWH].[LKP_numberOfAGroupType] OFF
