--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_hedgeTradeType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
INSERT INTO [DWH].[LKP_hedgeTradeType] ([ID], [hedgeTradeType]) VALUES (1, N'Hedged')
INSERT INTO [DWH].[LKP_hedgeTradeType] ([ID], [hedgeTradeType]) VALUES (2, N'Hedging')
INSERT INTO [DWH].[LKP_hedgeTradeType] ([ID], [hedgeTradeType]) VALUES (3, N'Theoretical')
