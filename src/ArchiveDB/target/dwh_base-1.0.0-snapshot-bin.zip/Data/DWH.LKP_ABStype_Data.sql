--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_ABStype_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_ABStype] ON
INSERT INTO [DWH].[LKP_ABStype] ([ID], [ABStype], [active], [modificationDate]) VALUES (10, N'Synthetic', 1, NULL)
INSERT INTO [DWH].[LKP_ABStype] ([ID], [ABStype], [active], [modificationDate]) VALUES (11, N'Traditional', 1, NULL)
INSERT INTO [DWH].[LKP_ABStype] ([ID], [ABStype], [active], [modificationDate]) VALUES (12, N'N/A', 1, NULL)
INSERT INTO [DWH].[LKP_ABStype] ([ID], [ABStype], [active], [modificationDate]) VALUES (13, N'Granular', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_ABStype] OFF
