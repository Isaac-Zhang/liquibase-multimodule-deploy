--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_hedgeType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_hedgeType] ON
INSERT INTO [DWH].[LKP_hedgeType] ([ID], [hedgeType], [descr]) VALUES (1, 1, N'Fair Value')
INSERT INTO [DWH].[LKP_hedgeType] ([ID], [hedgeType], [descr]) VALUES (2, 2, N'Cash Flow')
SET IDENTITY_INSERT [DWH].[LKP_hedgeType] OFF
