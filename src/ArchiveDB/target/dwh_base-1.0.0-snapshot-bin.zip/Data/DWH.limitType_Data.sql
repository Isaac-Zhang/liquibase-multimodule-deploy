--liquibase formatted sql

--changeSet chth:Initial-DWH-limitType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[limitType] ON
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (16, 1, 13, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (17, 2, 13, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (18, 1, 14, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (19, 2, 14, 2)
SET IDENTITY_INSERT [DWH].[limitType] OFF
SET IDENTITY_INSERT [DWH].[limitType] ON
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (1, 1, 7, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (2, 2, 7, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (3, 1, 8, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (4, 2, 8, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (5, 1, 9, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (6, 2, 9, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (7, 1, 10, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (8, 2, 10, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (9, 4, 11, 1)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (10, 3, 11, 3)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (11, 3, 11, 3)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (12, 3, 11, 3)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (13, 1, 12, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (14, 2, 12, 2)
INSERT INTO [DWH].[limitType] ([ID], [_limitRiskType_ID], [_limitList_ID], [_limitDimension_ID]) VALUES (15, 5, 11, 5)
SET IDENTITY_INSERT [DWH].[limitType] OFF
