--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_marketDataType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_marketDataType] ON
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (1, N'FXSWAP')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (2, N'CCYPAIR')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (3, N'CREDIT')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (4, N'FIXING')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (5, N'FXFIXING')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (6, N'IRFIXING')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (7, N'RATES')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (8, N'FUTURE')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (9, N'BOND')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (10, N'EQUITY')
INSERT INTO [DWH].[LKP_marketDataType] ([ID], [marketDataType]) VALUES (11, N'SECURITY')
SET IDENTITY_INSERT [DWH].[LKP_marketDataType] OFF
