--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_ratingOrganization_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_ratingOrganization] ON
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (10, N'SEK Internal Rating', 1, NULL)
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (11, N'Standard & Poors', 1, NULL)
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (12, N'Moodys', 1, NULL)
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (13, N'Calculated Rating', 1, NULL)
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (14, N'Secured Rating', 1, NULL)
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (15, N'Other Rating', 1, NULL)
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (16, N'Fitch', 1, NULL)
INSERT INTO [DWH].[LKP_ratingOrganization] ([ID], [organization], [active], [descr]) VALUES (17, N'ALMI', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_ratingOrganization] OFF
