--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_swapStatus_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_swapStatus] ON
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (22, N'LTM COMPLETE LATE', NULL, 1, '2014-09-23 08:53:13.263')
SET IDENTITY_INSERT [DWH].[LKP_swapStatus] OFF
SET IDENTITY_INSERT [DWH].[LKP_swapStatus] ON
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (7, N'AWAITING AMENDED CONF', NULL, 1, '2010-09-09 14:03:32.767')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (8, N'CURRENTLY CHECKING', NULL, 1, '2010-09-09 14:03:32.767')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (9, N'LTM - COMPLETE', NULL, 1, '2010-09-09 14:03:32.767')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (10, N'LTM - COMPLETE / MOP', NULL, 1, '2010-09-09 14:03:32.767')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (11, N'NO CONF HAS ARRIVED', NULL, 1, '2010-09-09 14:03:32.767')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (12, N'SEK REVIEW', NULL, 1, '2010-09-09 14:03:32.767')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (13, N'FOR SIGNING', NULL, 1, '2010-11-11 08:52:31.480')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (14, N'DRAFT OK', NULL, 1, '2010-12-23 10:48:17.253')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (15, N'AWAITING AMENDED', NULL, 1, '2012-07-16 15:47:57.723')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (16, N'LTM COMPLETE', NULL, 1, '2012-07-16 15:47:57.723')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (17, N'MOP', NULL, 1, '2012-07-16 15:47:57.723')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (18, N'LTM - MOP', NULL, 1, '2012-09-22 00:26:52.447')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (19, N'ECOMPLETE', NULL, 1, '2013-04-18 13:24:46.003')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (20, N'ELECTRONIC COMPLETE', NULL, 1, '2013-10-03 17:03:47.893')
INSERT INTO [DWH].[LKP_swapStatus] ([ID], [statusName], [descr], [active], [modificationDate]) VALUES (21, N'GIVEN FOR SIGNATURE', NULL, 1, '2013-10-31 17:39:58.393')
SET IDENTITY_INSERT [DWH].[LKP_swapStatus] OFF
