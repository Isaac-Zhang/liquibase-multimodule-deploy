--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_internalSector_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_internalSector] ON
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (1, N'Energy')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (2, N'Telecom & IT')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (3, N'Pulp & Paper')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (4, N'Materials')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (5, N'Auto')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (6, N'Shipping')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (7, N'Construction')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (8, N'Industrials')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (9, N'Consumer')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (10, N'Financials')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (11, N'Health Care')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (12, N'ABS')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (13, N'Sovereign')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (14, N'Other')
INSERT INTO [DWH].[LKP_internalSector] ([ID], [internalSectorName]) VALUES (15, N'Övrigt')
SET IDENTITY_INSERT [DWH].[LKP_internalSector] OFF
