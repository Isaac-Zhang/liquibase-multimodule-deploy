--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_limitRiskType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_limitRiskType] ON
INSERT INTO [DWH].[LKP_limitRiskType] ([ID], [limitRiskTypeName], [limitLevel], [description], [modificationDate], [active]) VALUES (1, N'CreditRiskExposure_E', N'Entity', N'TODO -some description', '2010-11-16 11:36:31.950', 1)
INSERT INTO [DWH].[LKP_limitRiskType] ([ID], [limitRiskTypeName], [limitLevel], [description], [modificationDate], [active]) VALUES (2, N'CreditRiskExposure_G', N'Group', N'TODO -some description', '2010-11-16 11:36:31.950', 1)
INSERT INTO [DWH].[LKP_limitRiskType] ([ID], [limitRiskTypeName], [limitLevel], [description], [modificationDate], [active]) VALUES (3, N'Facility_Risk_Exposu', N'Facility', N'Facility', '2010-11-16 12:17:29.960', 1)
INSERT INTO [DWH].[LKP_limitRiskType] ([ID], [limitRiskTypeName], [limitLevel], [description], [modificationDate], [active]) VALUES (4, N'Country_Risk_Exposur', N'Country', N'Country', '2010-11-17 12:19:13.200', 1)
INSERT INTO [DWH].[LKP_limitRiskType] ([ID], [limitRiskTypeName], [limitLevel], [description], [modificationDate], [active]) VALUES (5, N'Industry_Risk_Exposu', N'Industry', N'Industry', '2010-11-17 12:19:13.200', 1)
SET IDENTITY_INSERT [DWH].[LKP_limitRiskType] OFF
