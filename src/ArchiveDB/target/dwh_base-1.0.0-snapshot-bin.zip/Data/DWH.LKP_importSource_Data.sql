--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_importSource_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (0, N'GWB', N'GWB')
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (1, N'MXG', N'MXG')
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (2, N'CALC', N'Calculated')
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (3, N'PRF', N'ProFinance')
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (5, N'ACBS', N'ACBS')
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (6, N'ACBS', N'ACBS')
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (7, N'XOR', N'XOR')
INSERT INTO [DWH].[LKP_importSource] ([ID], [shortName], [longName]) VALUES (99, N'CORR', N'Correction')
