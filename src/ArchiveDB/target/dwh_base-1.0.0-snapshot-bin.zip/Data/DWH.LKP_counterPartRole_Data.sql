--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_counterPartRole_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_counterPartRole] ON
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (26, N'Agent IPA', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (27, N'Master', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (28, N'Physical', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (29, N'Related', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (30, N'CDS', NULL, 1)
SET IDENTITY_INSERT [DWH].[LKP_counterPartRole] OFF
SET IDENTITY_INSERT [DWH].[LKP_counterPartRole] ON
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (1, N'Obligor', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (2, N'Issuer', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (3, N'Guarantor', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (4, N'ContractCounterPart', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (5, N'RiskCounterPart', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (6, N'CreditCoveredCounterpart', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (7, N'Broker', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (8, N'Agent', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (9, N'Distributor', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (10, N'BondLeadManager1', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (11, N'BondLeadManager2', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (12, N'BondLeadManager3', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (13, N'BondLeadManager4', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (14, N'Clearer', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (15, N'Buyer', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (16, N'Exchange', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (17, N'Seller', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (18, N'Exporter', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (19, N'Borrower', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (20, N'Lender', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (21, N'SwapCounterpart', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (22, N'FeeCounterpart', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (23, N'ClearingBroker', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (24, N'ExecutingBroker', NULL, 1)
INSERT INTO [DWH].[LKP_counterPartRole] ([ID], [roleName], [descr], [Active]) VALUES (25, N'CentralCounterpart', NULL, 1)
SET IDENTITY_INSERT [DWH].[LKP_counterPartRole] OFF
