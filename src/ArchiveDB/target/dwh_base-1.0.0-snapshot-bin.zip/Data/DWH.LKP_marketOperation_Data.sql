--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_marketOperation_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_marketOperation] ON
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10008, N'-1', N'TRDEVENTS', N'For IRT context, call deposits', 1, '2013-04-26 13:22:04.820')
SET IDENTITY_INSERT [DWH].[LKP_marketOperation] OFF
SET IDENTITY_INSERT [DWH].[LKP_marketOperation] ON
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10000, N'0', N'', N'No market operation', 1, '2010-10-12 13:22:04.820')
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10001, N'2', N'EXP', N'Expiry', 1, '2010-10-12 13:22:04.820')
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10002, N'1', N'EXR', N'Exercise', 1, '2010-10-12 13:22:04.820')
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10003, N'4', N'NET', N'Netting or close-out', 1, '2010-10-12 13:22:04.820')
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10004, N'5', N'RPL', N'Restructure', 1, '2010-10-12 13:22:04.820')
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10005, N'7', N'RPL_D', N'Trade cancellation', 1, '2010-10-12 13:22:04.820')
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10006, N'6', N'RPL_M', N'Cancel and reissue', 1, '2010-10-12 13:22:04.820')
INSERT INTO [DWH].[LKP_marketOperation] ([ID], [marketOperationID], [marketOperation], [descr], [active], [modificationDate]) VALUES (10007, N'3', N'XIT', N'Early termination', 1, '2010-10-12 13:22:04.820')
SET IDENTITY_INSERT [DWH].[LKP_marketOperation] OFF
