--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_SCB_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_SCB] ON
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (1, N'A', N'Jordbruk, skogsbruk och fiske', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (2, N'B', N'Utvinning av mineral', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (3, N'C', N'Tillverkning', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (4, N'D', N'Försörjning av el, gas, värme och kyla', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (5, N'E', N'Vattenförsörjning, avloppsrening, avfallshantering', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (6, N'F', N'Byggverksamhet', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (7, N'H', N'Transport och magasinering', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (8, N'J', N'Informations- och kommunikationsverksamhet', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (9, N'I', N'Hotell- och restaurangverksamhet', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (10, N'K', N'Finans- och försäkringsverksamhet', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (11, N'L', N'Fastighetsverksamhet', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (12, N'M', N'Verksamhet inom juridik, ekonomi och vetenskap', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (13, N'N', N'Uthyrning, fastighetsservice, och resetjänster', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (14, N'O', N'Offentlig förvaltning och försvar', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (15, N'P', N'Utbildning', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (16, N'Q', N'Vård och omsorg, sociala tjänster', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (17, N'G', N'Handel, reparation av motorfordon och motorcyklar', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (18, N'Z', N'Ej angiven', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (20, N'R', N'Kultur, nöje och fritid', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (21, N'S', N'Annan serviceverksamhet', 1, NULL)
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (22, N'T', N'Försvarsarbete i hushåll', 1, '2010-06-04 08:45:29.117')
INSERT INTO [DWH].[LKP_SCB] ([ID], [branch], [name], [active], [modificationDate]) VALUES (23, N'U', N'Verksamhet vid internationella organisationer', 1, '2010-06-04 08:45:29.117')
SET IDENTITY_INSERT [DWH].[LKP_SCB] OFF
