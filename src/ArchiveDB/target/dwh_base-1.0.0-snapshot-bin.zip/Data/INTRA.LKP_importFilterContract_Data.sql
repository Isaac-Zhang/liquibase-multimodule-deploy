--liquibase formatted sql

--changeSet chth:Initial-INTRA-LKP_importFilterContract_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [INTRA].[LKP_importFilterContract] ON
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (1, 1, N'IRD', N'ASWP', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (2, 1, N'IRD', N'CS', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (3, 1, N'IRD', N'IRS', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (4, 1, N'IRD', N'FRA', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (5, 1, N'IRD', N'SFUT', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (6, 1, N'IRD', N'CF', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (7, 1, N'CRD', N'CDS', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (8, 1, N'IRD', N'BOND', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (9, 1, N'CURR', N'FXD', N'FXD', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (10, 1, N'CURR', N'FXD', N'XSW', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (11, 1, N'IRD', N'BOND', N'CALL', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (12, 1, N'CURR', N'FXD', N'FXDS', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (13, 1, N'IRD', N'CD', N'', 1)
INSERT INTO [INTRA].[LKP_importFilterContract] ([ID], [sourceSystem], [contractFamily], [contractGroup], [contractType], [valid]) VALUES (14, 1, N'IRD', N'LN_BR', N'', 1)
SET IDENTITY_INSERT [INTRA].[LKP_importFilterContract] OFF
