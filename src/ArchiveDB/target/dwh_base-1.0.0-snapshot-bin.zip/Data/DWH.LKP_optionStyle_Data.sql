--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_optionStyle_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_optionStyle] ON
INSERT INTO [DWH].[LKP_optionStyle] ([ID], [style], [styleDescription], [active], [modificationDate]) VALUES (1, N'A', N'American', 1, NULL)
INSERT INTO [DWH].[LKP_optionStyle] ([ID], [style], [styleDescription], [active], [modificationDate]) VALUES (2, N'B', N'Bermuda', 1, NULL)
INSERT INTO [DWH].[LKP_optionStyle] ([ID], [style], [styleDescription], [active], [modificationDate]) VALUES (3, N'D', N'Digital', 1, NULL)
INSERT INTO [DWH].[LKP_optionStyle] ([ID], [style], [styleDescription], [active], [modificationDate]) VALUES (4, N'E', N'European', 1, NULL)
INSERT INTO [DWH].[LKP_optionStyle] ([ID], [style], [styleDescription], [active], [modificationDate]) VALUES (5, N'Q', N'Quanto', 1, NULL)
SET IDENTITY_INSERT [DWH].[LKP_optionStyle] OFF
