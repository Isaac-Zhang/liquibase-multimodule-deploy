--liquibase formatted sql

--changeSet chth:Initial-DWH-addressType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[addressType] ON
INSERT INTO [DWH].[addressType] ([ID], [descr], [addressType]) VALUES (10, NULL, N'Primary Mailing Address')
INSERT INTO [DWH].[addressType] ([ID], [descr], [addressType]) VALUES (11, NULL, N'SWIFT Address')
SET IDENTITY_INSERT [DWH].[addressType] OFF
