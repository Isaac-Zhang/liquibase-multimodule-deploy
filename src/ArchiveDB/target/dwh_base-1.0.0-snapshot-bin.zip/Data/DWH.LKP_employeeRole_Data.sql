--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_employeeRole_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_employeeRole] ON
INSERT INTO [DWH].[LKP_employeeRole] ([ID], [employeeRole], [descr], [active]) VALUES (1, N'Credit Manager', N'Credit Manager', 1)
INSERT INTO [DWH].[LKP_employeeRole] ([ID], [employeeRole], [descr], [active]) VALUES (2, N'Account Manager', N'Account Manager', 1)
SET IDENTITY_INSERT [DWH].[LKP_employeeRole] OFF
