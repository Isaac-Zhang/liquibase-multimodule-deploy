--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_cashFlowExcludeStatus_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_cashFlowExcludeStatus] ON
INSERT INTO [DWH].[LKP_cashFlowExcludeStatus] ([ID], [excludeStatus], [descr], [active]) VALUES (1, N'N', NULL, 1)
INSERT INTO [DWH].[LKP_cashFlowExcludeStatus] ([ID], [excludeStatus], [descr], [active]) VALUES (2, N'Excl historical', NULL, 1)
INSERT INTO [DWH].[LKP_cashFlowExcludeStatus] ([ID], [excludeStatus], [descr], [active]) VALUES (3, N'Excl off balance', NULL, 1)
INSERT INTO [DWH].[LKP_cashFlowExcludeStatus] ([ID], [excludeStatus], [descr], [active]) VALUES (4, N'Excl NOM from IRS.', NULL, 1)
INSERT INTO [DWH].[LKP_cashFlowExcludeStatus] ([ID], [excludeStatus], [descr], [active]) VALUES (5, N'Excl NOM from one curr ASWP.', NULL, 1)
INSERT INTO [DWH].[LKP_cashFlowExcludeStatus] ([ID], [excludeStatus], [descr], [active]) VALUES (6, N'N/A', NULL, 1)
SET IDENTITY_INSERT [DWH].[LKP_cashFlowExcludeStatus] OFF
