--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_creditQualityParent_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_creditQualityParent] ON
INSERT INTO [DWH].[LKP_creditQualityParent] ([ID], [creditQualityParent]) VALUES (1, N'parentRisk')
INSERT INTO [DWH].[LKP_creditQualityParent] ([ID], [creditQualityParent]) VALUES (2, N'parentLegal')
INSERT INTO [DWH].[LKP_creditQualityParent] ([ID], [creditQualityParent]) VALUES (3, N'state')
SET IDENTITY_INSERT [DWH].[LKP_creditQualityParent] OFF
