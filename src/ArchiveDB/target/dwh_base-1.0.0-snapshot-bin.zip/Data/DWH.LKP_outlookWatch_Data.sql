--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_outlookWatch_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_outlookWatch] ON
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (-1, N'unmapped', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (10, N'undefined', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (11, N'Developing', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (12, N'Evolving', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (13, N'N/A', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (14, N'Negative', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (15, N'Positive', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (16, N'Possible Downgrade', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (17, N'Stable', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (18, N'Under Review', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (19, N'Watch: Developing', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (20, N'Watch - Evolving', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (21, N'Watch: Negative', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (22, N'Watch: Positive', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (23, N'Watch - Possible Downgrade', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (24, N'Watch - Possible Upgrade', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (25, N'Watch - Stable', 1, NULL, NULL)
INSERT INTO [DWH].[LKP_outlookWatch] ([ID], [outlookWatch], [active], [descr], [modificationDate]) VALUES (26, N'Issue Matured', 1, NULL, NULL)
SET IDENTITY_INSERT [DWH].[LKP_outlookWatch] OFF
