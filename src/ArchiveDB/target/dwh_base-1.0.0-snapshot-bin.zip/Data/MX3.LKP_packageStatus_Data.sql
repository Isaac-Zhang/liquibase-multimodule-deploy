--liquibase formatted sql

--changeSet chth:Initial-MX3-LKP_packageStatus_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_packageStatus] ON
INSERT INTO [MX3].[LKP_packageStatus] ([mxStatusId], [packageStatus], [ACTIVE], [datemodified]) VALUES (0, N'Active', 1, '2015-01-20 11:00:54.793')
INSERT INTO [MX3].[LKP_packageStatus] ([mxStatusId], [packageStatus], [ACTIVE], [datemodified]) VALUES (1, N'Inactive', 1, '2015-01-20 11:00:54.797')
INSERT INTO [MX3].[LKP_packageStatus] ([mxStatusId], [packageStatus], [ACTIVE], [datemodified]) VALUES (2, N'Suspended', 1, '2015-01-20 11:00:54.797')
INSERT INTO [MX3].[LKP_packageStatus] ([mxStatusId], [packageStatus], [ACTIVE], [datemodified]) VALUES (3, N'n/a', 1, '2015-01-20 11:00:54.797')
SET IDENTITY_INSERT [DWH].[LKP_packageStatus] OFF