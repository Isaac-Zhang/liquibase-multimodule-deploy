--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_creditQualityType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_creditQualityType] ON
INSERT INTO [DWH].[LKP_creditQualityType] ([ID], [creditQualityType], [fromInternalRating]) VALUES (1001, N'Standard', 0)
INSERT INTO [DWH].[LKP_creditQualityType] ([ID], [creditQualityType], [fromInternalRating]) VALUES (1002, N'IRBSecurizations', 0)
INSERT INTO [DWH].[LKP_creditQualityType] ([ID], [creditQualityType], [fromInternalRating]) VALUES (1003, N'IRBSpecializedLending', 1)
INSERT INTO [DWH].[LKP_creditQualityType] ([ID], [creditQualityType], [fromInternalRating]) VALUES (1004, N'StandardSecurizations', 0)
INSERT INTO [DWH].[LKP_creditQualityType] ([ID], [creditQualityType], [fromInternalRating]) VALUES (1005, N'IRBEstimatedPD', 1)
INSERT INTO [DWH].[LKP_creditQualityType] ([ID], [creditQualityType], [fromInternalRating]) VALUES (1006, N'CVA', 1)
SET IDENTITY_INSERT [DWH].[LKP_creditQualityType] OFF
