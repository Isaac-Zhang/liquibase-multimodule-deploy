--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_employeeRoleType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_employeeRoleType] ON
INSERT INTO [DWH].[LKP_employeeRoleType] ([ID], [employeeRoleType], [descr], [active]) VALUES (-1, N'none', N'none', 1)
INSERT INTO [DWH].[LKP_employeeRoleType] ([ID], [employeeRoleType], [descr], [active]) VALUES (1, N'Corporates', N'Corporates', 1)
INSERT INTO [DWH].[LKP_employeeRoleType] ([ID], [employeeRoleType], [descr], [active]) VALUES (2, N'Financials', N'Financials', 1)
INSERT INTO [DWH].[LKP_employeeRoleType] ([ID], [employeeRoleType], [descr], [active]) VALUES (3, N'CapM', N'CapM', 1)
INSERT INTO [DWH].[LKP_employeeRoleType] ([ID], [employeeRoleType], [descr], [active]) VALUES (4, N'Corporate', N'Corporate', 1)
INSERT INTO [DWH].[LKP_employeeRoleType] ([ID], [employeeRoleType], [descr], [active]) VALUES (5, N'IPF', N'IPF', 1)
INSERT INTO [DWH].[LKP_employeeRoleType] ([ID], [employeeRoleType], [descr], [active]) VALUES (6, N'Other', N'Other', 1)
SET IDENTITY_INSERT [DWH].[LKP_employeeRoleType] OFF
