--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_packageMethod_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_packageMethod] ON
INSERT INTO [DWH].[LKP_packageMethod] ([ID], [packageMethod], [active], [modificationDate]) VALUES (1, N'Asset swap package', 1, NULL)
INSERT INTO [DWH].[LKP_packageMethod] ([ID], [packageMethod], [active], [modificationDate]) VALUES (2, N'Funding swap', 1, NULL)
INSERT INTO [DWH].[LKP_packageMethod] ([ID], [packageMethod], [active], [modificationDate]) VALUES (3, N'Package', 1, NULL)
INSERT INTO [DWH].[LKP_packageMethod] ([ID], [packageMethod], [active], [modificationDate]) VALUES (5, N'UD Structured trades', 1, '2014-06-09 12:19:48.293')
SET IDENTITY_INSERT [DWH].[LKP_packageMethod] OFF
