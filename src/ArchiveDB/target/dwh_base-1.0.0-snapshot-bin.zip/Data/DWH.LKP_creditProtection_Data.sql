--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_creditProtection_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
INSERT INTO [DWH].[LKP_creditProtection] ([_scenario_ID], [creditRiskProtectionAllocation], [validFrom], [validTo], [isCreditProtection], [isEnabledForDoubleDefault], [isLEProtection]) VALUES (-1, N'Risk Covered Entity Normal', '2001-01-01', '2199-12-31', 0, 0, 0)
INSERT INTO [DWH].[LKP_creditProtection] ([_scenario_ID], [creditRiskProtectionAllocation], [validFrom], [validTo], [isCreditProtection], [isEnabledForDoubleDefault], [isLEProtection]) VALUES (-1, N'Risk Covering Entity Combination', '2001-01-01', '2199-12-31', 1, 1, 1)
INSERT INTO [DWH].[LKP_creditProtection] ([_scenario_ID], [creditRiskProtectionAllocation], [validFrom], [validTo], [isCreditProtection], [isEnabledForDoubleDefault], [isLEProtection]) VALUES (-1, N'Risk Covering Entity Normal', '2001-01-01', '2199-12-31', 1, 0, 1)
