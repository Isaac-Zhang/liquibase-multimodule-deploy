--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_beneficialOwner_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_beneficialOwner] ON
INSERT INTO [DWH].[LKP_beneficialOwner] ([ID], [beneficialOwner], [beneficialOwnerDescription], [active], [modificationDate]) VALUES (10000, N'Beneficial Owner 1', N'Beneficial Owner 1', 1, '2013-06-24 10:34:29.273')
INSERT INTO [DWH].[LKP_beneficialOwner] ([ID], [beneficialOwner], [beneficialOwnerDescription], [active], [modificationDate]) VALUES (10001, N'Beneficial Owner 2', N'Beneficial Owner 2', 1, '2013-06-24 10:34:29.277')
INSERT INTO [DWH].[LKP_beneficialOwner] ([ID], [beneficialOwner], [beneficialOwnerDescription], [active], [modificationDate]) VALUES (10002, N'Beneficial Owner 3', N'Beneficial Owner 3', 1, '2013-06-24 10:34:29.277')
INSERT INTO [DWH].[LKP_beneficialOwner] ([ID], [beneficialOwner], [beneficialOwnerDescription], [active], [modificationDate]) VALUES (10003, N'Beneficial Owner 4', N'Beneficial Owner 4', 1, '2013-06-24 10:34:29.280')
SET IDENTITY_INSERT [DWH].[LKP_beneficialOwner] OFF
