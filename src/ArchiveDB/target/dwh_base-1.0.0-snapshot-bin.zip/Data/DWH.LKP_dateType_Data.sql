--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_dateType_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_dateType] ON
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (79, N'docInOutDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (80, N'expiryDate', N'expiryDate', 1)
SET IDENTITY_INSERT [DWH].[LKP_dateType] OFF
SET IDENTITY_INSERT [DWH].[LKP_dateType] ON
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (41, N'bondMaturityDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (42, N'currentCouponDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (43, N'date', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (44, N'dealinsertionDateMxG', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (45, N'endDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (46, N'externAllInDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (47, N'externAllIn2Date', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (48, N'interestDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (49, N'issueDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (50, N'lastMarketOperationDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (51, N'maturityDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (52, N'migrationDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (53, N'couponNextPayDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (54, N'couponNextFixingDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (55, N'revaluationDate0', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (56, N'revaluationDate1', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (57, N'revaluationDate2', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (58, N'startDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (59, N'tradeDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (60, N'updateDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (61, N'firstInterestPayDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (62, N'nextCouponDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (63, N'eventStartDate', N'eventStartDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (64, N'eventTradeDate', N'eventTradeDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (65, N'triggerStartDate', N'triggerStartDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (66, N'triggerEndDate', N'triggerEndDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (67, N'drawDownStartDate', N'drawDownStartDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (68, N'drawDownEndDate', N'drawDownEndDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (69, N'couponCalculationEndDate', N'couponCalculationEndDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (70, N'optionDeliveryDate', N'optionDeliveryDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (71, N'barrierWindowStartDate', N'barrierWindowStartDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (72, N'barrierWindowEndDate', N'barrierWindowEndDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (73, N'optionStrikeDate', N'optionStrikeDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (74, N'amortizationDate', N'amortizationDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (75, N'couponCalculationStartDate', N'couponCalculationStartDate', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (76, N'triggerStartCallDate', N'', 1)
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (77, N'triggerEndCallDate', N'', 1)
SET IDENTITY_INSERT [DWH].[LKP_dateType] OFF
SET IDENTITY_INSERT [DWH].[LKP_dateType] ON
INSERT INTO [DWH].[LKP_dateType] ([ID], [dateType], [descr], [active]) VALUES (78, N'docActionDate', N'', 1)
SET IDENTITY_INSERT [DWH].[LKP_dateType] OFF
