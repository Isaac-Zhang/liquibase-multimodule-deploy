--liquibase formatted sql

--changeSet chth:Initial-DWH-LKP_riskWeightFunction_Data-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET IDENTITY_INSERT [DWH].[LKP_riskWeightFunction] ON
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (23, N'rw_sADM_no_ext', N'rw_sADM')
SET IDENTITY_INSERT [DWH].[LKP_riskWeightFunction] OFF
SET IDENTITY_INSERT [DWH].[LKP_riskWeightFunction] ON
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (1, N'rw_s0', N'zeroWeight')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (2, N'rw_s100', N'fullWeight')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (3, N'rw_sSTA', N'Sovereign')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (4, N'rw_sFTG', N'Corporate')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (5, N'rw_sINS', N'Institution')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (6, N'rw_sSEC', N'Secured')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (7, N'rw_b2', N'pdStd')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (8, N'rw_iSPE_short', N'specialLending')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (9, N'rw_iSPE_long', N'specialLending')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (10, N'rw_iABS_A', N'ABScategoryA')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (11, N'rw_iABS_B', N'ABScategoryB')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (12, N'rw_iABS_C', N'ABScategoryC')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (13, N'rw_iABS_D', N'ABScategoryD')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (14, N'rw_iABS_E', N'ABScategoryE')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (15, N'rw_sABS_A', N'ABScategoryA')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (16, N'rw_sABS_B', N'ABScategoryB')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (17, N'rw_sABS_C', N'ABScategoryC')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (18, N'rw_sABS_D', N'ABScategoryD')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (19, N'rw_sABS_E', N'ABScategoryE')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (20, N'rw_CVA', N'cvaWeight')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (21, N'rw_CCP', N'centralCleared')
INSERT INTO [DWH].[LKP_riskWeightFunction] ([ID], [riskWeightFunction], [riskWeightFunctionName]) VALUES (22, N'rw_sADM', N'rw_sADM')
SET IDENTITY_INSERT [DWH].[LKP_riskWeightFunction] OFF
