--liquibase formatted sql

--changeSet chth:Initial-TRG_auditSprocEvent-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [TRG_auditSprocEvent] ON DATABASE  FOR DDL_PROCEDURE_EVENTS
  AS
  BEGIN
  INSERT INTO DWH_JOURNAL.dbo.eventLog (eventData, eventType, systemUser)
  VALUES (EVENTDATA (), 'Stored Procedure Change', SUSER_SNAME())
  END
GO