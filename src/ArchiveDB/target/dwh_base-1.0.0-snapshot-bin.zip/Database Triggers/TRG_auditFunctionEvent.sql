--liquibase formatted sql

--changeSet chth:Initial-TRG_auditFunctionEvent-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [TRG_auditFunctionEvent] ON DATABASE  FOR DDL_FUNCTION_EVENTS
  AS
  BEGIN
  INSERT INTO DWH_JOURNAL.dbo.eventLog (eventData, eventType, systemUser)
  VALUES (EVENTDATA (), 'Userdefined Function Change', SUSER_SNAME())
  END
GO