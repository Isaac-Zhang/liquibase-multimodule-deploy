--liquibase formatted sql

--changeSet chth:Initial-TRG_auditViewEvent-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [TRG_auditViewEvent] ON DATABASE  FOR DDL_VIEW_EVENTS
  AS
  BEGIN
  INSERT INTO DWH_JOURNAL.dbo.eventLog (eventData, eventType, systemUser)
  VALUES (EVENTDATA (), 'View Change', SUSER_SNAME())
  END
GO