--liquibase formatted sql

--changeSet chth:Initial-TRG_auditTableEvent-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO

CREATE TRIGGER [TRG_auditTableEvent] ON DATABASE  FOR DDL_TABLE_EVENTS
  AS
  BEGIN
  INSERT INTO DWH_JOURNAL.dbo.eventLog (eventData, eventType, systemUser)
  VALUES (EVENTDATA (), 'Table Change', SUSER_SNAME())
  END
GO