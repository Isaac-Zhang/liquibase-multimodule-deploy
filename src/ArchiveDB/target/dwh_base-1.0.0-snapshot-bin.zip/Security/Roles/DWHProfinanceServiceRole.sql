--liquibase formatted sql

--changeSet chth:Initial-DWHProfinanceServiceRole-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false

CREATE ROLE [DWHProfinanceServiceRole]
AUTHORIZATION [dbo]
GO