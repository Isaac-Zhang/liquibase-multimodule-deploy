--liquibase formatted sql
--EXEC sp_addrolemember N'db_ddladmin', N'SEK\sqlmonitor'
GO