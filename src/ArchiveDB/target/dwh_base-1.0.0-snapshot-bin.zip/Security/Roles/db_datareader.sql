--liquibase formatted sql
--EXEC sp_addrolemember N'db_datareader', N'SEK\DWHDeveloper'
GO
--EXEC sp_addrolemember N'db_datareader', N'SEK\DWHNormal'
GO
--EXEC sp_addrolemember N'db_datareader', N'SEK\DWHNormalBase'
GO