--liquibase formatted sql

--changeSet chth:Initial-SIPRole-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false

CREATE ROLE [SIPRole]
AUTHORIZATION [dbo]
GO