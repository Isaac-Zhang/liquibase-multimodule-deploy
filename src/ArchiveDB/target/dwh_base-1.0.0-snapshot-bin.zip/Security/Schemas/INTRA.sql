--liquibase formatted sql

--changeSet chth:Initial-INTRA-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [INTRA]
AUTHORIZATION [dbo]
GO

GO