--liquibase formatted sql

--changeSet chth:Initial-EXPORT-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [EXPORT]
AUTHORIZATION [dbo]
GO

GO