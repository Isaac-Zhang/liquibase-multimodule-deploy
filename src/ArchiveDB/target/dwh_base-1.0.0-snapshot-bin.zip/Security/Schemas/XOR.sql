--liquibase formatted sql

--changeSet chth:Initial-XOR-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [XOR]
AUTHORIZATION [dbo]
GO