--liquibase formatted sql

--changeSet chth:Initial-NOSTRO-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [NOSTRO]
AUTHORIZATION [dbo]
GO