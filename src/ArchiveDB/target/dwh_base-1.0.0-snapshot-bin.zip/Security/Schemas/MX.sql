--liquibase formatted sql

--changeSet chth:Initial-MX-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [MX]
AUTHORIZATION [dbo]
GO