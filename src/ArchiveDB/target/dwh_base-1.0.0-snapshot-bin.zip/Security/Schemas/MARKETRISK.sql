--liquibase formatted sql

--changeSet chth:Initial-MARKETRISK-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [MARKETRISK]
AUTHORIZATION [dbo]
GO