--liquibase formatted sql

--changeSet chth:Initial-DWH-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [DWH]
AUTHORIZATION [dbo]
GO