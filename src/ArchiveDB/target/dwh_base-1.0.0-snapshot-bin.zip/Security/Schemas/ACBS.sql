--liquibase formatted sql

--changeSet chth:Initial-ACBS-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [ACBS]
AUTHORIZATION [dbo]
GO