--liquibase formatted sql

--changeSet chth:Initial-MX3INTRA-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [MX3INTRA]
AUTHORIZATION [dbo]
GO