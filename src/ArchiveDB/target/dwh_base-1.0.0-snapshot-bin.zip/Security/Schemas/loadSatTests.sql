--liquibase formatted sql

--changeSet chth:Initial-loadSatTests-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [loadSatTests]
AUTHORIZATION [dbo]
GO
DECLARE @xp int
SELECT @xp=1
EXEC sp_addextendedproperty N'tSQLt.TestClass', @xp, 'SCHEMA', N'loadSatTests', NULL, NULL, NULL, NULL
GO