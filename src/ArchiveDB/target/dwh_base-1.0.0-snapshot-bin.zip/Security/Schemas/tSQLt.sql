--liquibase formatted sql

--changeSet chth:Initial-tSQLt-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [tSQLt]
AUTHORIZATION [dbo]
GO