--liquibase formatted sql

--changeSet chth:Initial-GWB-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE SCHEMA [GWB]
AUTHORIZATION [dbo]
GO