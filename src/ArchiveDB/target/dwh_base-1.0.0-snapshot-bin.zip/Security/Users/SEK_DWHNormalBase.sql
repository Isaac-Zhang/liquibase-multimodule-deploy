--liquibase formatted sql

--changeSet chth:Initial-SEK_DWHNormalBase-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'SEK\DWHNormalBase')
CREATE LOGIN [SEK\DWHNormalBase] FROM WINDOWS
GO
CREATE USER [SEK\DWHNormalBase] FOR LOGIN [SEK\DWHNormalBase]
GO