--liquibase formatted sql

--changeSet chth:Initial-SEK_DWHNormal-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'SEK\DWHNormal')
CREATE LOGIN [SEK\DWHNormal] FROM WINDOWS
GO
CREATE USER [SEK\DWHNormal] FOR LOGIN [SEK\DWHNormal]
GO
GRANT SELECT TO [SEK\DWHNormal]
