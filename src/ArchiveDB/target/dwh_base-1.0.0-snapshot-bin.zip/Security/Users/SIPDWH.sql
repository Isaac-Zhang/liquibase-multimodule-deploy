--liquibase formatted sql

--changeSet chth:Initial-SIPDWH-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
CREATE USER [SIPDWH] WITHOUT LOGIN
GO