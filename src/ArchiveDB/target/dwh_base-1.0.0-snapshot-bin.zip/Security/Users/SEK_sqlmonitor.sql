--liquibase formatted sql

--changeSet chth:Initial-SEK_sqlmonitor-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'SEK\sqlmonitor')
CREATE LOGIN [SEK\sqlmonitor] FROM WINDOWS
GO
CREATE USER [SEK\sqlmonitor] FOR LOGIN [SEK\sqlmonitor]
GO