--liquibase formatted sql

--changeSet chth:Initial-SEK_DWHDeveloper-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'SEK\DWHDeveloper')
CREATE LOGIN [SEK\DWHDeveloper] FROM WINDOWS
GO
CREATE USER [SEK\DWHDeveloper] FOR LOGIN [SEK\DWHDeveloper]
GO