--liquibase formatted sql

--changeSet chth:Initial-SIPDWHTest-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF NOT EXISTS (SELECT * FROM master.dbo.syslogins WHERE loginname = N'SIPDWHTest')
CREATE LOGIN [SIPDWHTest] WITH PASSWORD = 'p@ssw0rd'
GO
CREATE USER [SIPDWHTest] FOR LOGIN [SIPDWHTest]
GO