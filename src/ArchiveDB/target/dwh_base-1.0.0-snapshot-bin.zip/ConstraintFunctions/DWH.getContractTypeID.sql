--liquibase formatted sql

--changeSet func:Initial-DWH-getContractTypeID-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.getContractTypeID', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[getContractTypeID](@contractType varchar(5)) RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-getContractTypeID-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true
SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[getContractTypeID](@contractType varchar(5))
RETURNS tinyint
AS 
BEGIN
   DECLARE @retval tinyint
   SELECT @retval = ID FROM LKP_ContractType WHERE contractType=@contractType
   RETURN @retval
END
GO