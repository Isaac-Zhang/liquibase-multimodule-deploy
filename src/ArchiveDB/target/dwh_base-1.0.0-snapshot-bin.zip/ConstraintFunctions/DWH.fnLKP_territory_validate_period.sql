--liquibase formatted sql

--changeSet func:Initial-DWH-fnLKP_territory_validate_period-0 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
IF OBJECT_ID('DWH.fnLKP_territory_validate_period', 'FN') IS NULL EXEC('CREATE FUNCTION [DWH].[fnLKP_territory_validate_period]() RETURNS int AS BEGIN RETURN 1 END')
GO



--changeSet func:Initial-DWH-fnLKP_territory_validate_period-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:true

SET QUOTED_IDENTIFIER ON
GO
SET ANSI_NULLS ON
GO
ALTER FUNCTION  [DWH].[fnLKP_territory_validate_period]()
  --
  -- +----------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t           DWH.fnLKP_territory_validate_period 
  -- ! R e t u r n s         tinyint true=1,false=0
  -- ! P a r a m e t e r s   Name, DataType, Description
  -- +                       =========================================================================================
  -- !                       N/A
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! O b j e c t i v e
  -- !   Returns a "bit" checking the table for overlaping Periods etc. (grouped by territoryCode and _territoryType_ID)
  -- !   If no overlaps Then OK = return 1
  -- !   This bit valued is used by a CHECK CONSTRAINT on DWH.LKP_territory
  -- + ---------------------------------------------------------------------------------------------------------------
  -- !   S A M P L E
  -- !      SELECT DWH.fnLKP_territory_validate_period() as 'PeriodsAreOk'
  -- + ---------------------------------------------------------------------------------------------------------------
  -- ! H i s t o r y         Date       Who  What
  -- +                       ========== ==== =========================================================================
  -- !                       2015-02-17 Dajo CHG0011857: Initial version ... 
  -- !                       2015-03-31 Dajo CHG0011857: change name, add more checks
  -- + ---------------------------------------------------------------------------------------------------------------
  --
RETURNS BIT
AS 
    BEGIN
	DECLARE @noOverlap TINYINT
	DECLARE @isPeriod TINYINT

    --make sure validFrom <= validTo
        IF EXISTS ( SELECT
                        1
                    FROM DWH.LKP_territory a
					WHERE a.validFrom > a.validTo
					GROUP BY a.territoryCode,a.[_territoryType_ID]
						) 
			SET @isPeriod=0
		ELSE
			SET @isPeriod=1

    --check overlaps
        IF EXISTS ( SELECT
                        1
                    FROM DWH.LKP_territory a
					INNER JOIN DWH.LKP_territory b
						ON  a.validFrom > b.validFrom
						AND a.validFrom < b.validTo
						AND a.territoryCode = b.territoryCode
						AND a.[_territoryType_ID] = b.[_territoryType_ID]
						) 
           SET @noOverlap=0
        ELSE 
           SET @noOverlap=1

	RETURN @noOverlap*@isPeriod
    END
GO