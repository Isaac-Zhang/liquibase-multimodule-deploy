--liquibase formatted sql

--changeSet chth:Initial-DWH_BASE-1 endDelimiter:\nGO splitStatements:true stripComments:false runOnChange:false
ALTER DATABASE [DWH_BASE]
SET TRUSTWORTHY ON;
GO

ALTER DATABASE [DWH_BASE]
SET DB_CHAINING ON;
GO
